"""Explicit operator actions with tenant checks and retained audit evidence."""
import delivery_v2
from flask import request, abort, redirect, flash


def install(a):
    @a.app.post('/deliveries/<int:job_id>/resolve')
    @a.login_required
    def resolve_delivery(job_id):
        try:
            delivery_v2.resolve(a,job_id,a.current_owner_id(),request.form.get('action',''),request.form.get('reason',''))
            flash('已记录核对依据并更新状态。')
        except PermissionError: abort(403)
        except ValueError as exc: flash(str(exc))
        return redirect('/review')

    @a.app.post('/tasks/<int:task_id>/archive')
    @a.login_required
    def archive_task(task_id):
        with a.db() as c:
            c.execute('BEGIN IMMEDIATE')
            task=c.execute('SELECT * FROM tasks WHERE id=? AND owner_user_id=?',(task_id,a.current_owner_id())).fetchone()
            if not task: abort(404)
            if task['status'] not in ('completed','failed','cancelled','partial') or c.execute("SELECT 1 FROM delivery_jobs WHERE task_id=? AND status IN ('pending','sending','paused','unknown')",(task_id,)).fetchone():
                flash('请先结束任务并核对全部在途、未知记录。')
            else:
                c.execute("UPDATE tasks SET status='archived' WHERE id=?",(task_id,))
                flash('已归档，投递记录保留。')
        return redirect('/history')

    @a.app.get('/review')
    @a.login_required
    def review_page():
        task_id = request.args.get("task_id", type=int)
        owner_id = a.current_owner_id()
        with a.db() as c:
            if task_id is not None and not c.execute(
                "SELECT 1 FROM tasks WHERE id=? AND owner_user_id=?", (task_id, owner_id)
            ).fetchone():
                abort(404)
            jobs=c.execute("SELECT j.* FROM delivery_jobs j JOIN tasks t ON t.id=j.task_id WHERE t.owner_user_id=? AND j.status='unknown' AND (? IS NULL OR j.task_id=?) ORDER BY j.id DESC LIMIT 100",(owner_id,task_id,task_id)).fetchall()
            audits=c.execute('SELECT * FROM credential_audit WHERE owner_user_id=? ORDER BY id DESC LIMIT 50',(owner_id,)).fetchall() if task_id is None else []
            resolutions=c.execute('SELECT r.* FROM resolutions r JOIN delivery_jobs j ON j.id=r.job_id WHERE r.owner_user_id=? AND (? IS NULL OR j.task_id=?) ORDER BY r.id DESC LIMIT 50',(owner_id,task_id,task_id)).fetchall()
        return a.page("{% include 'review.html' %}",jobs=jobs,audits=audits,resolutions=resolutions,task_id=task_id)
