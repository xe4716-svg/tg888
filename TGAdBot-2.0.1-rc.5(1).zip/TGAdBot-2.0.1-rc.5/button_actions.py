"""Bot-scoped actions and immutable saved keyboard templates."""
import json
from flask import request, abort, flash, redirect

SCHEMA = """
CREATE TABLE IF NOT EXISTS button_actions(bot_id INTEGER NOT NULL,trigger TEXT NOT NULL,kind TEXT NOT NULL,body TEXT NOT NULL,mode TEXT NOT NULL DEFAULT 'inline',PRIMARY KEY(bot_id,trigger,mode));
CREATE TABLE IF NOT EXISTS button_events(bot_id INTEGER NOT NULL,event_id TEXT NOT NULL,trigger TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(bot_id,event_id));
CREATE TABLE IF NOT EXISTS button_templates(id INTEGER PRIMARY KEY,owner_user_id TEXT NOT NULL,title TEXT NOT NULL,config_json TEXT NOT NULL,created_at TEXT NOT NULL);
"""


def migrate(c):
    for sql in SCHEMA.split(';'):
        if sql.strip(): c.execute(sql)


def dispatch(a, bot_id, token, update):
    cq = update.get('callback_query')
    message = cq.get('message',{}) if cq else update.get('message',{})
    mode = 'inline' if cq else 'reply'
    trigger = str(cq.get('data','') if cq else message.get('text',''))
    chat_id = (message.get('chat') or {}).get('id')
    event_id = ('callback:' + str(cq['id'])) if cq else ('message:' + str(chat_id) + ':' + str(message.get('message_id')))
    with a.db() as c:
        c.execute('BEGIN IMMEDIATE')
        authorized = c.execute("SELECT 1 FROM chats g JOIN bots b ON b.id=g.bot_id WHERE b.id=? AND b.status='active' AND g.chat_id=? AND g.status='active'",(bot_id,chat_id)).fetchone()
        action = c.execute('SELECT * FROM button_actions WHERE bot_id=? AND trigger=? AND mode=?',(bot_id,trigger,mode)).fetchone() if authorized else None
        if not action:
            return False
        inserted = c.execute("INSERT OR IGNORE INTO button_events VALUES(?,?,?,'sending',?)",(bot_id,event_id,trigger,a.now()))
        if not inserted.rowcount: return True
    try:
        if cq:
            a.api(token,'answerCallbackQuery',{'callback_query_id':cq['id'],'text':action['body'][:200] if action['kind'] in ('notice','alert') else '已收到','show_alert':action['kind']=='alert'})
        if action['kind']=='reply':
            a.api(token,'sendMessage',{'chat_id':chat_id,'text':action['body']})
        with a.db() as c:
            c.execute("UPDATE button_events SET status='done' WHERE bot_id=? AND event_id=?",(bot_id,event_id))
    except Exception:
        with a.db() as c:
            c.execute("UPDATE button_events SET status='unknown' WHERE bot_id=? AND event_id=?",(bot_id,event_id))
        # Telegram can already have received the reply; never resend automatically.
    return True


def install(a):
    @a.app.route('/buttons',methods=['GET','POST'])
    @a.login_required
    def buttons_page():
        owner=a.current_owner_id()
        with a.db() as c:
            bots=c.execute("SELECT id,username FROM bots WHERE owner_user_id=? AND status='active'",(owner,)).fetchall()
            chats=c.execute("SELECT g.* FROM chats g JOIN bots b ON b.id=g.bot_id WHERE b.owner_user_id=? AND b.status='active' AND g.status='active'",(owner,)).fetchall()
        if request.method=='POST':
            try:
                if request.form.get('action')=='template':
                    raw=request.form.get('buttons','')
                    a.parse_buttons(raw)
                    title=request.form.get('title','').strip()
                    if not title or len(title)>100: raise ValueError('模板名称须为 1–100 字')
                    with a.db() as c:
                        c.execute('INSERT INTO button_templates(owner_user_id,title,config_json,created_at) VALUES(?,?,?,?)',(owner,title,raw,a.now()))
                else:
                    bot_id=int(request.form['bot_id'])
                    if bot_id not in {b['id'] for b in bots}: abort(403)
                    trigger=request.form.get('trigger',''); body=request.form.get('body','')
                    mode=request.form.get('mode','inline'); kind=request.form.get('kind','notice')
                    if mode not in ('inline','reply') or kind not in ('notice','alert','reply','record'): raise ValueError('动作类型无效')
                    if not 1<=len(trigger.encode())<=64: raise ValueError('触发文字/回调值须为 1–64 字节')
                    if not body or len(body)>(200 if kind in ('notice','alert') else 4096): raise ValueError('请填写符合长度限制的回复')
                    if mode=='reply' and kind not in ('reply','record'): raise ValueError('回复键盘支持发送预设回复或记录点击')
                    with a.db() as c:
                        c.execute('INSERT INTO button_actions VALUES(?,?,?,?,?) ON CONFLICT(bot_id,trigger,mode) DO UPDATE SET kind=excluded.kind,body=excluded.body',(bot_id,trigger,kind,body,mode))
                flash('已保存。模板保存为快照，不会改变现有任务。')
            except (ValueError,KeyError) as exc: flash(str(exc))
            return redirect('/buttons')
        with a.db() as c:
            templates=c.execute('SELECT * FROM button_templates WHERE owner_user_id=? ORDER BY id DESC',(owner,)).fetchall()
            actions=c.execute('SELECT x.* FROM button_actions x JOIN bots b ON b.id=x.bot_id WHERE b.owner_user_id=?',(owner,)).fetchall()
            events=c.execute('SELECT e.* FROM button_events e JOIN bots b ON b.id=e.bot_id WHERE b.owner_user_id=? ORDER BY e.rowid DESC LIMIT 50',(owner,)).fetchall()
        return a.page("{% include 'buttons.html' %}",bots=bots,chats=chats,templates=templates,actions=actions,events=events)

    @a.app.post('/buttons/test-send')
    @a.login_required
    def test_send_buttons():
        try:
            bid,cid=map(int,request.form.get('target','').split(':'))
            buttons=a.parse_buttons(request.form.get('buttons',''))
            if not buttons: raise ValueError('请先添加按钮')
            with a.db() as c:
                c.execute('BEGIN IMMEDIATE')
                chat=c.execute("SELECT g.* FROM chats g JOIN bots b ON b.id=g.bot_id WHERE b.id=? AND b.owner_user_id=? AND b.status='active' AND g.chat_id=? AND g.status='active'",(bid,a.current_owner_id(),cid)).fetchone()
                if not chat: abort(403)
                a.bind_prompt_actions(c,request.form.get('buttons',''),[bid])
                task=c.execute("""INSERT INTO tasks(bot_ids,chat_targets,body,buttons,ad_mode,ad_text,ad_button_text,ad_url,status,created_at,owner_user_id,semantics)
                                  VALUES(?,?,?,?,'BOTH',?,?,?,'running',?,?,'per_target')""",
                               (json.dumps([str(bid)]),json.dumps([f'{bid}:{cid}']),'按钮测试消息',json.dumps(buttons,ensure_ascii=False),a.setting('ad_text'),a.setting('ad_button_text'),a.setting('ad_url'),a.now(),a.current_owner_id())).lastrowid
                c.execute("INSERT INTO delivery_jobs(task_id,bot_id,chat_id,chat_title,status,created_at,updated_at) VALUES(?,?,?,?,'pending',?,?)",(task,bid,cid,chat['title'],a.now(),a.now()))
            a.start_delivery_worker()
            flash('已创建一次测试投递，请在目标群点击按钮验证。')
            return redirect(f'/tasks/{task}')
        except (ValueError,TypeError):
            flash('请选择自己的目标群并检查按钮配置。')
            return redirect('/buttons')

    @a.app.get('/buttons/templates/<int:ident>')
    @a.login_required
    def get_button_template(ident):
        with a.db() as c:
            row=c.execute('SELECT config_json FROM button_templates WHERE id=? AND owner_user_id=?',(ident,a.current_owner_id())).fetchone()
        if not row: abort(404)
        return {'config':row['config_json']}
