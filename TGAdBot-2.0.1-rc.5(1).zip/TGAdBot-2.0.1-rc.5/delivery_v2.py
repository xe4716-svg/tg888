"""Per-target delivery, persisted message receipts and explicit reconciliation."""
import contextvars
import hashlib
import json
import math
import time
from contextlib import contextmanager

_scope = contextvars.ContextVar('delivery_scope', default=None)


@contextmanager
def journal(a, job):
    marker = _scope.set({'app': a, 'job': job['id'], 'cycle': job['success_count'], 'part': 0})
    try:
        yield
    finally:
        _scope.reset(marker)


def request_with_receipt(send, method, payload):
    scope = _scope.get()
    if scope is None or not method.startswith(('send', 'copy', 'forward', 'edit')):
        return send()
    a = scope['app']
    part = scope['part']; scope['part'] += 1
    key = (scope['job'], scope['cycle'], part)
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    with a.db() as c:
        c.execute('BEGIN IMMEDIATE')
        receipt = c.execute('SELECT * FROM message_receipts WHERE job_id=? AND cycle=? AND part=?', key).fetchone()
        if receipt:
            if receipt['payload_hash'] != digest or receipt['method'] != method:
                raise a.PartialDeliveryError('发送配置与已记录消息不一致，请核对后处理。')
            if receipt['status'] == 'sent':
                return json.loads(receipt['result_json'])
            if receipt['status'] in ('sending', 'unknown'):
                raise a.PartialDeliveryError('已有结果不明的消息，禁止自动重发。')
            c.execute("UPDATE message_receipts SET status='sending' WHERE job_id=? AND cycle=? AND part=?", key)
        else:
            c.execute("INSERT INTO message_receipts(job_id,cycle,part,method,payload_hash,status) VALUES(?,?,?,?,?,'sending')",
                      (*key, method, digest))
    try:
        result = send()
    except a.TelegramAPIError:
        with a.db() as c:
            c.execute("UPDATE message_receipts SET status='failed' WHERE job_id=? AND cycle=? AND part=?", key)
        raise
    except Exception:
        with a.db() as c:
            c.execute("UPDATE message_receipts SET status='unknown' WHERE job_id=? AND cycle=? AND part=?", key)
        raise
    with a.db() as c:
        c.execute("UPDATE message_receipts SET status='sent',result_json=? WHERE job_id=? AND cycle=? AND part=?",
                  (json.dumps(result), *key))
    return result


def claim(a):
    current = int(time.time())
    with a.db() as c:
        c.execute('BEGIN IMMEDIATE')
        c.execute("""UPDATE delivery_jobs SET status='cancelled',last_error='运行时长已到',updated_at=?
                     WHERE status='pending' AND task_id IN
                     (SELECT id FROM tasks WHERE semantics='per_target' AND status='running' AND ends_at<=?)""", (a.now(), current))
        c.execute("""UPDATE tasks SET status='completed' WHERE semantics='per_target' AND status='running' AND ends_at<=?
                     AND NOT EXISTS(SELECT 1 FROM delivery_jobs WHERE task_id=tasks.id AND status IN ('sending','unknown'))""", (current,))
        row = c.execute("""SELECT j.* FROM delivery_jobs j JOIN tasks t ON t.id=j.task_id JOIN bots b ON b.id=j.bot_id
            WHERE t.semantics='per_target' AND t.status IN ('running','scheduled') AND j.status='pending'
            AND b.status='active' AND j.next_attempt_at<=? AND COALESCE(t.scheduled_at,0)<=?
            AND (t.ends_at IS NULL OR t.ends_at>?)
            AND NOT EXISTS(SELECT 1 FROM delivery_jobs busy WHERE busy.bot_id=j.bot_id AND busy.status='sending')
            ORDER BY j.next_attempt_at,j.id LIMIT 1""", (current, current, current)).fetchone()
        if not row:
            return None
        c.execute("UPDATE delivery_jobs SET status='sending',attempts=attempts+1,updated_at=? WHERE id=?", (a.now(), row['id']))
        c.execute("""UPDATE tasks SET status='running',started_at=COALESCE(started_at,?),
                     ends_at=CASE WHEN stop_after_seconds>0 AND ends_at IS NULL THEN ?+stop_after_seconds ELSE ends_at END WHERE id=?""",
                  (current, current, row['task_id']))
        task = c.execute('SELECT * FROM tasks WHERE id=?', (row['task_id'],)).fetchone()
        c.execute('INSERT OR IGNORE INTO task_versions VALUES(?,?,?,?)',
                  (task['id'], task['config_version'], json.dumps(dict(task)), a.now()))
        return dict(row) | {'attempts': row['attempts'] + 1}


def settle_success(a, c, job, task):
    count = job['success_count'] + 1
    rotation = json.loads(task['rotation_messages'] or '[]')
    cursor = (job['asset_cursor'] + 1) % max(1, len(rotation))
    current = int(time.time())
    ended = (task['max_success'] > 0 and count >= task['max_success']) or (task['ends_at'] and current >= task['ends_at'])
    state = 'sent' if ended else ('paused' if task['status'] == 'paused' else 'pending')
    if task['status'] in ('cancelled', 'archived'):
        state = 'cancelled'
    c.execute("""UPDATE delivery_jobs SET status=?,success_count=?,asset_cursor=?,attempts=0,
                 next_attempt_at=?,last_error=NULL,updated_at=? WHERE id=?""",
              (state, count, cursor, math.ceil(time.time() + a.task_send_gap_seconds(task['id'])), a.now(), job['id']))


def process(a, job, task):
    try:
        with a.db() as c:
            bot = c.execute("SELECT * FROM bots WHERE id=? AND status='active'", (job['bot_id'],)).fetchone()
        if not bot:
            with a.db() as c:
                c.execute("UPDATE delivery_jobs SET status='failed',last_error=?,updated_at=? WHERE id=?",
                          ('机器人不可用，请检查机器人状态。', a.now(), job['id']))
            return
        token = a.decrypt_token(bot['token'])
        rotation = json.loads(task['rotation_messages'] or '[]')
        buttons = json.loads(task['buttons'])
        with journal(a, job):
            if rotation:
                a.send_one(token, job['chat_id'], rotation[job['asset_cursor'] % len(rotation)], buttons, task['ad_mode'],
                           ad_text=task['ad_text'], ad_button_text=task['ad_button_text'], ad_url=task['ad_url'])
            else:
                assets = json.loads(task['media_assets'] or '{}').get(str(job['bot_id']), [])
                a.send_task_content(token, job['chat_id'], task['body'], buttons, task['ad_mode'], task['ad_text'],
                                    task['ad_button_text'], task['ad_url'], json.loads(task['content_modes']), assets, task['sender_mode'])
        with a.db() as c:
            c.execute('BEGIN IMMEDIATE')
            fresh = c.execute('SELECT * FROM tasks WHERE id=?', (task['id'],)).fetchone()
            settle_success(a, c, job, fresh)
    except a.TelegramAPIError as exc:
        a.record_delivery_api_error(job['id'], exc)
        retry = exc.retry_after is not None or (exc.code >= 500 and job['attempts'] < 5)
        delay = max(10, exc.retry_after or min(300, 2 ** min(job['attempts'], 8)))
        with a.db() as c:
            state = c.execute('SELECT status FROM tasks WHERE id=?', (task['id'],)).fetchone()[0]
            target_state = ('paused' if state == 'paused' else 'pending') if retry else 'failed'
            if state == 'cancelled': target_state = 'cancelled'
            c.execute('UPDATE delivery_jobs SET status=?,next_attempt_at=?,last_error=?,updated_at=? WHERE id=?',
                      (target_state, int(time.time()) + delay, a.telegram_error_message(exc), a.now(), job['id']))
            if exc.retry_after is not None:
                c.execute("UPDATE delivery_jobs SET next_attempt_at=MAX(next_attempt_at,?) WHERE bot_id=? AND status IN ('pending','paused')",
                          (int(time.time()) + delay, job['bot_id']))
    except Exception as exc:
        # With receipts, even partial success remains recoverable without repeating confirmed parts.
        with a.db() as c:
            ambiguous = c.execute("SELECT 1 FROM message_receipts WHERE job_id=? AND cycle=? AND status IN ('sending','unknown')",
                                  (job['id'], job['success_count'])).fetchone()
            state = 'unknown' if ambiguous or isinstance(exc, (a.PartialDeliveryError, a.requests.RequestException)) else 'failed'
            c.execute('UPDATE delivery_jobs SET status=?,last_error=?,updated_at=? WHERE id=?',
                      (state, '发送结果待核对' if state == 'unknown' else '暂时无法确定失败原因，请检查任务配置后再试。',
                       a.now(), job['id']))
    finally:
        a.update_task_summary(task['id'])


def resolve(a, job_id, owner, action, reason):
    if action not in ('sent', 'retry', 'skip') or not reason.strip() or len(reason) > 1000:
        raise ValueError('请选择处理方式，并填写核对依据（最多 1000 字）。')
    with a.db() as c:
        c.execute('BEGIN IMMEDIATE')
        job = c.execute('SELECT * FROM delivery_jobs WHERE id=?', (job_id,)).fetchone()
        task = c.execute('SELECT * FROM tasks WHERE id=? AND owner_user_id=?', (job['task_id'], owner)).fetchone() if job else None
        if not task:
            raise PermissionError()
        if job['status'] != 'unknown':
            raise ValueError('该记录已经处理，请刷新页面。')
        if action == 'sent':
            if task['semantics'] == 'per_target':
                settle_success(a, c, job, task)
            else:
                c.execute("UPDATE delivery_jobs SET status='sent',last_error=NULL,updated_at=? WHERE id=?", (a.now(), job_id))
        elif action == 'retry':
            if task['status'] in ('cancelled', 'archived'):
                raise ValueError('已终止任务不能重试。')
            c.execute("UPDATE message_receipts SET status='failed' WHERE job_id=? AND cycle=? AND status IN ('sending','unknown')", (job_id, job['success_count']))
            c.execute("UPDATE delivery_jobs SET status=?,next_attempt_at=MAX(next_attempt_at,?),last_error=NULL WHERE id=?",
                      ('paused' if task['status'] == 'paused' else 'pending', int(time.time()) + 10, job_id))
            if task['status'] == 'unknown': c.execute("UPDATE tasks SET status='running' WHERE id=?", (task['id'],))
        else:
            c.execute("UPDATE delivery_jobs SET status='cancelled',last_error='人工核对后终止该目标' WHERE id=?", (job_id,))
        c.execute('INSERT INTO resolutions(job_id,owner_user_id,action,reason,at) VALUES(?,?,?,?,?)', (job_id, owner, action, reason, a.now()))
    a.update_task_summary(task['id'])
