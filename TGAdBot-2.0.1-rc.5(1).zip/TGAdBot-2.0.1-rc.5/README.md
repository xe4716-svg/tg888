# TGAdBot 2.0.1-rc.2

TG 管家独立项目。Flask / SQLite / Docker，服务端口 8096。当前分支是可直接检查和构建的源码，不再从旧版压缩包或 Base64 补丁拼装。

- 安装与更新：[README_QUICKSTART.md](README_QUICKSTART.md)
- 改动与边界：[CHANGELOG.md](CHANGELOG.md)
- 实际检查结果：[VERIFICATION.md](VERIFICATION.md)
- 逐项进度：[TGAdBot整改清单.md](TGAdBot整改清单.md)
- 候选安装包：`releases/TGAdBot-2.0.1-rc.2.zip`，校验文件在同目录。

## 开发检查

```sh
python -m pip install -r requirements.txt pytest playwright
python -m playwright install chromium
python -m pytest -q tests
python tests/ui_component_smoke.py
python tests/ui_smoke.py
python tests/ui_remediation_smoke.py
python build_package.py
```

自动测试使用模拟 Telegram 返回值和临时数据库，不向真实群组发送消息。GitHub Actions 执行测试、浏览器检查、镜像构建和候选包打包，不部署服务器。

历史基线：用户提供 `tgadbot2.1.zip` 中的 TGAdBot 2.0，清理包 SHA-256 为 `ecde455266cb1e5d99cd7f745810b8463fa3af6699b931e847922bb614577373`。原混合压缩包已从本分支文件树移除；Git 历史未重写。
