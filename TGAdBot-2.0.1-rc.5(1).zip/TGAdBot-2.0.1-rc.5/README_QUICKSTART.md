# TGAdBot 2.0.1-rc.3 全新独立安装

本包只用于新实例，不覆盖旧目录、不复制旧配置或数据。需要 Linux、Docker Compose v2、Python 3，以及镜像和依赖下载网络。

上传 ZIP 和同名 .sha256 文件到 /www/tgadbot-rc3-new（新建空目录），执行：

```bash
cd /www/tgadbot-rc3-new
sha256sum -c TGAdBot-2.0.1-rc.3.zip.sha256
unzip TGAdBot-2.0.1-rc.3.zip
cd TGAdBot-2.0.1-rc.3
sha256sum -c SHA256SUMS
python3 init_config.py
docker compose -p tgadbot-rc3 config --quiet
docker compose -p tgadbot-rc3 up -d --build
docker compose -p tgadbot-rc3 ps
curl -fsS http://127.0.0.1:28097/health
```

健康接口应返回 ok=true、version=2.0.1-rc.3；容器稍后应为 healthy。失败查看 `docker compose -p tgadbot-rc3 logs --tail=100 tgadbot`。

容器名 tgadbot-rc3，服务 tgadbot，项目 tgadbot-rc3，宿主端口 28097，数据卷 tgadbot-rc3_tgadbot_data。首次安装前确认此容器名、端口和数据卷未被使用；若存在则停止安装并换一组独立名称与端口，不要删除已有卷。新卷首次初始化为空业务库，随后创建必要系统数据。

将新域名 HTTPS 反向代理指向 127.0.0.1:28097，保留 SESSION_COOKIE_SECURE=1，正确传递 Host、X-Forwarded-Proto。在服务器本地查看新生成 .env 内 ADMIN_PASSWORD 登录；不要公开密钥。登录后应没有机器人和业务任务，再添加自己的测试机器人验证采集与发送。

包中不含 .env、真实 Token、数据库或媒体。不要运行 down -v。旧服务和旧卷保持独立。

本地 219 项回归和三组 Chromium 检查通过；当前电脑 Docker 引擎不可用，因此 Linux 镜像构建、容器健康与真实 Telegram 实发需按上面步骤在服务器验证，未宣称已完成生产验收。
