#!/usr/bin/env python3
"""Generate a private configuration for a NEW installation; never overwrite it."""
import argparse
import base64
import os
from pathlib import Path
import secrets


def create_config(directory: Path, local_http: bool = False) -> Path:
    template = (directory / '.env.example').read_text(encoding='utf-8')
    replacements = {
        'REPLACE_WITH_RANDOM_SECRET_AT_LEAST_32_CHARS': secrets.token_urlsafe(48),
        'REPLACE_WITH_STRONG_ADMIN_PASSWORD_AT_LEAST_12_CHARS': secrets.token_urlsafe(24),
        'REPLACE_WITH_FERNET_KEY': base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('ascii'),
    }
    for placeholder, value in replacements.items():
        if template.count(placeholder) != 1:
            raise ValueError('Unexpected .env.example placeholder: ' + placeholder)
        template = template.replace(placeholder, value)
    if local_http:
        template = template.replace('SESSION_COOKIE_SECURE=1', 'SESSION_COOKIE_SECURE=0')
    target = directory / '.env'
    descriptor = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'w', encoding='utf-8', newline='\n') as output:
        output.write(template)
    return target


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--local-http', action='store_true', help='Allow HTTP cookies only for a local SSH tunnel')
    options = parser.parse_args()
    try:
        create_config(Path(__file__).resolve().parent, options.local_http)
    except FileExistsError:
        parser.exit(1, 'Refusing to overwrite existing .env. Existing installation: preserve all original secrets.\n')
    print('Created private .env beside this script. Read ADMIN_PASSWORD locally; secrets are not printed.')
