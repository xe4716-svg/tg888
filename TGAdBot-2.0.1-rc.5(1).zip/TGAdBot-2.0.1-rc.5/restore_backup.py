#!/usr/bin/env python3
"""Restore the SQLite database and media snapshot created by upgrade.sh."""

from __future__ import annotations

import argparse
from contextlib import closing
import os
import shutil
import sqlite3
import tarfile
import tempfile
from pathlib import Path


def _verify_sqlite(path: Path) -> None:
    if not path.is_file():
        raise FileNotFoundError(f"SQLite backup not found: {path}")
    uri = path.resolve().as_uri() + "?mode=ro"
    with closing(sqlite3.connect(uri, uri=True)) as connection:
        row = connection.execute("PRAGMA integrity_check").fetchone()
    if not row or row[0] != "ok":
        raise RuntimeError(f"SQLite integrity_check failed for {path}: {row!r}")


def _remove_path(path: Path) -> None:
    if path.is_symlink() or path.is_file():
        path.unlink(missing_ok=True)
    elif path.exists():
        shutil.rmtree(path)


def restore_backup(backup_dir: str | Path, db_path: str | Path, media_dir: str | Path) -> dict[str, str]:
    backup_root = Path(backup_dir)
    backup_db = backup_root / "tgadbot.sqlite3"
    media_archive = backup_root / "media.tar.gz"
    database = Path(db_path)
    media = Path(media_dir)

    # Preserve the application's ownership when the private backup is read as root.
    # Validate and stage every backup before touching the live persistent volume.
    _verify_sqlite(backup_db)
    database.parent.mkdir(parents=True, exist_ok=True)
    media.parent.mkdir(parents=True, exist_ok=True)
    db_stat = (database if database.exists() else database.parent).stat()
    media_stat = (media if media.exists() else media.parent).stat()
    if media.is_symlink() or (media.exists() and not media.is_dir()):
        raise RuntimeError(f"Refusing to replace non-directory media path: {media}")

    with tempfile.TemporaryDirectory(prefix=".tgadbot-restore-", dir=str(media.parent)) as temp_name:
        temp_root = Path(temp_name)
        staged_db = temp_root / "restored.sqlite3"
        shutil.copy2(backup_db, staged_db)
        _verify_sqlite(staged_db)

        staged_media = temp_root / "media"
        has_media_backup = media_archive.is_file()
        if has_media_backup:
            staged_media.mkdir()
            with tarfile.open(media_archive, "r:gz") as archive:
                archive.extractall(path=staged_media, filter="data")

        if hasattr(os, "geteuid") and os.geteuid() == 0:
            os.chown(staged_db, db_stat.st_uid, db_stat.st_gid)
            if has_media_backup:
                for item in [staged_media, *staged_media.rglob("*")]:
                    os.chown(item, media_stat.st_uid, media_stat.st_gid, follow_symlinks=False)

        previous_media = temp_root / "previous-media"
        media_swapped = False
        if has_media_backup:
            if media.exists():
                os.replace(media, previous_media)
            try:
                os.replace(staged_media, media)
                media_swapped = True
            except Exception:
                if previous_media.exists():
                    os.replace(previous_media, media)
                raise

        previous_db_files: list[tuple[Path, Path]] = []
        try:
            for suffix in ("", "-wal", "-shm"):
                live_path = Path(str(database) + suffix)
                if live_path.exists():
                    saved_path = temp_root / ("previous.sqlite3" + suffix)
                    os.replace(live_path, saved_path)
                    previous_db_files.append((live_path, saved_path))
            os.replace(staged_db, database)
        except Exception:
            for live_path, saved_path in reversed(previous_db_files):
                if saved_path.exists():
                    os.replace(saved_path, live_path)
            if media_swapped:
                _remove_path(media)
                if previous_media.exists():
                    os.replace(previous_media, media)
            raise

    return {
        "database": "restored",
        "integrity": "ok",
        "media": "restored" if media_archive.is_file() else "unchanged (no media backup)",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backup-dir", required=True)
    parser.add_argument("--db-path", required=True)
    parser.add_argument("--media-dir", required=True)
    args = parser.parse_args()
    result = restore_backup(args.backup_dir, args.db_path, args.media_dir)
    print("Rollback data restore:", ", ".join(f"{key}={value}" for key, value in result.items()))


if __name__ == "__main__":
    main()
