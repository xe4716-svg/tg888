"""Transactional additive migrations, checksum verification and SQLite backups."""
import hashlib
import os
import sqlite3
from pathlib import Path

SQL = """
CREATE TABLE IF NOT EXISTS credential_audit(id INTEGER PRIMARY KEY,owner_user_id TEXT NOT NULL,bot_id INTEGER NOT NULL,action TEXT NOT NULL,at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS credential_audit_owner ON credential_audit(owner_user_id,at);
CREATE TABLE IF NOT EXISTS task_versions(task_id INTEGER NOT NULL,version INTEGER NOT NULL,config_json TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(task_id,version));
CREATE TABLE IF NOT EXISTS resolutions(id INTEGER PRIMARY KEY,job_id INTEGER NOT NULL,owner_user_id TEXT NOT NULL,action TEXT NOT NULL,reason TEXT NOT NULL,at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS message_receipts(id INTEGER PRIMARY KEY,job_id INTEGER NOT NULL,cycle INTEGER NOT NULL,part INTEGER NOT NULL,method TEXT NOT NULL,payload_hash TEXT NOT NULL,status TEXT NOT NULL,result_json TEXT,UNIQUE(job_id,cycle,part));
CREATE TABLE IF NOT EXISTS worker_lease(name TEXT PRIMARY KEY,holder TEXT NOT NULL,expires REAL NOT NULL);
"""
ADDITIONS = {
    'tasks': {'config_version': 'INTEGER NOT NULL DEFAULT 1', 'paused_at': 'INTEGER',
              'pause_total': 'INTEGER NOT NULL DEFAULT 0', 'semantics': "TEXT NOT NULL DEFAULT 'legacy'", 'max_success': 'INTEGER NOT NULL DEFAULT 1',
              'stop_after_seconds': 'INTEGER NOT NULL DEFAULT 0', 'started_at': 'INTEGER', 'ends_at': 'INTEGER'},
    'delivery_jobs': {'success_count': 'INTEGER NOT NULL DEFAULT 0', 'asset_cursor': 'INTEGER NOT NULL DEFAULT 0'},
    'bots': {'lifecycle': 'INTEGER NOT NULL DEFAULT 1'},
}


def migrate(c):
    from material_library import SCHEMA as materials_schema
    from button_actions import SCHEMA as buttons_schema
    checksum = hashlib.sha256((Path(__file__).read_text(encoding='utf-8') + materials_schema + buttons_schema).encode()).hexdigest()
    c.execute('CREATE TABLE IF NOT EXISTS schema_migrations(version TEXT PRIMARY KEY,checksum TEXT NOT NULL)')
    old = c.execute("SELECT checksum FROM schema_migrations WHERE version='2.0.1-operations'").fetchone()
    if old:
        if old[0] != checksum:
            raise RuntimeError('Migration checksum changed: 2.0.1-operations')
        return
    for statement in SQL.split(';'):
        if statement.strip():
            c.execute(statement)
    for table, additions in ADDITIONS.items():
        columns = {r[1] for r in c.execute(f'PRAGMA table_info({table})')}
        for name, kind in additions.items():
            if name not in columns:
                c.execute(f'ALTER TABLE {table} ADD COLUMN {name} {kind}')
    for event in ('INSERT','UPDATE'):
        c.execute(f"""CREATE TRIGGER IF NOT EXISTS validate_modern_task_{event.lower()}
                      BEFORE {event} ON tasks WHEN NEW.semantics='per_target' AND
                      (NEW.send_gap_seconds<10 OR NEW.send_gap_seconds>3600 OR NEW.max_success<0 OR NEW.stop_after_seconds<0)
                      BEGIN SELECT RAISE(ABORT,'invalid task limits'); END""")
    c.execute('INSERT INTO schema_migrations VALUES(?,?)', ('2.0.1-operations', checksum))


def backup_before_upgrade(path):
    source = Path(path)
    if not source.is_file() or not source.stat().st_size:
        return
    connection = sqlite3.connect(str(source))
    try:
        known = connection.execute("SELECT 1 FROM sqlite_master WHERE name='schema_migrations'").fetchone()
        if known and connection.execute("SELECT 1 FROM schema_migrations WHERE version='2.0.1-operations'").fetchone():
            return
        dest = source.with_name(source.name + '.before-2.0.1.bak')
        try:
            fd = os.open(str(dest), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            raise RuntimeError('升级备份已存在，请先核对并另存备份再重试：' + str(dest))
        os.close(fd)
        output = sqlite3.connect(str(dest))
        try:
            connection.backup(output)
        finally:
            output.close()
    finally:
        connection.close()
