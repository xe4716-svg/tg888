"""Process-held lock: a second scheduler using this database cannot start."""
import os

_handle = None


def acquire(database):
    global _handle
    if _handle is not None: return
    handle = open(database + '.worker.lock', 'a+b')
    try:
        handle.seek(0)
        if os.name == 'nt':
            import msvcrt
            if os.path.getsize(handle.name) == 0:
                handle.write(b'0'); handle.flush(); handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        handle.close()
        raise RuntimeError('此数据库已有调度进程；请保持一个 Gunicorn worker，勿重复启动。') from None
    _handle = handle
