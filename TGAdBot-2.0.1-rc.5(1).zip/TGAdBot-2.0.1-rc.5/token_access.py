"""Owner-only, reauthenticated access to encrypted Bot credentials."""
import hmac
import time
from flask import request, session, jsonify, abort


def install(a):
    @a.app.post('/bots/<int:bot_id>/token/reveal')
    @a.login_required
    def reveal_bot_token(bot_id):
        owner = a.current_owner_id()
        with a.db() as c:
            bot = c.execute("SELECT * FROM bots WHERE id=?", (bot_id,)).fetchone()
            if not bot or bot['owner_user_id'] != owner:
                abort(403)
            if bot['status'] == 'deleted':
                abort(409)
            user = c.execute('SELECT password_hash FROM user_accounts WHERE id=?', (owner,)).fetchone()
            failures = c.execute("SELECT COUNT(*) FROM credential_audit WHERE owner_user_id=? AND action='denied' AND at>?",
                                 (owner, int(time.time()) - 600)).fetchone()[0]
        if failures >= 5:
            return jsonify(error='验证次数过多，请 10 分钟后再试。'), 429
        verified = session.get('credential_verified', {})
        valid = verified.get('owner') == owner and 0 <= time.time() - verified.get('at', 0) < 300
        if not valid:
            password = request.form.get('password', '')
            valid = (hmac.compare_digest(password.encode(), a.ADMIN_PASSWORD.encode()) if owner == 'legacy_admin'
                     else bool(user and user['password_hash'] and a.verify_password(password, user['password_hash'])))
            if not valid:
                with a.db() as c:
                    c.execute("INSERT INTO credential_audit(owner_user_id,bot_id,action,at) VALUES(?,?,'denied',?)",
                              (owner, bot_id, int(time.time())))
                return jsonify(error='密码不正确；Telegram 登录用户请先在账号设置中设置密码。'), 403
            session['credential_verified'] = {'owner': owner, 'at': int(time.time())}
        with a.db() as c:
            c.execute("INSERT INTO credential_audit(owner_user_id,bot_id,action,at) VALUES(?,?,'reveal',?)",
                      (owner, bot_id, int(time.time())))
        return jsonify(token=a.decrypt_token(bot['token']), expires_in=60)

    @a.app.after_request
    def protect_credential_response(response):
        if '/token/' in request.path:
            response.headers['Cache-Control'] = 'no-store, private'
            response.headers['Pragma'] = 'no-cache'
            response.headers['X-Content-Type-Options'] = 'nosniff'
        return response
