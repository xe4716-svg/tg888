# TGAdBot 2.0.1-rc.1 检查记录

日期：2026-11-11。实际执行环境：Windows、Python 3.11、Flask 完整运行环境、Playwright Chromium。所有 Token、用户、消息和数据库均为测试数据。

## 已执行

|检查|结果|证据入口|
|---|---|---|
|全量自动测试|201 passed in 19.91s|`python -m pytest -q tests --junitxml=dist/pytest.xml`|
|可视化编辑器|通过；无 JavaScript 异常|`tests/ui_component_smoke.py`|
|页面业务流程|通过：任务创建、模板载入、任务编辑、公告、Bot 删除|`tests/ui_smoke.py`|
|新增页面与凭据生命周期|通过：密码遮罩、Token 一分钟隐藏、1440/820/390 宽度、手机导航和主题持久化|`tests/ui_remediation_smoke.py`|
|部署配置与脚本|通过：Docker Compose 配置解析，Linux Bash 检查 preflight.sh/upgrade.sh 语法|`docker compose config --quiet`；隔离 Linux 容器内 `bash -n`|
|旧库升级|通过：旧明文 Token 加密、已删除记录失效标记、迁移重入、SQLite 完整性、升级前备份|`test_upgrade_backup_preserves_old_token_and_history`|
|权限与并发|通过：他人/管理员越权 Token 访问拒绝、CSRF、失败限速、并发领取只有一个成功|`tests/test_unified_remediation.py`|
|重复发送防护|通过：成功部分复用回执、未知结果不自动重试、人工核对重复提交拒绝、本地媒体上传回执|同上|
|安全导入|通过：ZIP 越界路径拒绝、来源版本、续传去重|同上|

原清理版 180 项测试保留，本次增加 21 项自动化用例。测试数字不是功能完备度百分比。

## 未通过 / 未验证

- 本机 Docker 镜像构建未完成：连接 `auth.docker.io` 超时，失败发生在下载 Python 基础镜像阶段。不是镜像已构建成功。GitHub Actions 重新执行镜像构建，结果以对应提交的运行记录为准。
- 没有使用真实 Telegram Bot/账号/目标群。消息收发、频道权限、真实相册、真实点击和限流仍须测试账号联调。
- 未对线上服务器部署。Linux/CentOS 生产升级、SELinux 强制策略及完整容器回滚未在本轮实际执行。
- 设计稿的 TDLib 直接读取账号历史和完整语言切换尚未交付；历史导入现为 Desktop JSON/ZIP。来源中的文字、说明、原始结构可保存；任意格式的在线素材编辑、自动后台历史抓取不在已通过范围。

## 如何复查

按 README 安装开发依赖并执行三组浏览器检查与 pytest。`build_package.py` 只收集明确列出的代码、模板、静态文件、说明及测试文件，附每文件 SHA-256。不会把运行目录、数据库、真实 .env 或旧混合源码包放入新包。

本分支没有部署动作。需以候选包先进行测试服务器验收后，再决定正式升级。

## 2.0.1-rc.2

Local remediation baseline: 208 pytest checks passed before packaging. Chromium checks covered the editor, delivery history and responsive navigation. This package has not been verified on a production server.


## 2026-11-12 本地 005/013 专项及 006/007 基础逻辑

- 全量：`python -m pytest -q tests`，219 passed in 24.33s；证据 `regression-final.log`。
- 浏览器：`tests/ui_component_smoke.py`、`tests/ui_remediation_smoke.py`、`tests/ui_smoke.py` 全部通过。
- 新增来源切换、跨 Bot 消息去重、跨账号隔离、旧导入接口关闭；成员变更异常及删除隔离、迟到事件保护；提示动作事务回滚及重复回调回归。
- Chromium 检查来源切换、异常刷新、删除取消/确认、提示预览、桌面/平板/手机布局，截图 `dist/screenshots/`。
- 数据结构未变更，历史资料保留。005/013 以本地授权范围完成；006/007 基础逻辑就绪，最终设计逐项验收未完成；本轮未打包、未部署、未实发 Telegram。
