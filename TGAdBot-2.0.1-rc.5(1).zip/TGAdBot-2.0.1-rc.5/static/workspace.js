"use strict";
(() => {
  try { document.body.classList.toggle('dark',localStorage.getItem('tgadbot-theme')==='dark'); } catch {}
  document.querySelector('.theme-toggle')?.addEventListener('click',()=>{
    document.body.classList.toggle('dark');
    try {localStorage.setItem('tgadbot-theme',document.body.classList.contains('dark')?'dark':'light');} catch {}
  });
  document.querySelector('[data-button-template]')?.addEventListener('change',async event=>{
    if(!event.target.value)return;
    const response=await fetch('/buttons/templates/'+event.target.value);
    if(!response.ok)return;
    const data=await response.json(), raw=document.querySelector('textarea[name=buttons]');
    if(raw){raw.value=data.config;raw.dispatchEvent(new Event('template-loaded'));}
  });
  const menu=document.querySelector('.menu-toggle');
  menu?.addEventListener('click',()=>{const open=document.body.classList.toggle('nav-open');menu.setAttribute('aria-expanded',String(open));});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'){document.body.classList.remove('nav-open');menu?.setAttribute('aria-expanded','false');}});
  document.querySelectorAll('[data-timezone]').forEach(input=>input.value=String(new Date().getTimezoneOffset()));
  document.querySelector('[data-test-buttons]')?.addEventListener('submit',event=>{
    event.currentTarget.querySelector('[name=buttons]').value=document.querySelector('textarea[name=buttons]')?.value || '';
  });
  document.querySelectorAll('main table').forEach(table=>{
    const input=document.createElement('input');input.type='search';input.placeholder='筛选当前表格';input.setAttribute('aria-label','筛选当前表格');input.className='filter-input';
    table.parentElement.before(input);input.oninput=()=>table.querySelectorAll('tbody tr').forEach(row=>row.hidden=!row.textContent.toLowerCase().includes(input.value.toLowerCase()));
  });
  // Confirm the concrete settings once; preserve native validation and CSRF submission.
  const form=document.querySelector('form.broadcast-form');
  if(form){let confirmed=false;form.addEventListener('submit',event=>{
    if(event.defaultPrevented||confirmed)return;
    event.preventDefault();
    const data=new FormData(form), dialog=document.createElement('dialog'),title=document.createElement('h2'),summary=document.createElement('pre');
    title.textContent='确认本次任务配置';summary.className='form-preview';
    summary.textContent=`目标群组：${data.getAll('chat_keys').length}\n素材：${data.getAll('content_modes').map(value=>({text:'文字',photo:'图片',video:'视频'})[value]||'素材').join('、')}\n发送间隔：${data.get('send_gap_seconds')} 秒\n启动时间：${data.get('scheduled_at')||'保持原计划 / 立即开始'}\n每群成功上限：${({once:'1',loop:'不限',count:data.get('repeat_max_runs')})[data.get('repeat_mode')]||'1'}\n停止时长：${data.get('repeat_duration_value')||'不限'} ${({none:'',minutes:'分钟',hours:'小时',days:'天'})[data.get('repeat_duration_unit')]||''}\n正文：${data.get('body')||''}\n轮换素材：${data.get('rotation_messages')||'无'}`;
    const back=document.createElement('button'),save=document.createElement('button');back.type=save.type='button';back.textContent='返回修改';save.textContent='确认保存';back.onclick=()=>dialog.close();save.onclick=()=>{confirmed=true;dialog.close();form.requestSubmit();confirmed=false;};
    dialog.append(title,summary,back,save);document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove());dialog.showModal();
  });}
})();

(() => {
  const list = document.querySelector("[data-sidebar-links]");
  if (!list) return;
  document.querySelector("[data-add-sidebar-link]")?.addEventListener("click", () => {
    if (list.children.length >= 30) return;
    const row = document.createElement("div");
    row.className = "field-grid";
    row.dataset.sidebarLink = "";
    const name = document.createElement("input");
    name.name = "sidebar_link_name";
    name.placeholder = "按钮名称";
    name.setAttribute("aria-label", "按钮名称");
    name.maxLength = 60;
    const url = document.createElement("input");
    url.name = "sidebar_link_url";
    url.type = "url";
    url.placeholder = "https://";
    url.setAttribute("aria-label", "自定义链接");
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "secondary";
    remove.dataset.removeSidebarLink = "";
    remove.textContent = "删除";
    row.append(name, url, remove);
    list.append(row);
    name.focus();
  });
  list.addEventListener("click", event => {
    if (event.target.closest("[data-remove-sidebar-link]")) {
      event.target.closest("[data-sidebar-link]")?.remove();
    }
  });
})();

// Keep delivery counts and status labels current without replacing controls.
(() => {
  if (!/^\/(history|tasks\/\d+)$/.test(location.pathname)) return;
  let busy = false;
  async function updateDeliveryStatus() {
    if (busy || document.hidden) return;
    busy = true;
    try {
      const response = await fetch(location.href, {cache: "no-store", credentials: "same-origin"});
      if (!response.ok || new URL(response.url).pathname !== location.pathname) return;
      const snapshot = new DOMParser().parseFromString(await response.text(), "text/html");
      const selectors = [".stats-grid .stat-value", ".section-head > .status-pill", "[data-live-summary]"];
      for (const selector of selectors) {
        const visible = document.querySelectorAll(selector);
        const incoming = snapshot.querySelectorAll(selector);
        if (visible.length !== incoming.length) continue;
        visible.forEach((element, index) => {
          element.textContent = incoming[index].textContent;
          element.className = incoming[index].className;
        });
      }
      const progress = document.querySelector("[data-live-progress]");
      const latestProgress = snapshot.querySelector("[data-live-progress]");
      if (progress && latestProgress) progress.replaceChildren(...latestProgress.children);
      const results = document.querySelector("[data-delivery-results]");
      const latest = snapshot.querySelector("[data-delivery-results]");
      if (results && latest && results.innerHTML !== latest.innerHTML &&
          !results.contains(document.activeElement)) {
        results.replaceChildren(...latest.children);
      }
    } catch {
      // Keep the last available result until the next successful refresh.
    } finally {
      busy = false;
    }
  }
  setInterval(updateDeliveryStatus, 3000);
  document.addEventListener("visibilitychange", updateDeliveryStatus);
})();
(() => {
  const fields = document.querySelectorAll('input[name="send_gap_seconds"]');
  if (!fields.length) return;
  let refreshing = false;
  async function refreshInterval() {
    if (refreshing || document.hidden) return;
    refreshing = true;
    try {
      const response = await fetch("/settings/delivery-interval", {cache: "no-store", credentials: "same-origin"});
      if (!response.ok || !response.headers.get("content-type")?.includes("application/json")) return;
      const data = await response.json();
      if (Number.isFinite(data.seconds)) {
        fields.forEach(field => {
          field.min = String(data.seconds);
          if (document.activeElement !== field && Number(field.value) < data.seconds) {
            field.value = String(data.seconds);
          }
        });
      }
    } catch {
      // Retain the last minimum interval until the next successful update.
    } finally {
      refreshing = false;
    }
  }
  setInterval(refreshInterval, 3000);
  document.addEventListener("visibilitychange", refreshInterval);
})();
(() => {
  const sources = document.querySelector('[data-source-chat]');
  if (!sources) return;
  const bot = sources.form.querySelector('[name="bot_id"]');
  const options = Array.from(sources.options).map(option => option.cloneNode(true));
  function refresh() {
    sources.replaceChildren(...options.filter(option => option.dataset.bot === bot.value).map(option => option.cloneNode(true)));
    sources.disabled = sources.options.length === 0;
    sources.form.querySelector('button[type="submit"],button:not([type])').disabled = sources.disabled;
  }
  bot.addEventListener('change', refresh);
  refresh();
})();

// Refresh only the group card, preserving forms elsewhere on the dashboard.
if (document.querySelector('[data-group-status]')) {
  let refreshingGroups = false;
  setInterval(async () => {
    if (document.hidden || refreshingGroups) return;
    refreshingGroups = true;
    try {
      const response = await fetch(location.href, {credentials: 'same-origin'});
      if (!response.ok) return;
      const doc = new DOMParser().parseFromString(await response.text(), 'text/html');
      const next = doc.querySelector('[data-group-status]');
      const current = document.querySelector('[data-group-status]');
      if (next && current && !current.contains(document.activeElement)) {
        const query = current.querySelector(".filter-input")?.value || "";
        current.replaceWith(next);
        const table = next.querySelector('table');
        if (table) {
          const filter = document.createElement('input');
          filter.type = 'search'; filter.className = 'filter-input';
          filter.placeholder = '筛选当前表格'; filter.setAttribute('aria-label', '筛选当前表格');
          filter.value = query;
          const apply = () => table.querySelectorAll('tbody tr').forEach(row => row.hidden = !row.textContent.toLowerCase().includes(filter.value.toLowerCase()));
          filter.addEventListener('input', apply); table.parentElement.before(filter); apply();
        }
      }
    } catch (_) {} finally { refreshingGroups = false; }
  }, 3000);
}
