"use strict";
(() => {
  if (!document.querySelector("[data-token-bot]")) return;
  let token = '', timer, epoch = 0;
  const dialog = document.createElement('dialog');
  dialog.innerHTML = '<form method="dialog"><h2>查看自己的 Bot Token</h2><p>输入登录密码验证，显示 1 分钟后自动隐藏。</p><label>登录密码<input type="password" autocomplete="current-password" name="password"></label><p role="alert"></p><code></code><div><button type="button" data-reveal>验证并查看</button><button type="button" data-copy hidden>复制</button><button>关闭并隐藏</button></div></form>';
  document.body.append(dialog);
  const clear = () => { ++epoch; token = ''; clearTimeout(timer); dialog.querySelector('code').textContent = ''; dialog.querySelector('input').value = ''; dialog.querySelector('[data-copy]').hidden = true; };
  dialog.addEventListener('close', clear);
  window.addEventListener('pagehide', () => { clear(); dialog.close(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) {clear(); dialog.close();} });
  document.querySelectorAll('[data-token-bot]').forEach(button => button.onclick = () => {
    clear(); dialog.dataset.bot = button.dataset.tokenBot;
    dialog.querySelector('[role=alert]').textContent = ''; dialog.showModal();
  });
  dialog.querySelector('[data-reveal]').onclick = async () => {
    const generation = ++epoch;
    const body = new URLSearchParams({password: dialog.querySelector('input').value, csrf_token: document.querySelector('[name=csrf_token]')?.value || ''});
    dialog.querySelector('input').value = '';
    try {
      const response = await fetch(`/bots/${dialog.dataset.bot}/token/reveal`, {method:'POST', body, cache:'no-store'});
      const data = await response.json();
      if (generation !== epoch || !dialog.open) return;
      if (!response.ok) throw Error(data.error || '验证失败');
      token = data.token; data.token = '';
      dialog.querySelector('code').textContent = token;
      dialog.querySelector('[data-copy]').hidden = false;
      clearTimeout(timer); timer = setTimeout(clear, 60000);
    } catch (error) { if (generation === epoch) dialog.querySelector('[role=alert]').textContent = error.message; }
  };
  dialog.querySelector('[data-copy]').onclick = async () => {
    if (!token) return;
    try { await navigator.clipboard.writeText(token); dialog.querySelector('[role=alert]').textContent = '已复制'; }
    catch { dialog.querySelector('[role=alert]').textContent = '浏览器无法复制，请使用 HTTPS 或手动选中复制。'; }
  };
})();
