#!/usr/bin/env bash
# Read-only TGAdBot server preflight. Does not restart, modify, or deploy anything.
set -Eeuo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="${TGADBOT_ROOT_DIR:-$APP_DIR}"
if [[ ! -d "$ROOT_DIR" ]]; then
  echo "ERROR: TGADBOT_ROOT_DIR must name an existing installation directory." >&2
  exit 1
fi
ROOT_DIR="$(cd "$ROOT_DIR" && pwd)"
PROJECT_NAME="${COMPOSE_PROJECT_NAME:-tgadbot}"
CONTAINER_NAME="${TGADBOT_CONTAINER:-}"
FAILURES=0

pass() { printf '[PASS] %s\n' "$1"; }
warn() { printf '[WARN] %s\n' "$1"; }
fail() { printf '[FAIL] %s\n' "$1"; FAILURES=$((FAILURES + 1)); }

echo "TGAdBot CentOS 9 read-only preflight"
echo "Time: $(date -Is)"
if [[ -r /etc/os-release ]]; then
  . /etc/os-release
  echo "OS: ${PRETTY_NAME:-unknown}"
else
  warn "无法读取 /etc/os-release"
fi

if ! command -v docker >/dev/null 2>&1; then
  fail "未安装 Docker"
  exit 2
fi
if ! docker info >/dev/null 2>&1; then
  fail "当前用户无法访问 Docker daemon；请使用受控 sudo/root 执行"
  exit 2
fi
pass "Docker daemon 可访问"
docker --version
if docker compose version >/dev/null 2>&1; then
  pass "Docker Compose v2 可用"
  docker compose version
else
  fail "Docker Compose v2 不可用"
  exit 2
fi

COMPOSE_FILE=""
for candidate in \
  "$ROOT_DIR/compose.tgadbot.production.yaml" \
  "$ROOT_DIR/compose.tgadbot.yaml" \
  "$ROOT_DIR/compose.yaml"; do
  if [[ -f "$candidate" ]]; then COMPOSE_FILE="$candidate"; break; fi
done
if [[ -z "$COMPOSE_FILE" ]]; then
  fail "未找到现有 Compose 文件（不修改任何文件）"
  exit 2
fi
pass "发现 Compose 文件：$(basename "$COMPOSE_FILE")"
if ! docker compose -p "$PROJECT_NAME" -f "$COMPOSE_FILE" config --quiet; then
  fail "当前 Compose 配置校验失败"
else
  pass "当前 Compose 配置校验通过"
fi

if [[ -z "$CONTAINER_NAME" ]]; then
  CONTAINER_ID="$(docker compose -p "$PROJECT_NAME" -f "$COMPOSE_FILE" ps -q tgadbot 2>/dev/null || true)"
  if [[ -n "$CONTAINER_ID" ]]; then
    CONTAINER_NAME="$(docker inspect -f '{{.Name}}' "$CONTAINER_ID" 2>/dev/null | sed 's#^/##' || true)"
  fi
fi
if [[ -z "$CONTAINER_NAME" ]]; then
  for candidate in tgadbot "${PROJECT_NAME}-tgadbot-1" tgadbot-tgadbot-1; do
    if docker inspect "$candidate" >/dev/null 2>&1; then CONTAINER_NAME="$candidate"; break; fi
  done
fi
if [[ -z "$CONTAINER_NAME" ]] || ! docker inspect "$CONTAINER_NAME" >/dev/null 2>&1; then
  fail "找不到 TGAdBot 容器；请核对 COMPOSE_PROJECT_NAME 或 TGADBOT_CONTAINER"
  exit 2
fi
pass "找到容器：$CONTAINER_NAME"
docker inspect -f 'Container status: {{.State.Status}}; health: {{if .State.Health}}{{.State.Health.Status}}{{else}}not-configured{{end}}; image: {{.Config.Image}}' "$CONTAINER_NAME"
echo "Published ports:"
docker port "$CONTAINER_NAME" 2>/dev/null || true
echo "Mounts:"
docker inspect -f '{{range .Mounts}}{{printf "%s %s -> %s rw=%v\n" .Type .Source .Destination .RW}}{{end}}' "$CONTAINER_NAME"
DATA_MOUNT="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/data"}}{{.Type}} {{.Source}} rw={{.RW}}{{end}}{{end}}' "$CONTAINER_NAME")"
if [[ -n "$DATA_MOUNT" ]]; then
  pass "/data 持久化挂载：$DATA_MOUNT"
else
  fail "容器没有 /data 持久化挂载；禁止执行升级"
fi

if [[ -f "$ROOT_DIR/.env" ]]; then
  pass "发现 .env（只检查存在性，不读取或输出内容）"
else
  warn "未在项目根目录发现 .env"
fi
if [[ -d "$ROOT_DIR/backups" && -w "$ROOT_DIR/backups" ]]; then
  pass "backups 目录存在且可写"
else
  warn "backups 目录不存在或当前用户不可写；升级前需确认备份空间和权限"
fi
df -h "$ROOT_DIR" | tail -n 1

if command -v getent >/dev/null 2>&1 && getent hosts api.telegram.org >/dev/null 2>&1; then
  pass "宿主机 DNS 可解析 api.telegram.org"
else
  fail "宿主机 DNS 无法解析 api.telegram.org"
fi
HTTP_STATUS_FILE="$(mktemp)"
CURL_ERROR_FILE="$(mktemp)"
if command -v curl >/dev/null 2>&1 && curl -sS -o /dev/null -w '%{http_code}' --connect-timeout 5 --max-time 10 https://api.telegram.org >"$HTTP_STATUS_FILE" 2>"$CURL_ERROR_FILE"; then
  HTTP_STATUS="$(cat "$HTTP_STATUS_FILE")"
  pass "宿主机可建立 Telegram HTTPS 连接（HTTP $HTTP_STATUS；未调用 Bot Token）"
else
  fail "宿主机无法建立 api.telegram.org:443 HTTPS 连接"
  if [[ -s "$CURL_ERROR_FILE" ]]; then sed 's/^/  /' "$CURL_ERROR_FILE"; fi
fi
rm -f "$HTTP_STATUS_FILE" "$CURL_ERROR_FILE"

if docker exec -i "$CONTAINER_NAME" python - <<'PY'
import socket
import urllib.error
import urllib.request

socket.getaddrinfo("api.telegram.org", 443)
try:
    response = urllib.request.urlopen("https://api.telegram.org", timeout=10)
    print(f"Container Telegram HTTPS reachable (HTTP {response.status}; no Bot Token used)")
except urllib.error.HTTPError as error:
    print(f"Container Telegram HTTPS reachable (HTTP {error.code}; no Bot Token used)")
PY
then
  pass "容器内 DNS 与 Telegram HTTPS 正常"
else
  fail "容器内无法解析 api.telegram.org 或无法建立 HTTPS 连接"
fi

echo
echo "Preflight summary: failures=$FAILURES"
echo "本脚本只读，不会停止/重启容器、修改配置、执行数据库迁移或部署。"
if [[ "$FAILURES" -gt 0 ]]; then
  echo "存在阻塞项；不要运行 upgrade.sh。"
  exit 2
fi
echo "只读检查通过；仍需人工确认这是测试服务器并确认备份后，才可进行升级验收。"
