"""Allowlisted Telegram collection and bounded, resumable Desktop JSON/ZIP imports."""
from contextlib import nullcontext
from datetime import date
import hashlib
import io
import json
import mimetypes
import os
from pathlib import Path, PurePosixPath
import secrets
import shutil
import zipfile
from flask import request, abort, redirect, flash

SCHEMA = """
CREATE TABLE IF NOT EXISTS collection_sources(bot_id INTEGER NOT NULL,chat_id INTEGER NOT NULL,title TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(bot_id,chat_id));
CREATE TABLE IF NOT EXISTS materials(id INTEGER PRIMARY KEY,bot_id INTEGER NOT NULL,source_chat_id INTEGER NOT NULL,source_message_id INTEGER NOT NULL,version INTEGER NOT NULL DEFAULT 1,payload TEXT NOT NULL,complete INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL,UNIQUE(bot_id,source_chat_id,source_message_id));
CREATE TABLE IF NOT EXISTS material_versions(material_id INTEGER NOT NULL,version INTEGER NOT NULL,payload TEXT NOT NULL,PRIMARY KEY(material_id,version));
CREATE TABLE IF NOT EXISTS imports(id TEXT PRIMARY KEY,bot_id INTEGER NOT NULL,owner_user_id TEXT NOT NULL,path TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'paused',cursor INTEGER NOT NULL DEFAULT 0,total INTEGER NOT NULL,added INTEGER NOT NULL DEFAULT 0,duplicates INTEGER NOT NULL DEFAULT 0,incomplete INTEGER NOT NULL DEFAULT 0,error TEXT);
"""

# --- rc.5: 统一媒体分类（animation 必须先于 document 判定）---
MEDIA_KINDS = ("photo", "video", "animation", "audio", "voice", "video_note", "sticker", "document")
MEDIA_SEND_METHODS = {"photo": "sendPhoto", "video": "sendVideo", "animation": "sendAnimation", "audio": "sendAudio", "voice": "sendVoice", "video_note": "sendVideoNote", "sticker": "sendSticker", "document": "sendDocument"}
CAPTIONLESS_KINDS = {"sticker", "video_note"}
CONTENT_MODE_LABELS = {"text": "文字", "photo": "图片", "video": "视频", "animation": "动图", "document": "文件", "audio": "音频", "voice": "语音", "video_note": "视频笔记", "sticker": "贴纸"}
DESKTOP_MEDIA_KINDS = {"video_file": "video", "animation": "animation", "audio_file": "audio", "voice_message": "voice", "video_message": "video_note", "sticker": "sticker"}
_IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff", ".heic", ".heif"}
_VIDEO_EXTS = {".mp4", ".mov", ".webm", ".mkv", ".avi", ".m4v", ".mpeg", ".mpg", ".3gp"}
_AUDIO_EXTS = {".mp3", ".m4a", ".ogg", ".oga", ".opus", ".wav", ".flac", ".aac", ".wma"}
def document_category(mime_type, file_name):
    mime = (mime_type or "").strip().lower()
    if mime.startswith("image/"): return "image"
    if mime.startswith("video/"): return "video"
    if mime.startswith("audio/"): return "audio"
    ext = os.path.splitext(file_name or "")[1].lower()
    if ext in _IMAGE_EXTS: return "image"
    if ext in _VIDEO_EXTS: return "video"
    if ext in _AUDIO_EXTS: return "audio"
    return "file"
def media_label(media_type, mime_type=None, file_name=None):
    if media_type == "document":
        return {"image": "图片文件", "video": "视频文件", "audio": "音频文件", "file": "文件"}[document_category(mime_type, file_name)]
    return CONTENT_MODE_LABELS.get(media_type, "媒体")
def classify_media(message):
    for kind in MEDIA_KINDS:
        value = message.get(kind)
        if kind == "photo":
            if isinstance(value, list) and value:
                photos = [p for p in value if isinstance(p, dict) and p.get("file_id")]
                if photos: return "photo", max(photos, key=lambda item: int(item.get("file_size") or 0))
            continue
        if isinstance(value, dict) and value.get("file_id"): return kind, value
    return None, None
def media_field_present(message):
    for kind in MEDIA_KINDS:
        value = message.get(kind)
        if kind == "photo" and isinstance(value, list) and value: return True
        if kind != "photo" and isinstance(value, dict) and value: return True
    return False
DIAG_COLUMNS = {
    "last_update_at": "TEXT",
    "last_collected_at": "TEXT",
    "last_error_at": "TEXT",
    "last_error": "TEXT",
    "status_text": "TEXT NOT NULL DEFAULT 'Telegram 未送达更新'",
}


def migrate(c):
    for sql in SCHEMA.split(';'):
        if sql.strip():
            c.execute(sql)
    cols = {r[1] for r in c.execute("PRAGMA table_info(collection_sources)").fetchall()}
    for col, col_def in DIAG_COLUMNS.items():
        if col not in cols:
            c.execute(f"ALTER TABLE collection_sources ADD COLUMN {col} {col_def}")


def allowed(a, bot_id, chat_id):
    with a.db() as c:
        return c.execute(
            "SELECT 1 FROM collection_sources s JOIN bots b ON b.id=s.bot_id "
            "WHERE s.bot_id=? AND s.chat_id=? AND s.enabled=1 AND b.status='active'",
            (bot_id, chat_id),
        ).fetchone() is not None


def _record_source_diag(c, bot_id, chat_id, *, now_ts, status_text, collected=False, error=None):
    if error:
        c.execute(
            """UPDATE collection_sources
               SET last_update_at=?, last_error_at=?, last_error=?, status_text=?
               WHERE bot_id=? AND chat_id=?""",
            (now_ts, now_ts, error[:200], status_text, bot_id, chat_id),
        )
    elif collected:
        c.execute(
            """UPDATE collection_sources
               SET last_update_at=?, last_collected_at=?, last_error=NULL, status_text=?
               WHERE bot_id=? AND chat_id=?""",
            (now_ts, now_ts, status_text, bot_id, chat_id),
        )
    else:
        c.execute(
            """UPDATE collection_sources
               SET last_update_at=?, status_text=?
               WHERE bot_id=? AND chat_id=?""",
            (now_ts, status_text, bot_id, chat_id),
        )


def _has_collectible_content(message):
    if (message.get("text") or "").strip() or (message.get("caption") or "").strip():
        return True
    kind, _media = classify_media(message)
    return kind is not None


def _has_valid_media(message):
    if not media_field_present(message):
        return True
    kind, media = classify_media(message)
    return bool(kind and media and media.get("file_id"))


def collect(a, bot_id, message, *, complete=True, require_source=False, connection=None):
    chat_id = int(message['chat']['id'])
    message_id = int(message['message_id'])
    payload = json.dumps(message, ensure_ascii=False, sort_keys=True)
    now_ts = a.now()
    with (a.db() if connection is None else nullcontext(connection)) as c:
        if connection is None:
            c.execute('BEGIN IMMEDIATE')
        bot = c.execute("SELECT id FROM bots WHERE id=? AND status='active'", (bot_id,)).fetchone()
        if require_source:
            if not bot:
                return False
            src = c.execute(
                "SELECT enabled FROM collection_sources WHERE bot_id=? AND chat_id=?",
                (bot_id, chat_id),
            ).fetchone()
            if not src:
                return False
            if not int(src["enabled"]):
                _record_source_diag(
                    c, bot_id, chat_id, now_ts=now_ts,
                    status_text="来源未启用", error="来源未启用，收到更新未采集"
                )
                return False
            if not _has_valid_media(message):
                _record_source_diag(
                    c, bot_id, chat_id, now_ts=now_ts,
                    status_text="媒体读取失败", error="媒体读取失败：缺少有效 file_id"
                )
                return False
            if not _has_collectible_content(message):
                _record_source_diag(
                    c, bot_id, chat_id, now_ts=now_ts,
                    status_text="消息类型不支持", error="消息类型不支持（支持文字、图片、视频、动图、文件、音频、语音、视频笔记、贴纸）"
                )
                return False
        if not bot:
            raise ValueError('机器人已停用')
        try:
            c.execute("SAVEPOINT sp_collect_write")
            old = c.execute(
                """SELECT m.* FROM materials m JOIN bots b ON b.id=m.bot_id
                   WHERE b.owner_user_id=(SELECT owner_user_id FROM bots WHERE id=?)
                   AND m.source_chat_id=? AND m.source_message_id=? ORDER BY m.id LIMIT 1""",
                (bot_id, chat_id, message_id),
            ).fetchone()
            if old and '_desktop' in message and (old['complete'] or not complete):
                c.execute("RELEASE SAVEPOINT sp_collect_write")
                return False
            if old and old['payload'] == payload and old['complete'] == int(complete):
                if old['bot_id'] != bot_id:
                    c.execute("UPDATE materials SET bot_id=? WHERE id=?", (bot_id, old['id']))
                    if complete:
                        a.remember_media_message(bot_id, message, connection=c)
                if require_source:
                    _record_source_diag(
                        c, bot_id, chat_id, now_ts=now_ts,
                        status_text="采集正常（重复消息已去重）", collected=True
                    )
                c.execute("RELEASE SAVEPOINT sp_collect_write")
                return False
            if old:
                c.execute(
                    'INSERT OR IGNORE INTO material_versions VALUES(?,?,?)',
                    (old['id'], old['version'], old['payload']),
                )
                c.execute(
                    'UPDATE materials SET payload=?,complete=?,version=version+1,updated_at=?,bot_id=? WHERE id=?',
                    (payload, int(complete), now_ts, bot_id, old['id']),
                )
            else:
                c.execute(
                    'INSERT INTO materials(bot_id,source_chat_id,source_message_id,payload,complete,updated_at) VALUES(?,?,?,?,?,?)',
                    (bot_id, chat_id, message_id, payload, int(complete), now_ts),
                )
            if complete:
                a.remember_media_message(bot_id, message, connection=c)
            if require_source:
                _record_source_diag(
                    c, bot_id, chat_id, now_ts=now_ts,
                    status_text="采集正常", collected=True
                )
            c.execute("RELEASE SAVEPOINT sp_collect_write")
        except Exception as exc:
            c.execute("ROLLBACK TO SAVEPOINT sp_collect_write")
            c.execute("RELEASE SAVEPOINT sp_collect_write")
            if require_source:
                _record_source_diag(
                    c, bot_id, chat_id, now_ts=now_ts,
                    status_text="写库失败", error=f"写库失败：{type(exc).__name__}"
                )
            raise
    return True


def verify_source_permissions(a, bot_id, chat_id):
    """Verify bot membership and read permissions when saving a source."""
    with a.db() as c:
        bot = c.execute("SELECT token,telegram_id FROM bots WHERE id=? AND status='active'", (bot_id,)).fetchone()
        chat = c.execute("SELECT chat_type,title FROM chats WHERE bot_id=? AND chat_id=?", (bot_id, chat_id)).fetchone()
    if not bot:
        return False, "机器人已停用或不存在"
    chat_type = (chat["chat_type"] if chat else "") or "supergroup"
    try:
        token = a.decrypt_token(bot["token"])
        member = a.api(token, "getChatMember", {"chat_id": chat_id, "user_id": bot["telegram_id"]}, timeout=8)
        status = member.get("status")
        if status in ("left", "kicked"):
            return False, "机器人已不在该群组或频道内，请重新邀请后再试"
        if chat_type == "channel" and status not in ("administrator", "creator"):
            return False, "频道来源需授予机器人管理员权限并允许接收频道消息"
        if chat_type in ("group", "supergroup") and status == "member":
            return True, "来源已启用（提示：群组普通消息需在 BotFather 关闭隐私模式或授予机器人管理员权限）"
        return True, "来源已启用，机器人群内权限正常"
    except Exception:
        # In offline/mock environments where getChatMember is not stubbed, keep default ready notice.
        if chat_type == "channel":
            return True, "Telegram 未送达更新（频道需授予管理员权限并允许接收消息）"
        return True, "Telegram 未送达更新（群组需关闭 BotFather 隐私模式或授予管理员权限）"


def prepare_import(data, root, *, chat_id=None, date_from=None, date_to=None):
    """Never extract supplied paths; save allowed media under generated filenames."""
    root = Path(root); root.mkdir(parents=True, exist_ok=False)
    media = {}
    if zipfile.is_zipfile(io.BytesIO(data)):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            entries = z.infolist()
            if len(entries) > 2000 or sum(e.file_size for e in entries) > 200 * 1024 * 1024:
                raise ValueError('导入包最多 2000 个文件、解压后 200 MB')
            names = set()
            for e in entries:
                p = PurePosixPath(e.filename.replace('\\', '/'))
                if p.is_absolute() or '..' in p.parts or ':' in e.filename or e.flag_bits & 1 or (e.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError('ZIP 含有不安全路径或符号链接')
                if str(p) in names: raise ValueError('ZIP 含重复路径')
                names.add(str(p))
                if e.file_size > 50 * 1024 * 1024 or (e.compress_size and e.file_size / e.compress_size > 300):
                    raise ValueError('文件过大或压缩比异常')
            candidates = [e for e in entries if PurePosixPath(e.filename).name == 'result.json']
            if len(candidates) != 1: raise ValueError('ZIP 需要且只能包含一个 Telegram Desktop result.json')
            if candidates[0].file_size > 20 * 1024 * 1024: raise ValueError('JSON 超过 20 MB')
            document = json.loads(z.read(candidates[0]))
            base = PurePosixPath(candidates[0].filename).parent
            referenced = {name for message in document.get('messages', []) if isinstance(message, dict)
                          for name in (message.get('photo'), message.get('file')) if isinstance(name, str)}
            for e in entries:
                if e.is_dir():
                    continue
                p = PurePosixPath(e.filename)
                try: relative = str(p.relative_to(base))
                except ValueError: continue
                if relative not in referenced:
                    continue
                suffix = p.suffix.lower()
                name = hashlib.sha256(e.filename.encode()).hexdigest() + (suffix if suffix.isascii() and suffix[1:].isalnum() and len(suffix) <= 12 else '')
                output = root / name
                with output.open('xb') as f: f.write(z.read(e))
                media[relative] = str(output)
    else:
        if len(data) > 20 * 1024 * 1024: raise ValueError('JSON 超过 20 MB')
        document = json.loads(data)
    if not isinstance(document, dict) or not isinstance(document.get('messages'), list) or not document.get('id'):
        raise ValueError('请选择 Telegram Desktop 单个聊天的 JSON 导出包')
    if len(document['messages']) > 100000: raise ValueError('单批最多 100000 条消息')
    if chat_id is not None:
        export_id = int(document['id'])
        expected_ids = {export_id}
        if export_id > 0:
            chat_type = str(document.get('type', ''))
            if 'channel' in chat_type or 'supergroup' in chat_type:
                expected_ids.add(-1_000_000_000_000 - export_id)
            elif 'group' in chat_type:
                expected_ids.add(-export_id)
        if chat_id not in expected_ids:
            raise ValueError('导出文件的聊天 ID 与选定来源不符')
        document['id'] = chat_id
    if date_from or date_to:
        start = date.fromisoformat(date_from) if date_from else date.min
        end = date.fromisoformat(date_to) if date_to else date.max
        if start > end:
            raise ValueError('开始日期必须早于或等于结束日期')
        filtered = []
        for message in document['messages']:
            if not isinstance(message, dict) or message.get('type') != 'message':
                continue
            try:
                day = date.fromisoformat(str(message.get('date', ''))[:10])
            except ValueError:
                continue
            if start <= day <= end:
                filtered.append(message)
        document['messages'] = filtered
    document['_media'] = media
    manifest = root / 'manifest.json'
    manifest.write_text(json.dumps(document, ensure_ascii=False), encoding='utf-8')
    return manifest, len(document['messages'])


def process_batch(a, ident, owner):
    try:
        with a.db() as c:
            c.execute('BEGIN IMMEDIATE')
            row = c.execute('SELECT * FROM imports WHERE id=? AND owner_user_id=?', (ident, owner)).fetchone()
            if not row:
                raise PermissionError()
            if row['status'] in ('completed', 'cancelled', 'running'):
                return
            document = json.loads(Path(row['path']).read_text(encoding='utf-8'))
            added = duplicate = incomplete = 0
            end = min(row['cursor'] + 100, row['total'])
            for original in document['messages'][row['cursor']:end]:
                if not isinstance(original, dict) or original.get('type') != 'message':
                    continue
                message = desktop_message(document, original)
                complete = message.pop('_import_complete')
                changed = collect(a, row['bot_id'], message, complete=complete, connection=c)
                added += int(changed)
                duplicate += int(not changed)
                incomplete += int(not complete)
            c.execute(
                "UPDATE imports SET status=?,cursor=?,added=added+?,duplicates=duplicates+?,incomplete=incomplete+?,error=NULL WHERE id=?",
                ('completed' if end == row['total'] else 'paused', end, added, duplicate, incomplete, ident),
            )
    except Exception as exc:
        with a.db() as c:
            c.execute("UPDATE imports SET error=? WHERE id=? AND owner_user_id=? AND status='paused'",
                      (type(exc).__name__, ident, owner))
        raise


def desktop_message(document, original):
    text = original.get('text', '')
    if isinstance(text, list):
        text = ''.join(part if isinstance(part, str) else str(part.get('text', ''))
                       for part in text if isinstance(part, (str, dict)))
    message = {
        'message_id': int(original['id']),
        'chat': {'id': int(document['id']), 'title': document.get('name', '导入聊天')},
        'text': text,
        'date': original.get('date_unixtime'),
        '_desktop': original,
        '_import_complete': True,
    }
    filename = original.get('photo') or original.get('file')
    if filename:
        local = document['_media'].get(filename)
        message['_import_complete'] = bool(local)
        if local:
            kind = 'photo' if original.get('photo') else DESKTOP_MEDIA_KINDS.get(original.get('media_type'), 'document')
            media = {'file_id': 'local:' + local, 'file_name': PurePosixPath(filename).name,
                     'mime_type': mimetypes.guess_type(filename)[0]}
            message[kind] = [media] if kind == 'photo' else media
            message['caption'] = text
            message['_local_media'] = local
    return message


def install(a):
    @a.app.post('/library/materials/<int:ident>/use')
    @a.login_required
    def use_material(ident):
        with a.db() as c:
            material=c.execute("SELECT m.* FROM materials m JOIN bots b ON b.id=m.bot_id WHERE m.id=? AND b.owner_user_id=? AND b.status='active'",(ident,a.current_owner_id())).fetchone()
            if not material: abort(404)
            if not material['complete']:
                flash('素材缺失媒体，请补齐后再发送。')
                return redirect('/library')
            message=json.loads(material['payload'])
            ids=c.execute('SELECT id FROM media_assets WHERE bot_id=? AND ((source_chat_id=? AND source_message_id=?) OR file_unique_id=?)',
                          (material['bot_id'],material['source_chat_id'],material['source_message_id'],f"desktop:{material['source_chat_id']}:{material['source_message_id']}")).fetchall()
            assets=a.load_selected_media_assets(c,material['bot_id'],[r[0] for r in ids])
            modes=sorted({x['type'] for x in assets}) if assets else ['text']
            config={'bot_ids':[str(material['bot_id'])],'chat_targets':[], 'body':message.get('text','') if not assets else '',
                    'content_modes':modes,'media_assets':{str(material['bot_id']):assets},'buttons':[], 'send_gap_seconds':a.platform_send_gap_seconds()}
            template=c.execute('INSERT INTO task_templates(title,config_json,created_at,owner_user_id) VALUES(?,?,?,?)',
                               (f'素材 #{ident} · v{material["version"]}',json.dumps(config,ensure_ascii=False),a.now(),a.current_owner_id())).lastrowid
        return redirect(f'/broadcast?template_id={template}')

    @a.app.route('/library',methods=['GET','POST'])
    @a.login_required
    def library():
        owner = a.current_owner_id()
        with a.db() as c:
            bots = c.execute("SELECT id,username FROM bots WHERE owner_user_id=? AND status='active'",(owner,)).fetchall()
        if request.method == 'POST':
            if request.form.get('action') != 'source':
                abort(410)
            try:
                bot_id = int(request.form['bot_id'])
                if bot_id not in {b['id'] for b in bots}: abort(403)
                if request.form.get('action') == 'source':
                    chat_id = int(request.form['chat_id'])
                    enabled_flag = int(request.form.get('enabled') == 'on')
                    with a.db() as c:
                        c.execute("BEGIN IMMEDIATE")
                        selected = c.execute("SELECT title,chat_type FROM chats WHERE bot_id=? AND chat_id=? AND status='active'", (bot_id,chat_id)).fetchone()
                        if not selected:
                            abort(400)
                    ok_perm, perm_msg = verify_source_permissions(a, bot_id, chat_id) if enabled_flag else (True, "来源未启用")
                    status_text = perm_msg if enabled_flag else "来源未启用"
                    last_err = None if ok_perm else perm_msg
                    with a.db() as c:
                        c.execute("BEGIN IMMEDIATE")
                        selected = c.execute("SELECT title FROM chats WHERE bot_id=? AND chat_id=? AND status='active'", (bot_id,chat_id)).fetchone()
                        if not selected:
                            abort(400)
                        c.execute("UPDATE collection_sources SET enabled=0,status_text='来源未启用' WHERE chat_id=? AND bot_id IN (SELECT id FROM bots WHERE owner_user_id=?)", (chat_id,owner))
                        title_val = (request.form.get('title','') or selected['title'])[:200]
                        c.execute(
                            """INSERT INTO collection_sources(bot_id,chat_id,title,enabled,last_error_at,last_error,status_text)
                               VALUES(?,?,?,?,?,?,?)
                               ON CONFLICT(bot_id,chat_id) DO UPDATE SET
                                 title=excluded.title,
                                 enabled=excluded.enabled,
                                 last_error_at=excluded.last_error_at,
                                 last_error=excluded.last_error,
                                 status_text=excluded.status_text""",
                            (bot_id, chat_id, title_val, enabled_flag, a.now() if last_err else None, last_err, status_text),
                        )
                    flash(f'采集来源已保存（{status_text}）。')
                else:
                    abort(410)
            except (ValueError,KeyError): flash('来源配置无效，请重新选择机器人和群组。')
            return redirect('/library')
        q=request.args.get('q','')[:200]
        try: page=max(1,int(request.args.get('page','1')))
        except ValueError: page=1
        with a.db() as c:
            sources=c.execute('SELECT s.*, b.username AS bot_username FROM collection_sources s JOIN bots b ON b.id=s.bot_id WHERE b.owner_user_id=? ORDER BY s.enabled DESC, s.bot_id, s.chat_id',(owner,)).fetchall()
            materials=c.execute('SELECT m.*, b.username AS bot_username FROM materials m JOIN bots b ON b.id=m.bot_id WHERE b.owner_user_id=? AND m.payload LIKE ? ORDER BY m.id DESC LIMIT 50 OFFSET ?', (owner,'%'+q+'%',(page-1)*50)).fetchall()
            imports = c.execute('SELECT * FROM imports WHERE owner_user_id=? ORDER BY rowid DESC LIMIT 30', (owner,)).fetchall()
            available = c.execute("SELECT ch.* FROM chats ch JOIN bots b ON b.id=ch.bot_id WHERE b.owner_user_id=? AND b.status='active' AND ch.status='active' ORDER BY ch.title", (owner,)).fetchall()
        material_labels = {}
        for m in materials:
            try: payload = json.loads(m['payload'])
            except (TypeError, ValueError): payload = {}
            if not isinstance(payload, dict): payload = {}
            kind, media = classify_media(payload)
            if kind: material_labels[m['id']] = media_label(kind, (media or {}).get('mime_type'), (media or {}).get('file_name'))
            elif str(payload.get('text') or payload.get('caption') or '').strip(): material_labels[m['id']] = '文字'
            else: material_labels[m['id']] = '其他'
        return a.page("{% include 'library.html' %}",available=available,bots=bots,sources=sources,materials=materials,material_labels=material_labels,imports=imports,q=q,page_number=page)

    @a.app.post('/library/imports')
    @a.login_required
    def start_import():
        owner = a.current_owner_id()
        upload = request.files.get('history')
        if not upload or not upload.filename:
            abort(400)
        try:
            bot_id = int(request.form['bot_id'])
            chat_id = int(request.form['chat_id'])
        except (KeyError, ValueError):
            abort(400)
        with a.db() as c:
            allowed = c.execute(
                "SELECT 1 FROM collection_sources s JOIN bots b ON b.id=s.bot_id "
                "WHERE s.bot_id=? AND s.chat_id=? AND b.owner_user_id=? AND b.status='active'",
                (bot_id, chat_id, owner),
            ).fetchone()
        if not allowed:
            abort(403)
        ident = secrets.token_hex(16)
        root = Path(a.MEDIA_DIR).resolve() / 'imports' / ident
        try:
            path, total = prepare_import(upload.read(), root, chat_id=chat_id,
                                         date_from=request.form.get('date_from'), date_to=request.form.get('date_to'))
            with a.db() as c:
                c.execute('BEGIN IMMEDIATE')
                if not c.execute("SELECT 1 FROM bots WHERE id=? AND owner_user_id=? AND status='active'", (bot_id, owner)).fetchone():
                    raise ValueError('机器人已停用')
                c.execute("INSERT INTO imports(id,bot_id,owner_user_id,path,total) VALUES(?,?,?,?,?)",
                          (ident, bot_id, owner, str(path), total))
        except (ValueError, TypeError, OSError, zipfile.BadZipFile) as exc:
            shutil.rmtree(root, ignore_errors=True)
            flash(str(exc) if isinstance(exc, ValueError) else '无法读取历史导出文件。')
            return redirect('/library')
        return import_action(ident, 'resume')

    @a.app.post('/library/imports/<ident>/<action>')
    @a.login_required
    def import_action(ident, action):
        owner = a.current_owner_id()
        if action != 'resume':
            abort(404)
        try:
            process_batch(a, ident, owner)
        except PermissionError:
            abort(404)
        except (ValueError, KeyError, TypeError, OSError):
            flash('导入暂停，当前批次未提交。')
        return redirect('/library')
