"""Production WSGI entrypoint. Run exactly one Gunicorn worker for this quick version."""
from app import app, init_db, start_pollers, start_delivery_worker

from app import DB_PATH
from runtime_lock import acquire
acquire(DB_PATH)
init_db()
start_pollers()
start_delivery_worker()
