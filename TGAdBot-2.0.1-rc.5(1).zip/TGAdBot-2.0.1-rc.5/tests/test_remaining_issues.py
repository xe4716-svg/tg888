import html
import json
import re
import time
import pytest
from test_runtime_storage import appmod, create_job, clean_database

HAS_FLASK_TEST_CLIENT = callable(getattr(appmod.app, "test_client", None))
requires_flask_http = pytest.mark.skipif(
    not HAS_FLASK_TEST_CLIENT,
    reason="Flask HTTP/CSRF integration requires the Flask runtime installed by CI",
)


def client_for(uid=None):
    appmod.app.config.update(TESTING=True, WTF_CSRF_ENABLED=False)
    client=appmod.app.test_client()
    with client.session_transaction() as s:
        s.update(authenticated=True,auth_method='local_password' if uid else 'admin_password',is_admin=not uid)
        if uid: s['user_id']=uid
    return client


def test_inline_rows_and_utf8_callback_limits():
    rows=appmod.parse_buttons(json.dumps({'rows':[[{'text':'网址','kind':'URL','target':'https://example.com'},{'text':'回调','kind':'CALLBACK','target':'中'*21}]]}))
    assert len(rows[0])==2 and rows[0][1]['callback_data']=='中'*21
    with pytest.raises(ValueError):
        appmod.parse_buttons(json.dumps({'rows':[[{'text':'回调','kind':'CALLBACK','target':'中'*22}]]}))
    assert appmod.parse_buttons('旧按钮 | URL | https://example.com')==[[{'text':'旧按钮','url':'https://example.com'}]]


@requires_flask_http
def test_account_password_http_minimum_and_preserved_old_hash():
    uid=appmod.create_local_user('password-boundary@example.com','oldpass')
    client=client_for(uid)
    html=client.get('/account').get_data(as_text=True)
    assert 'name="new_password" minlength="6"' in html
    with appmod.db() as c: old=c.execute('SELECT password_hash FROM user_accounts WHERE id=?',(uid,)).fetchone()[0]
    data={'email':'password-boundary@example.com','current_password':'oldpass','new_password':'12345','password_confirm':'12345'}
    assert '至少需要 6' in client.post('/account',data=data).get_data(as_text=True)
    with appmod.db() as c: assert c.execute('SELECT password_hash FROM user_accounts WHERE id=?',(uid,)).fetchone()[0]==old
    data.update(new_password='123456',password_confirm='123456')
    assert client.post('/account',data=data).status_code==302
    assert appmod.authenticate_local_user(data['email'],'123456')['id']==uid


def test_reply_keyboard_real_send_payload_keeps_ad(monkeypatch):
    calls=[]
    monkeypatch.setattr(appmod,'api',lambda token,method,payload: calls.append((method,payload)) or {'message_id':1})
    markup=appmod.parse_buttons(json.dumps({'mode':'reply','rows':[[{'text':'帮助'}]]}))
    appmod.send_one('fake',1,'内容',markup,'BOTH','广告','官方','https://example.com')
    assert calls[0][1]['reply_markup']['keyboard']==[[{'text':'帮助'}]]
    assert '广告' in calls[0][1]['text'] and 'https://example.com' in calls[0][1]['text']


@requires_flask_http
def test_announcement_crud_schedule_pin_disable_and_group():
    admin=client_for()
    with appmod.db() as c: c.execute('DELETE FROM announcements')
    assert admin.post('/admin/announcements',data={'title':'测试公告','body':'正文','enabled':'on','pinned':'on'}).status_code==302
    with appmod.db() as c:
        item=c.execute('SELECT * FROM announcements').fetchone()
    assert item['pinned']==1
    assert '测试公告' in admin.get('/').get_data(as_text=True)
    admin.post('/admin/announcements',data={'id':item['id'],'title':'未来公告','body':'正文','enabled':'on','published_at':int(time.time())+3600})
    assert '未来公告' not in admin.get('/').get_data(as_text=True)
    admin.post('/admin/announcements',data={'action':'group','official_group_url':'https://t.me/test_group'})
    assert 'https://t.me/test_group' in admin.get('/').get_data(as_text=True)
    admin.post('/admin/announcements',data={'action':'group','official_group_url':'javascript:alert(1)'})
    assert appmod.setting('official_group_url')=='https://t.me/test_group'
    admin.post('/admin/announcements',data={'id':item['id'],'title':'停用公告','body':'正文'})
    assert '停用公告' not in admin.get('/').get_data(as_text=True)
    admin.post('/admin/announcements',data={'id':item['id'],'action':'delete'})
    with appmod.db() as c: assert c.execute('SELECT COUNT(*) FROM announcements').fetchone()[0]==0


@requires_flask_http
def test_user_permissions_and_manual_clear_preserves_queue():
    uid=appmod.create_local_user('owner@example.com','123456')
    other=appmod.create_local_user('other@example.com','123456')
    _,task,job=create_job()
    with appmod.db() as c: c.execute('UPDATE tasks SET owner_user_id=? WHERE id=?',(uid,task))
    user=client_for(uid)
    assert user.get('/admin/announcements').status_code==403
    assert user.post('/admin/announcements',data={'title':'bad'}).status_code==403
    assert client_for(other).get(f'/tasks/{task}').status_code==404
    assert user.post('/history/clear').status_code==302
    with appmod.db() as c:
        assert c.execute('SELECT status FROM delivery_jobs WHERE id=?',(job,)).fetchone()[0]=='pending'
        assert c.execute('SELECT * FROM log_visibility WHERE owner_user_id=?',(uid,)).fetchone()
        assert not c.execute('SELECT * FROM log_visibility WHERE owner_user_id=?',(other,)).fetchone()
    assert str(task) in user.get('/history').get_data(as_text=True)


def test_automatic_cleanup_exact_twelve_hour_cutoff_and_idempotent_migration():
    _,task,job=create_job()
    current=appmod.datetime.now(appmod.timezone.utc)
    appmod.cleanup_success_logs(current)
    with appmod.db() as c:
        cutoff=c.execute("SELECT hidden_before FROM log_visibility WHERE owner_user_id='legacy_admin'").fetchone()[0]
        assert cutoff==(current-appmod.timedelta(hours=12)).isoformat(timespec='seconds')
        assert c.execute('SELECT id FROM delivery_jobs WHERE id=?',(job,)).fetchone()
    appmod.init_db(); appmod.init_db()
    with appmod.db() as c: assert c.execute('SELECT id FROM tasks WHERE id=?',(task,)).fetchone()


@requires_flask_http
def test_favicon_served_and_references_approved_brand():
    client=client_for()
    assert 'rel="icon" type="image/png" href="/static/brand-approved.png"' in client.get('/').get_data(as_text=True)
    response=client.get('/static/brand-approved.png')
    assert response.status_code==200 and response.data.startswith(b'\x89PNG')


@requires_flask_http
def test_old_task_recent_delivery_keeps_full_retention_window():
    uid=appmod.create_local_user('long-running@example.com','123456')
    _,task,job=create_job()
    current=appmod.datetime.now(appmod.timezone.utc)
    old=(current-appmod.timedelta(hours=24)).isoformat(timespec='seconds')
    recent=(current-appmod.timedelta(hours=1)).isoformat(timespec='seconds')
    with appmod.db() as c:
        c.execute("UPDATE tasks SET owner_user_id=?,created_at=?,status='completed' WHERE id=?",(uid,old,task))
        c.execute("UPDATE delivery_jobs SET status='sent',updated_at=?,last_error='recent delivery marker' WHERE id=?",(recent,job))
    appmod.cleanup_success_logs(current)
    client=client_for(uid)
    assert f'/tasks/{task}' in client.get('/history').get_data(as_text=True)
    assert 'recent delivery marker' in client.get(f'/tasks/{task}').get_data(as_text=True)
    appmod.cleanup_success_logs(current+appmod.timedelta(hours=12))
    assert f'/tasks/{task}' not in client.get('/history').get_data(as_text=True)
    assert 'recent delivery marker' not in client.get(f'/tasks/{task}').get_data(as_text=True)
    with appmod.db() as c: assert c.execute('SELECT status FROM delivery_jobs WHERE id=?',(job,)).fetchone()[0]=='sent'


@requires_flask_http
def test_completed_logs_hidden_in_list_counts_and_detail_without_deleting_jobs():
    uid=appmod.create_local_user('clear@example.com','123456')
    _,task,job=create_job()
    with appmod.db() as c:
        c.execute("UPDATE tasks SET owner_user_id=?,status='completed' WHERE id=?",(uid,task))
        c.execute("UPDATE delivery_jobs SET status='sent',last_error='private log marker' WHERE id=?",(job,))
    client=client_for(uid)
    assert 'private log marker' in client.get(f'/tasks/{task}').get_data(as_text=True)
    client.post('/history/clear')
    assert f'/tasks/{task}' not in client.get('/history').get_data(as_text=True)
    assert 'private log marker' not in client.get(f'/tasks/{task}').get_data(as_text=True)
    with appmod.db() as c: assert c.execute('SELECT status FROM delivery_jobs WHERE id=?',(job,)).fetchone()[0]=='sent'


@requires_flask_http
def test_legacy_reply_task_sends_but_template_does_not_load_keyboard(monkeypatch):
    buttons={'keyboard':[[{'text':'帮助'}]],'resize_keyboard':True}
    calls=[]
    monkeypatch.setattr(appmod,'api',lambda token,method,payload: calls.append(payload) or {'message_id':1})
    appmod.send_task_content('fake',1,'正文',buttons,'BUTTON_ONLY','','广告','https://example.com',['text'],[])
    assert calls[0]['reply_markup']==buttons and 'https://example.com' in calls[0]['text']
    _,task,_=create_job()
    with appmod.db() as c: c.execute('UPDATE tasks SET buttons=? WHERE id=?',(json.dumps(buttons),task))
    client=client_for()
    assert client.post(f'/tasks/{task}/clone').status_code==302
    html=client.get('/broadcast?template_id=latest').get_data(as_text=True)
    assert '旧模板的回复键盘未载入' in html
    assert '帮助' not in html


@pytest.mark.parametrize('enabled,interval,max_runs,expected_series',[('off','15','5',False),('on','15','2',True)])
@requires_flask_http
def test_recurrence_switch_persists_first_execution_in_total(monkeypatch,enabled,interval,max_runs,expected_series):
    bot,_,_=create_job()
    with appmod.db() as c:
        c.execute("INSERT INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,1,'group','supergroup','active',?)",(bot,appmod.now()))
    monkeypatch.setattr(appmod,'start_delivery_worker',lambda:None)
    client=client_for()
    response=client.post('/broadcast',data={'bot_ids':str(bot),'chat_keys':f'{bot}:1','content_modes':'text','body':'循环','send_gap_seconds':'10','repeat_enabled':enabled,'repeat_duration_unit':'none','repeat_max_runs':max_runs})
    assert response.status_code==302
    with appmod.db() as c:
        task=c.execute('SELECT * FROM tasks ORDER BY id DESC LIMIT 1').fetchone()
        assert bool(task['series_id'])==expected_series
        if expected_series:
            series=c.execute('SELECT * FROM recurring_series WHERE id=?',(task['series_id'],)).fetchone()
            assert series['runs_created']==1 and series['max_runs']==2 and series['interval_seconds']==0 and series['loop_mode']=='continuous'


@requires_flask_http
def test_broadcast_persists_both_continuous_stop_limits(monkeypatch):
    bot_id, _, _ = create_job()
    with appmod.db() as c:
        c.execute(
            "INSERT INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,?,'combined-limit group','supergroup','active',?)",
            (bot_id, -100123, appmod.now()),
        )
    monkeypatch.setattr(appmod, "start_delivery_worker", lambda: None)
    client = client_for()
    response = client.post(
        "/broadcast",
        data={
            "bot_ids": str(bot_id),
            "chat_keys": f"{bot_id}:-100123",
            "content_modes": "text",
            "body": "combined stop conditions",
            "send_gap_seconds": "10",
            "repeat_enabled": "on",
            "repeat_duration_unit": "minutes",
            "repeat_duration_value": "5",
            "repeat_max_runs": "2",
        },
    )
    assert response.status_code == 302
    with appmod.db() as c:
        task = c.execute(
            "SELECT id,series_id FROM tasks ORDER BY id DESC LIMIT 1"
        ).fetchone()
        series = c.execute(
            "SELECT * FROM recurring_series WHERE id=?", (task["series_id"],)
        ).fetchone()
    assert task["series_id"] is not None
    assert series["loop_mode"] == "continuous"
    assert series["interval_seconds"] == 0
    assert series["runs_created"] == 1
    assert series["max_runs"] == 2
    assert series["stop_after_seconds"] == 300
    assert series["status"] == "active"


def test_malformed_button_json_returns_actionable_validation_error():
    with pytest.raises(ValueError, match="按钮配置格式无效"):
        appmod.parse_buttons('{"mode":"inline","rows":')


@requires_flask_http
def test_broadcast_buttons_persist_and_template_roundtrip_without_invalid_overwrite(monkeypatch):
    bot_id, _, _ = create_job()
    with appmod.db() as c:
        c.execute(
            "INSERT INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,?,'按钮验收群','supergroup','active',?)",
            (bot_id, -100123, appmod.now()),
        )
        before_tasks = c.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
    monkeypatch.setattr(appmod, "start_delivery_worker", lambda: None)
    client = client_for()

    expected_task_buttons = [
        [
            {"text": "官网", "url": "https://example.com"},
            {"text": "联系客服", "callback_data": "support"},
        ],
        [{"text": "帮助", "url": "https://example.com/help"}],
    ]
    editor_payload = {
        "mode": "inline",
        "rows": [
            [
                {"text": "官网", "kind": "URL", "target": "https://example.com"},
                {"text": "联系客服", "kind": "CALLBACK", "target": "support"},
            ],
            [{"text": "帮助", "kind": "URL", "target": "https://example.com/help"}],
        ],
    }
    response = client.post("/broadcast", data={
        "bot_ids": str(bot_id),
        "chat_keys": f"{bot_id}:-100123",
        "content_modes": "text",
        "body": "按钮保存验收",
        "buttons": json.dumps(editor_payload, ensure_ascii=False),
        "send_gap_seconds": "10",
        "repeat_enabled": "off",
        "repeat_duration_unit": "none",
        "repeat_max_runs": "5",
    })
    assert response.status_code == 302
    with appmod.db() as c:
        task = c.execute("SELECT id,buttons FROM tasks ORDER BY id DESC LIMIT 1").fetchone()
        assert c.execute("SELECT COUNT(*) FROM tasks").fetchone()[0] == before_tasks + 1
    task_id = task["id"]
    assert json.loads(task["buttons"]) == expected_task_buttons

    saved = client.post(f"/tasks/{task_id}/clone")
    assert saved.status_code == 302
    restored_html = client.get("/broadcast?template_id=latest").get_data(as_text=True)
    match = re.search(r'<textarea name="buttons"[^>]*>(.*?)</textarea>', restored_html, re.S)
    assert match, "button editor backing field should be present for template reuse"
    restored_editor = json.loads(html.unescape(match.group(1)))
    assert restored_editor == editor_payload

    with appmod.db() as c:
        task_count_before_invalid = c.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        template_count_before_invalid = c.execute("SELECT COUNT(*) FROM task_templates").fetchone()[0]
    invalid_payload = {
        "mode": "inline",
        "rows": [[{"text": "危险链接", "kind": "URL", "target": "javascript:alert(1)"}]],
    }
    rejected = client.post("/broadcast", data={
        "bot_ids": str(bot_id),
        "chat_keys": f"{bot_id}:-100123",
        "content_modes": "text",
        "body": "这条不应创建",
        "buttons": json.dumps(invalid_payload, ensure_ascii=False),
        "send_gap_seconds": "10",
        "repeat_enabled": "off",
    })
    assert rejected.status_code == 302
    assert "无效按钮链接" in client.get(rejected.location).get_data(as_text=True)
    rejected_reply = client.post("/broadcast", data={
        "bot_ids": str(bot_id),
        "chat_keys": f"{bot_id}:-100123",
        "content_modes": "text",
        "body": "禁止新建回复键盘",
        "buttons": json.dumps({"mode": "reply", "rows": [[{"text": "旧按钮"}]]}),
    }, follow_redirects=True)
    assert "新群发任务仅支持内联按钮" in rejected_reply.get_data(as_text=True)
    with appmod.db() as c:
        assert c.execute("SELECT COUNT(*) FROM tasks").fetchone()[0] == task_count_before_invalid
        assert c.execute("SELECT COUNT(*) FROM task_templates").fetchone()[0] == template_count_before_invalid
        stored = c.execute("SELECT buttons FROM tasks WHERE id=?", (task_id,)).fetchone()["buttons"]
    assert json.loads(stored) == expected_task_buttons


@requires_flask_http
def test_bot_add_connection_error_preserves_existing_bot_and_group(monkeypatch):
    import requests
    existing_bot, _, _ = create_job()
    with appmod.db() as c:
        c.execute(
            "INSERT INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,?,'已有群组','supergroup','active',?)",
            (existing_bot, -100456, appmod.now()),
        )

    def fail_api(token, method, payload=None, timeout=35):
        assert method == "getMe"
        raise requests.ConnectionError("Temporary failure in name resolution")

    monkeypatch.setattr(appmod, "api", fail_api)
    client = client_for()
    response = client.post(
        "/bots/add",
        data={"token": "123456:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijk"},
        follow_redirects=True,
    )
    page = response.get_data(as_text=True)
    assert "无法连接 Telegram API" in page
    assert "本次 Token 未保存" in page
    assert "当前显示的 1 个机器人和 1 个群组" in page
    assert "已保存，等待连接" in page
    with appmod.db() as c:
        assert c.execute("SELECT COUNT(*) FROM bots").fetchone()[0] == 1
        assert c.execute("SELECT COUNT(*) FROM chats").fetchone()[0] == 1
        saved = c.execute("SELECT token FROM bots WHERE id=?", (existing_bot,)).fetchone()["token"]
    assert appmod.decrypt_token(saved) == "fake-test-bot-token"


@requires_flask_http
def test_bot_add_success_saves_encrypted_token_and_verified_status(monkeypatch):
    token = "123456:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijk"
    monkeypatch.setattr(
        appmod,
        "api",
        lambda supplied, method, payload=None, timeout=35: {
            "id": 987654, "username": "verified_test_bot", "first_name": "Verified Bot"
        },
    )
    monkeypatch.setattr(appmod, "start_pollers", lambda: None)
    response = client_for().post("/bots/add", data={"token": token}, follow_redirects=True)
    assert "已添加 @verified_test_bot" in response.get_data(as_text=True)
    with appmod.db() as c:
        row = c.execute("SELECT * FROM bots WHERE telegram_id=987654").fetchone()
    assert row["token"] != token
    assert appmod.decrypt_token(row["token"]) == token
    assert row["last_api_status"] == "connected"
    assert row["last_api_ok_at"]


def test_poll_bot_persists_network_error_without_disabling_saved_bot(monkeypatch):
    import requests

    bot_id, _, _ = create_job()

    class StopAfterWait:
        stopped = False
        def is_set(self):
            return self.stopped
        def wait(self, seconds):
            self.stopped = True
            return True

    monkeypatch.setattr(
        appmod, "api",
        lambda *args, **kwargs: (_ for _ in ()).throw(requests.ConnectionError("DNS failure")),
    )
    appmod.poll_bot(bot_id, "fake-test-bot-token", StopAfterWait())
    with appmod.db() as c:
        row = c.execute("SELECT status,last_api_status,last_api_error FROM bots WHERE id=?", (bot_id,)).fetchone()
    assert row["status"] == "active"
    assert row["last_api_status"] == "error"
    assert "DNS" in row["last_api_error"]


def test_poll_bot_clears_previous_error_after_successful_api_call(monkeypatch):
    bot_id, _, _ = create_job()
    with appmod.db() as c:
        c.execute(
            "UPDATE bots SET last_api_status='error',last_api_error='previous DNS failure' WHERE id=?",
            (bot_id,),
        )

    class StopAfterApi:
        stopped = False
        def is_set(self):
            return self.stopped
        def set(self):
            self.stopped = True
        def wait(self, seconds):
            self.stopped = True
            return True

    stop_event = StopAfterApi()
    def successful_api(*args, **kwargs):
        stop_event.set()
        return []
    monkeypatch.setattr(appmod, "api", successful_api)
    appmod.poll_bot(bot_id, "fake-test-bot-token", stop_event)
    with appmod.db() as c:
        row = c.execute("SELECT last_api_status,last_api_error,last_api_ok_at FROM bots WHERE id=?", (bot_id,)).fetchone()
    assert row["last_api_status"] == "connected"
    assert row["last_api_error"] is None
    assert row["last_api_ok_at"]


def test_upgrade_script_builds_compose_dns_override_from_host_resolvers():
    from pathlib import Path
    script = (Path(__file__).parents[1] / "upgrade.sh").read_text(encoding="utf-8")
    assert "/etc/resolv.conf" in script
    assert "compose.dns-override.yaml" in script
    assert "dns:" in script
    assert "COMPOSE_ARGS" in script

def test_upgrade_script_verifies_package_sha256_before_docker_actions():
    from pathlib import Path
    script=(Path(__file__).parents[1]/"upgrade.sh").read_text(encoding="utf-8")
    assert '[[ ! -s "$APP_DIR/SHA256SUMS" ]]' in script
    assert 'sha256sum -c SHA256SUMS' in script
    assert "拒绝执行升级" in script


def test_upgrade_script_protects_backup_directory_and_secret_files():
    from pathlib import Path
    script=(Path(__file__).parents[1]/"upgrade.sh").read_text(encoding="utf-8")
    assert "umask 077" in script
    assert 'chmod 0700 "$BACKUP_DIR"' in script
    assert 'chmod 0600 "$BACKUP_DIR/.env"' in script
    assert 'chmod 0600 "$BACKUP_DIR/tgadbot.sqlite3"' in script
    assert 'os.chmod(dst_path, 0o600)' in script


def test_server_preflight_is_read_only_and_does_not_print_secrets():
    from pathlib import Path
    script = (Path(__file__).parents[1] / "preflight.sh").read_text(encoding="utf-8")
    assert "api.telegram.org" in script
    assert "docker inspect" in script
    assert "docker exec -i" in script
    assert "只检查存在性，不读取或输出内容" in script
    assert "docker compose" in script
    forbidden = [
        "docker compose up",
        "docker compose restart",
        "docker stop",
        "docker rm",
        "docker system prune",
        "BOT_TOKEN=",
        "cat \"$ROOT_DIR/.env\"",
    ]
    assert not any(command in script for command in forbidden)
