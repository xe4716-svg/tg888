"""Real browser acceptance of credential lifecycle, source pages and responsive navigation."""
import sys
import threading
import logging
from pathlib import Path
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright
from test_runtime_storage import appmod as a, create_job


def main():
    logging.getLogger('werkzeug').setLevel(logging.ERROR)
    a.app.config.update(TESTING=True)
    bot,task,job=create_job()
    server=make_server('127.0.0.1',0,a.app,threaded=True)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    root=f'http://127.0.0.1:{server.server_port}'
    output=Path(__file__).parents[1]/'dist'/'screenshots';output.mkdir(parents=True,exist_ok=True)
    try:
        with sync_playwright() as pw:
            browser=pw.chromium.launch()
            context=browser.new_context()
            cookie=a.app.session_interface.get_signing_serializer(a.app).dumps({'authenticated':True,'auth_method':'admin_password','is_admin':True})
            context.add_cookies([{'name':'session','value':cookie,'url':root}])
            page=context.new_page();errors=[]
            page.on('pageerror',lambda error:errors.append(str(error)))
            page.goto(root+'/');page.clock.install()
            second, extra_task, extra_job = create_job()
            with a.db() as conn:
                conn.execute('DELETE FROM delivery_jobs WHERE id=?',(extra_job,))
                conn.execute('DELETE FROM tasks WHERE id=?',(extra_task,))
            a.remember_chat(bot, {"id":-100123,"type":"supergroup","title":"第一个来源"})
            a.remember_chat(second, {"id":-987654,"type":"supergroup","title":"第二个来源"})
            page.goto(root+'/library')
            assert page.locator('input[type=file]').count()==0
            page.locator('select[name=bot_id]').select_option(str(second))
            page.locator('[data-source-chat]').select_option('-987654')
            assert page.locator('[data-source-chat]').input_value()=='-987654'
            page.locator('select[name=bot_id]').select_option(str(bot))
            assert page.locator('[data-source-chat]').input_value()=='-100123'
            assert page.locator('[data-source-chat] option[value="-987654"]').count()==0
            page.goto(root+'/')
            a.update_chat_membership(bot, {"id":-100123}, {"status":"kicked"})
            page.clock.fast_forward(3100)
            page.get_by_text('异常：已退群或被移出', exact=True).wait_for()
            page.once('dialog',lambda dialog:dialog.dismiss())
            page.get_by_role('button',name='删除异常群').click()
            assert page.get_by_role('button',name='删除异常群').count()==1
            page.once('dialog',lambda dialog:dialog.accept())
            page.get_by_role('button',name='删除异常群').click()
            assert page.get_by_role('button',name='删除异常群').count()==0
            with a.db() as conn:
                assert conn.execute("SELECT status FROM chats WHERE bot_id=? AND chat_id=-100123",(bot,)).fetchone()[0]=='deleted'
                # Restore fixture for the remaining independent UI scenarios.
                conn.execute("UPDATE chats SET status='active' WHERE bot_id=?",(bot,))
            page.goto(root+'/broadcast')
            page.get_by_role('button',name='添加按钮',exact=True).click()
            page.get_by_role('combobox',name='第 1 个按钮类型').select_option('PROMPT')
            page.get_by_role('textbox',name='第 1 个按钮链接或回调数据').fill('预览提示内容')
            page.once('dialog',lambda dialog:dialog.accept() if dialog.message=='预览提示内容' else (_ for _ in ()).throw(AssertionError(dialog.message)))
            page.locator('.telegram-preview button').click()
            assert '预览提示内容' in page.locator('textarea[name=buttons]').input_value()
            page.screenshot(path=str(output/'buttons-preview.png'),full_page=True)
            page.goto(root+'/')

            assert page.locator('.side-nav a[href="/library"]').count()==1
            assert page.locator('.side-nav a[href="/buttons"]').count()==1
            assert page.locator('.side-nav a[href="/review"]').count()==0
            page.goto(root+f'/tasks/{task}')
            assert page.get_by_role('link', name='处理待核对投递').count()==1
            page.goto(root+'/history')
            row = page.locator('[data-delivery-results] tr').first
            assert row.locator('td').nth(3).inner_text()=='0'
            with a.db() as conn:
                conn.execute("UPDATE delivery_jobs SET status='sent' WHERE id=?", (job,))
            page.clock.fast_forward(3100)
            page.wait_for_function("document.querySelector('[data-delivery-results] tr').cells[3].textContent === '1'")
            with a.db() as conn:
                conn.execute("UPDATE delivery_jobs SET status='failed',last_error=? WHERE id=?",
                             ("机器人没有发送权限，请检查群组的发送权限。", job))
            page.clock.fast_forward(3100)
            page.wait_for_function("""() => {
                const cells = document.querySelector('[data-delivery-results] tr').cells;
                return cells[3].textContent === '0' && cells[4].textContent === '1';
            }""")
            page.reload()
            assert row.locator('td').nth(4).inner_text()=='1'
            page.goto(root+f'/tasks/{task}')
            assert page.get_by_text('机器人没有发送权限，请检查群组的发送权限。').count()==1
            page.goto(root+'/ads')
            page.locator('[name="user_bot_limit"]').fill('3')
            page.locator('[name="default_send_gap_seconds"]').fill('25')
            page.get_by_role('button', name='添加自定义按钮').click()
            page.get_by_role('textbox', name='按钮名称', exact=True).fill('帮助中心')
            page.get_by_role('textbox', name='自定义链接').fill('https://example.com/help')
            page.get_by_role('button', name='保存平台设置').click()
            assert page.locator('[name="user_bot_limit"]').input_value()=='3'
            assert page.locator('.side-nav').get_by_role('link', name='帮助中心').get_attribute('href')=='https://example.com/help'
            page.goto(root+'/broadcast')
            assert not page.get_by_role('checkbox', name='机器人以后被拉入新群时，自动发送本任务已选内容').evaluate("(input) => input.checked")
            assert float(page.locator('#send-gap-seconds').input_value())==25
            page.goto(root+'/ads')
            page.get_by_role('textbox', name='自定义链接').fill('https://example.com/updated')
            page.get_by_role('button', name='保存平台设置').click()
            assert page.locator('.side-nav').get_by_role('link', name='帮助中心').get_attribute('href')=='https://example.com/updated'
            page.locator('[data-remove-sidebar-link]').click()
            page.get_by_role('button', name='保存平台设置').click()
            assert page.locator('.side-nav').get_by_role('link', name='帮助中心').count()==0
            page.goto(root+'/')
            page.locator(f'[data-token-bot="{bot}"]').click()
            assert page.locator('dialog input').get_attribute('type')=='password'
            page.locator('dialog input').fill(a.ADMIN_PASSWORD)
            page.get_by_role('button',name='验证并查看').click()
            page.wait_for_function("document.querySelector('dialog code').textContent.length > 0")
            assert page.locator('dialog code').inner_text()=='fake-test-bot-token'
            assert page.locator('dialog input').input_value()==''
            page.clock.fast_forward(61000)
            assert page.locator('dialog code').inner_text()==''
            assert page.locator('[data-copy]').is_hidden()
            page.get_by_role('button',name='关闭并隐藏').click()
            for width in (1440,820,390):
                page.set_viewport_size({'width':width,'height':1000})
                for path in ('/','/library','/buttons','/review','/broadcast',f'/tasks/{task}/edit'):
                    page.goto(root+path)
                    assert page.locator('h1').count()>0
                    assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'),(width,path)
                if width<=820:
                    page.get_by_role('button',name='展开导航').click()
                    assert page.locator('body').evaluate("e=>e.classList.contains('nav-open')")
                    page.keyboard.press('Escape')
                page.goto(root+'/')
                page.screenshot(path=str(output/f'dashboard-{width}.png'),full_page=False)
            page.get_by_role('button',name='切换明暗主题').click();page.reload()
            assert page.locator('body').evaluate("e=>e.classList.contains('dark')")
            assert not errors,errors
            browser.close()
    finally:server.shutdown()
    print('Browser remediation acceptance passed: masked password, credential expiry, pages, 1440/820/390 widths, navigation and persistent theme.')


if __name__=='__main__':main()
