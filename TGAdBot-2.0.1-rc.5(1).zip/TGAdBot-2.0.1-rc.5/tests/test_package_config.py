from pathlib import Path
import os
import shutil
import subprocess
import sys

from cryptography.fernet import Fernet
import pytest

from init_config import create_config


def test_new_config_has_unique_valid_secrets_and_never_overwrites(tmp_path):
    template = Path(__file__).resolve().parents[1] / '.env.example'
    configs = []
    for name in ('one', 'two'):
        folder = tmp_path / name
        folder.mkdir()
        shutil.copyfile(template, folder / '.env.example')
        config = create_config(folder)
        content = config.read_bytes()
        values = dict(line.split('=', 1) for line in content.decode().splitlines() if line and not line.startswith('#'))
        assert len(values['APP_SECRET']) >= 32
        assert len(values['ADMIN_PASSWORD']) >= 12
        assert values['SESSION_COOKIE_SECURE'] == '1'
        Fernet(values['ENCRYPTION_KEY'].encode())
        with pytest.raises(FileExistsError):
            create_config(folder)
        assert config.read_bytes() == content
        configs.append(values)
    for key in ('APP_SECRET', 'ADMIN_PASSWORD', 'ENCRYPTION_KEY'):
        assert configs[0][key] != configs[1][key]


def test_config_cli_local_mode_and_no_secret_output(tmp_path):
    root = Path(__file__).resolve().parents[1]
    for name in ('.env.example', 'init_config.py'):
        shutil.copyfile(root / name, tmp_path / name)
    result = subprocess.run([sys.executable, str(tmp_path / 'init_config.py'), '--local-http'], capture_output=True, text=True)
    assert result.returncode == 0
    values = dict(line.split('=', 1) for line in (tmp_path / '.env').read_text().splitlines() if line and not line.startswith('#'))
    assert values['SESSION_COOKIE_SECURE'] == '0'
    assert all(values[key] not in result.stdout + result.stderr for key in ('APP_SECRET', 'ADMIN_PASSWORD', 'ENCRYPTION_KEY'))
    if os.name == 'posix':
        assert (tmp_path / '.env').stat().st_mode & 0o777 == 0o600
