from pathlib import Path

APP = Path(__file__).parents[1] / "app.py"
SOURCE = APP.read_text(encoding="utf-8")

def test_port_defaults_to_8096_everywhere():
    root = APP.parent
    assert 'port=int(os.getenv("PORT","8096"))' in SOURCE
    assert 'PORT=8096' in (root / "Dockerfile").read_text()
    assert 'PORT: 8096' in (root / "compose.yaml").read_text()
    assert 'PORT=8096' in (root / ".env.example").read_text()

def test_csrf_enabled():
    assert "CSRFProtect(app)" in SOURCE
    assert 'name="csrf_token"' in SOURCE
    assert "WTF_CSRF_TIME_LIMIT" in SOURCE

def test_sensitive_routes_require_login():
    for route in ['def index():', 'def add_bot():', 'def poll_start(bot_id):', 'def broadcast():', 'def ads():']:
        pos = SOURCE.index(route)
        assert "@login_required" in SOURCE[max(0, pos-100):pos]

def test_token_encryption_and_migration_present():
    assert "encrypt_token(token)" in SOURCE
    assert "decrypt_token(encrypted_token)" in SOURCE
    assert "token_encryption_version" in SOURCE
    assert "Fernet(ENCRYPTION_KEY.encode" in SOURCE

def test_server_forces_configurable_ad_policy():
    assert 'FORCED_AD_MODE = "BOTH"' in SOURCE
    assert "def forced_ad_mode():" in SOURCE
    assert 'ad_mode = ad_mode or forced_ad_mode()' in SOURCE
    assert 'mode=request.form.get("forced_ad_mode","BOTH")' in SOURCE
    assert 'name="forced_ad_mode"' in SOURCE
    assert 'name="ad_mode"' not in SOURCE


def test_secrets_have_no_unsafe_defaults():
    assert 'APP_SECRET = os.getenv("APP_SECRET", "")' in SOURCE
    assert 'ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "")' in SOURCE
    assert 'ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY", "")' in SOURCE

def test_secret_strength_is_enforced():
    assert "APP_SECRET 至少需要 32 个字符" in SOURCE
    assert "ADMIN_PASSWORD 至少需要 12 个字符" in SOURCE

def test_no_legacy_database_admin_password():
    assert "admin_password TEXT" not in SOURCE

def test_delivery_queue_is_persistent_and_unique_per_target():
    assert "CREATE TABLE IF NOT EXISTS delivery_jobs" in SOURCE
    assert "UNIQUE(task_id, bot_id, chat_id)" in SOURCE
    assert "INSERT OR IGNORE INTO delivery_jobs" in SOURCE

def test_ambiguous_network_send_is_not_retried():
    assert 'status=\'unknown\'' in SOURCE
    assert "网络结果不确定" in SOURCE
    assert "requests.exceptions.RequestException" in SOURCE

def test_telegram_retry_after_is_respected():
    assert "retry_after" in SOURCE
    assert "next_attempt_at" in SOURCE
    assert "Telegram 限流，等待" in SOURCE

def test_worker_starts_and_recovers_interrupted_sends_as_unknown():
    assert "start_delivery_worker()" in SOURCE
    assert "进程在发送过程中退出" in SOURCE

def test_task_and_recipient_enqueue_are_in_same_transaction():
    route_start = SOURCE.index('def broadcast():')
    route_end = SOURCE.index('@app.route("/ads"', route_start)
    segment = SOURCE[route_start:route_end]
    task_insert = segment.index('INSERT INTO tasks')
    enqueue_insert = segment.index('INSERT OR IGNORE INTO delivery_jobs')
    assert segment.rfind("with db() as c:", 0, task_insert) == segment.rfind("with db() as c:", 0, enqueue_insert)

def test_delivery_uses_task_ad_snapshot():
    assert 'ad_text=task["ad_text"]' in SOURCE
    assert 'ad_button_text=task["ad_button_text"]' in SOURCE
    assert 'ad_url=task["ad_url"]' in SOURCE

def test_telegram_media_library_replaces_local_upload():
    assert "def remember_media_message" in SOURCE
    assert "CREATE TABLE IF NOT EXISTS media_assets" in SOURCE
    assert "file_id TEXT NOT NULL" in SOURCE
    assert "def send_task_content" in SOURCE
    from material_library import MEDIA_SEND_METHODS
    assert MEDIA_SEND_METHODS["photo"] == "sendPhoto"
    assert MEDIA_SEND_METHODS["video"] == "sendVideo"
    assert 'name="media_assets_{{b.id}}"' in SOURCE
    assert 'type="file"' not in SOURCE
    assert 'enctype="multipart/form-data"' not in SOURCE
    assert "save_uploaded_media" not in SOURCE


def test_media_is_reused_by_telegram_file_id_not_server_upload():
    assert 'payload = {"chat_id": chat_id, kind: asset["file_id"]}' in SOURCE
    assert "media_assets TEXT NOT NULL DEFAULT" in SOURCE
    assert "source_message_id" in SOURCE


def test_retry_attempt_counter_is_incremented_before_processing():
    assert 'claimed["attempts"] = int(row["attempts"]) + 1' in SOURCE

def test_scheduled_send_is_saved_and_delayed_in_queue():
    assert "def parse_schedule_timestamp" in SOURCE
    assert "scheduled_epoch" in SOURCE
    assert "next_attempt_at" in SOURCE
    assert 'name="scheduled_at"' in SOURCE
    assert 'name="tz_offset_minutes"' in SOURCE

def test_local_upload_endpoint_and_limit_are_removed():
    assert 'MAX_CONTENT_LENGTH"] = 51 * 1024 * 1024' not in SOURCE
    assert 'request.files.get("media")' not in SOURCE

def test_production_uses_single_worker_wsgi_entrypoint():
    root = APP.parent
    assert "start_delivery_worker()" in (root / "wsgi.py").read_text()
    docker = (root / "Dockerfile").read_text()
    assert "gunicorn" in docker and '"--workers", "1"' in docker
    assert "gunicorn" in (root / "requirements.txt").read_text()

def test_media_directory_is_persisted_in_docker_volume():
    compose = (APP.parent / "compose.yaml").read_text()
    assert "MEDIA_DIR: /data/media" in compose
    assert "tgadbot_data:/data" in compose

def test_rotation_messages_are_sent_abc_per_group_with_resumable_cursor():
    assert "rotation_messages TEXT NOT NULL DEFAULT" in SOURCE
    assert "rotation_index INTEGER NOT NULL DEFAULT 0" in SOURCE
    assert "while rotation_index < len(rotation)" in SOURCE
    assert "SET rotation_index=?" in SOURCE
    assert 'name="rotation_messages"' in SOURCE
    assert "最多 20 条轮换消息" in SOURCE
    assert "每个目标群组都会依次收到 A→B→C 全部消息" in SOURCE

def test_task_controls_are_post_only_and_csrf_protected():
    assert '@app.post("/tasks/<int:task_id>/<action>")' in SOURCE
    assert 'name="csrf_token"' in SOURCE
    assert 'actions={"pause":pause_task,"resume":resume_task,"cancel":cancel_task,"retry_failed":retry_failed_jobs}' in SOURCE

def test_worker_does_not_claim_paused_or_cancelled_tasks():
    assert "tasks.status IN ('running','scheduled')" in SOURCE

def test_manual_pause_is_not_overwritten_by_delivery_summary():
    assert 'current["status"] in ("paused","cancelled")' in SOURCE

def test_auto_join_send_is_delayed_deduplicated_and_opt_in():
    assert "CREATE TABLE IF NOT EXISTS join_auto_sends" in SOURCE
    assert "UNIQUE(bot_id,chat_id)" in SOURCE
    assert "timestamp=int(time.time())+5" in SOURCE
    assert 'setting("auto_join_enabled") != "1"' in SOURCE
    assert "queue_auto_join_send(bot_id,chat)" in SOURCE
    assert "claim_join_auto_send()" in SOURCE

def test_interrupted_join_auto_send_is_marked_unknown_on_restart():
    assert "UPDATE join_auto_sends SET status='unknown'" in SOURCE


def test_recurring_series_has_bounded_repeats_and_unknown_pause():
    assert "CREATE TABLE IF NOT EXISTS recurring_series" in SOURCE
    assert "interval_seconds INTEGER NOT NULL" in SOURCE
    assert "max_runs INTEGER NOT NULL" in SOURCE
    assert "process_recurring_series()" in SOURCE
    assert "previous[\"status\"] == \"unknown\"" in SOURCE
    assert "loop_mode TEXT NOT NULL DEFAULT 'legacy_interval'" in SOURCE
    assert "stop_after_seconds INTEGER NOT NULL DEFAULT 0" in SOURCE
    assert "next_run_at = run_at if continuous else run_at + int(series[\"interval_seconds\"])" in SOURCE

def test_task_history_and_detail_routes_are_login_protected():
    assert '@app.route("/history")\n@login_required' in SOURCE
    assert '@app.route("/tasks/<int:task_id>")\n@login_required' in SOURCE
    assert "unknown_jobs" in SOURCE
    assert "last_error" in SOURCE

def test_task_template_never_exports_bot_tokens():
    assert "CREATE TABLE IF NOT EXISTS task_templates" in SOURCE
    assert '@app.post("/tasks/<int:task_id>/clone")' in SOURCE
    assert "不会复制 Bot Token" in SOURCE

def test_telegram_login_supports_public_registration_and_optional_allowlist():
    assert "def verify_telegram_login" in SOURCE
    assert 'hashlib.sha256(token.encode("utf-8")).digest()' in SOURCE
    assert "current - auth_ts > int(max_age_seconds)" in SOURCE
    assert "if TELEGRAM_LOGIN_ALLOWED_USER_IDS and user_id not in TELEGRAM_LOGIN_ALLOWED_USER_IDS" in SOURCE
    assert "不同账号的数据相互隔离" in SOURCE
    assert '@app.get("/auth/telegram/callback")' in SOURCE

def test_bot_profile_export_excludes_token():
    assert '@app.get("/bots/<int:bot_id>/profile")' in SOURCE
    assert '"schema":"tgadbot.bot-profile.v1"' in SOURCE
    assert '"note":"此文件不包含 Bot Token' in SOURCE

def test_cancelling_recurring_task_cancels_series():
    assert "UPDATE recurring_series SET status='cancelled'" in SOURCE

def test_saved_template_restores_buttons_in_supported_input_format():
    assert 'button_lines.append(f"{button.get(\'text\',\'\')} | URL | {button[\'url\']}")' in SOURCE

def test_recurring_series_controls_are_post_only_and_csrf_protected():
    assert '@app.post("/series/<int:series_id>/<action>")' in SOURCE
    assert 'actions={"pause":pause_series,"resume":resume_series,"cancel":cancel_series}' in SOURCE
    assert "UNKNOWN 系列必须先核对" in SOURCE

def test_template_id_query_is_parsed_safely():
    assert "except (TypeError, ValueError)" in SOURCE
    assert "template_config = json.loads(row[\"config_json\"])" in SOURCE


def test_rotation_parser_uses_newline_regex_import():
    assert ", re, base64" in SOURCE.splitlines()[0]
    assert "def parse_rotation_messages(rotation_raw):" in SOURCE
    assert 're.split(r"\\n\\s*---轮换消息---\\s*\\n", rotation_raw)' in SOURCE


def test_telegram_login_callback_consumes_hash_once():
    assert "CREATE TABLE IF NOT EXISTS telegram_login_uses" in SOURCE
    assert "def consume_telegram_login_hash" in SOURCE
    callback = SOURCE[SOURCE.index('def telegram_login_callback():'):SOURCE.index('@app.post("/logout")')]
    assert 'consume_telegram_login_hash(payload.get("hash"))' in callback
    assert "max_age_seconds=300" in SOURCE


def test_user_data_isolation_schema_and_route_filters_exist():
    assert "CREATE TABLE IF NOT EXISTS users" in SOURCE
    assert "owner_user_id TEXT NOT NULL DEFAULT 'legacy_admin'" in SOURCE
    assert "def current_owner_id():" in SOURCE
    assert "def owner_clause(" in SOURCE
    assert "WHERE bots.status='active' AND chats.status='active' AND {bot_where}" in SOURCE
    assert "require_admin()" in SOURCE


def test_success_log_retention_is_configurable_and_keeps_failures():
    assert 'LOG_RETENTION_HOURS = max(1, int(os.getenv("LOG_RETENTION_HOURS", "12")))' in SOURCE
    assert "def cleanup_success_logs" in SOURCE
    assert "timedelta(hours=LOG_RETENTION_HOURS)" in SOURCE
    assert "INSERT INTO log_visibility" in SOURCE
    assert "DELETE FROM delivery_jobs WHERE status='failed'" not in SOURCE
    assert "cleanup_success_logs()" in SOURCE


def test_task_specific_auto_join_reuses_selected_content():
    assert "def queue_task_join_auto_send" in SOURCE
    assert "def process_task_join_auto_send" in SOURCE
    assert 'name="auto_join_enabled"' in SOURCE
    assert "send_one(token,job[\"chat_id\"],rotation[rotation_index]" in SOURCE
    assert "send_task_content(token,job[\"chat_id\"]" in SOURCE


def test_complete_customer_accounts_and_admin_management_are_present():
    assert "CREATE TABLE IF NOT EXISTS user_accounts" in SOURCE
    assert '@app.route("/register", methods=["GET", "POST"])' in SOURCE
    assert '@app.route("/account", methods=["GET", "POST"])' in SOURCE
    assert '@app.get("/admin/users")' in SOURCE
    assert '@app.post("/admin/users/<user_id>/<action>")' in SOURCE
    assert "def hash_password(password):" in SOURCE
    assert 'hashlib.pbkdf2_hmac("sha256"' in SOURCE
    assert 'ALLOW_PUBLIC_REGISTRATION = os.getenv("ALLOW_PUBLIC_REGISTRATION", "1") == "1"' in SOURCE


def test_legacy_telegram_users_table_is_not_rebuilt_for_rollback_safety():
    assert "CREATE TABLE IF NOT EXISTS users(\n          telegram_user_id TEXT PRIMARY KEY" in SOURCE
    assert "INSERT OR IGNORE INTO user_accounts" in SOURCE
    assert "ALTER TABLE users RENAME TO" not in SOURCE


def test_allowlist_is_not_an_admin_role():
    admin_check = SOURCE[SOURCE.index("def is_admin_user():"):SOURCE.index("def current_owner_id():")]
    assert "TELEGRAM_LOGIN_ALLOWED_USER_IDS" not in admin_check
    assert 'user["role"] == "admin"' in admin_check


def test_media_assets_keep_source_message_for_copy_and_forward():
    assert "media_group_id TEXT" in SOURCE
    assert "source_message_json TEXT" in SOURCE
    assert '"copyMessages" if' not in SOURCE
    assert 'method = "forwardMessages" if use_forward else "copyMessages"' in SOURCE
    assert 'method = "forwardMessage" if use_forward else "copyMessage"' in SOURCE


def test_auto_join_rotations_are_independent_and_resumable():
    assert "rotation_index INTEGER NOT NULL DEFAULT 0" in SOURCE
    assert "while rotation_index < len(rotation)" in SOURCE
    assert "task_join_auto_sends SET rotation_index=?" in SOURCE
