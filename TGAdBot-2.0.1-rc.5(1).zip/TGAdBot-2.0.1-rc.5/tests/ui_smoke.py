"""Run separately: python tests/ui_smoke.py (requires Playwright Chromium)."""
import json
import threading
import time
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright
from test_runtime_storage import appmod, create_job

appmod.app.config.update(TESTING=True)
appmod.init_db()
button_test_bot,_,_=create_job()
with appmod.db() as c:
    c.execute("UPDATE bots SET username='browserbot',first_name='Browser Bot' WHERE id=?",(button_test_bot,))
    c.execute("INSERT INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,?,'按钮浏览器验收群','supergroup','active',?)",(button_test_bot,-100123,appmod.now()))
appmod.start_delivery_worker=lambda:None
server=make_server('127.0.0.1',0,appmod.app,threaded=True)
thread=threading.Thread(target=server.serve_forever,daemon=True)
thread.start()
root=f'http://127.0.0.1:{server.server_port}'
try:
    with sync_playwright() as pw:
        browser=pw.chromium.launch()
        context=browser.new_context()
        cookie=appmod.app.session_interface.get_signing_serializer(appmod.app).dumps({'authenticated':True,'auth_method':'admin_password','is_admin':True})
        context.add_cookies([{'name':'session','value':cookie,'url':root}])
        page=context.new_page(); errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        guest_context=browser.new_context()
        guest_page=guest_context.new_page()
        guest_page.goto(root+'/login')
        assert guest_page.locator('.guest-header img').get_attribute('src')=='/static/brand-approved.png'
        assert guest_page.locator('link[rel="icon"]').get_attribute('href')=='/static/brand-approved.png'
        guest_context.close()
        page.goto(root+'/broadcast')
        assert page.locator('.brand-logo').get_attribute('src')=='/static/brand-approved.png'
        page.get_by_role('button',name='添加按钮',exact=True).click()
        page.get_by_placeholder('按钮文字').fill('第一个')
        page.get_by_placeholder('https://链接 或已有回调数据').fill('https://example.com')
        page.get_by_role('button',name='添加按钮',exact=True).click()
        page.get_by_placeholder('按钮文字').nth(1).fill('第二个')
        assert page.locator('[data-button-preview]').inner_text()=='第一个\n第二个'
        page.locator('select').filter(has=page.locator('option[value="2"]')).select_option('2')
        assert page.locator('[data-button-preview]').inner_text()=='第一个 | 第二个'
        page.locator('select').filter(has=page.locator('option[value="1"]')).select_option('1')
        page.get_by_role('button',name='上移',exact=True).nth(1).click()
        assert page.get_by_placeholder('按钮文字').first.input_value()=='第二个'
        page.get_by_role('button',name='删除',exact=True).nth(1).click()
        assert page.get_by_placeholder('按钮文字').count()==1
        assert page.locator('select[aria-label="按钮显示方式"]').count() == 0
        page.locator('select[aria-label="每排按钮数量"]').select_option('2')
        page.get_by_placeholder('https://链接 或已有回调数据').first.fill('https://example.com/second')
        page.get_by_role('button',name='添加按钮',exact=True).click()
        page.get_by_placeholder('按钮文字').nth(1).fill('第三个')
        page.get_by_placeholder('https://链接 或已有回调数据').nth(1).fill('https://example.com/third')
        page.locator('#broadcast-body').fill('按钮持久化浏览器验收')
        page.get_by_role('button',name='确认并创建发送任务').click()
        page.get_by_role('button',name='确认保存',exact=True).click()
        page.wait_for_url(root+'/')
        with appmod.db() as c:
            saved_task=c.execute('SELECT id,buttons FROM tasks ORDER BY id DESC LIMIT 1').fetchone()
        saved_task_id=saved_task['id']
        assert json.loads(saved_task['buttons'])==[[{'text':'第二个','url':'https://example.com/second'},{'text':'第三个','url':'https://example.com/third'}]]
        page.goto(root+f'/tasks/{saved_task_id}')
        page.get_by_role('button',name='保存为可复用消息模板',exact=True).click()
        page.wait_for_url('**/broadcast?template_id=latest')
        assert page.get_by_placeholder('按钮文字').count()==2
        assert page.get_by_placeholder('按钮文字').nth(0).input_value()=='第二个'
        assert page.get_by_placeholder('按钮文字').nth(1).input_value()=='第三个'
        assert page.locator('select[aria-label="每排按钮数量"]').input_value()=='2'
        restored=page.locator('textarea[name="buttons"]').evaluate('(el)=>JSON.parse(el.value)')
        assert restored['rows'][0][0]['target']=='https://example.com/second'
        page.reload()
        assert page.get_by_placeholder('按钮文字').nth(0).input_value()=='第二个'
        assert page.get_by_placeholder('按钮文字').nth(1).input_value()=='第三个'
        with appmod.db() as c:
            tasks_before_invalid=c.execute('SELECT COUNT(*) FROM tasks').fetchone()[0]
        page.get_by_placeholder('https://链接 或已有回调数据').first.fill('javascript:alert(1)')
        page.get_by_role('button',name='确认并创建发送任务').click()
        assert 'HTTP/HTTPS' in page.locator('[role="alert"]').inner_text()
        with appmod.db() as c:
            assert c.execute('SELECT COUNT(*) FROM tasks').fetchone()[0]==tasks_before_invalid
        assert page.url.endswith('/broadcast?template_id=latest')
        assert page.locator('[name="repeat_enabled"]').is_visible()
        page.locator('[name="repeat_enabled"]').check()
        assert page.locator('[name="repeat_duration_unit"]').input_value()=='none'
        assert page.locator('[name="repeat_max_runs"]').input_value()==''
        page.get_by_text('高级选项：文字轮换',exact=True).click()
        page.get_by_role('button',name='添加轮换消息',exact=True).click()
        rotation=page.locator('#rotation-messages + div')
        rotation.locator('textarea').first.fill('第一条轮换')
        rotation.get_by_role('button',name='添加轮换消息',exact=True).click()
        rotation.locator('textarea').nth(1).fill('第二条轮换')
        rotation.get_by_role('button',name='上移',exact=True).nth(1).click()
        assert rotation.locator('textarea').first.input_value()=='第二条轮换'
        assert rotation.locator('pre').first.inner_text()=='第二条轮换'
        rotation.get_by_role('button',name='删除',exact=True).nth(1).click()
        assert page.locator('#rotation-messages').input_value()=='第二条轮换'
        assert page.locator('#rotation-messages').is_hidden()
        assert page.locator('link[rel="icon"]').get_attribute('href')=='/static/brand-approved.png'
        page.goto(root+'/admin/announcements')
        group_form=page.locator('form').filter(has=page.get_by_role('button',name='保存官方群'))
        group_form.locator('[name="official_group_url"]').fill('https://t.me/tgadbot_acceptance')
        group_form.get_by_role('button',name='保存官方群',exact=True).click()
        form=page.locator('form').filter(has=page.get_by_role('heading',name='新增公告'))
        form.locator('[name="title"]').fill('浏览器公告')
        form.locator('[name="body"]').fill('浏览器正文')
        form.get_by_role('button',name='新增',exact=True).click()
        page.goto(root+'/')
        assert page.get_by_role('heading',name='浏览器公告',exact=True).count()==1
        assert page.get_by_role('link',name='加入官方群').get_attribute('href')=='https://t.me/tgadbot_acceptance'
        _,task,_=create_job()
        with appmod.db() as c:
            series=c.execute("INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at) VALUES('{}',900,2,1,?,?,'active',?,?)",(int(time.time())+900,task,appmod.now(),appmod.now())).lastrowid
            c.execute('UPDATE tasks SET series_id=? WHERE id=?',(series,task))
        page.goto(root+f'/tasks/{task}')
        assert '剩余' in page.locator('[data-countdown]').inner_text()
        page.get_by_role('button',name='暂停整个循环',exact=True).click()
        page.goto(root+f'/tasks/{task}')
        assert page.locator('[data-countdown]').inner_text()=='已暂停'
        page.get_by_role('button',name='恢复整个循环',exact=True).click()
        page.goto(root+f'/tasks/{task}')
        resumed_countdown = page.locator('[data-countdown]').inner_text()
        assert ('剩余' in resumed_countdown or resumed_countdown == '等待上一轮结束或调度执行'), resumed_countdown
        page.get_by_role('button',name='取消整个循环',exact=True).click()
        page.goto(root+f'/tasks/{task}')
        assert page.locator('[data-countdown]').inner_text()=='已取消'

        # Verify an existing queued task can be edited without replacing its history.
        page.goto(root+f'/tasks/{saved_task_id}')
        page.get_by_role('link',name='编辑任务内容与发送设置').click()
        page.locator('textarea[name="body"]').fill('浏览器验收：修改后的任务正文')
        assert page.locator('input[name="send_gap_seconds"]').get_attribute('readonly') is not None
        page.locator('select[name="sender_mode"]').select_option('show')
        page.get_by_role('button',name='保存任务修改',exact=True).click()
        page.get_by_role('button',name='确认保存',exact=True).click()
        page.wait_for_url(root+f'/tasks/{saved_task_id}')
        with appmod.db() as c:
            edited=c.execute('SELECT body,send_gap_seconds,sender_mode FROM tasks WHERE id=?',(saved_task_id,)).fetchone()
            retained=c.execute('SELECT COUNT(*) FROM delivery_jobs WHERE task_id=?',(saved_task_id,)).fetchone()[0]
        assert edited['body']=='浏览器验收：修改后的任务正文'
        assert edited['send_gap_seconds']==appmod.platform_send_gap_seconds() and edited['sender_mode']=='show' and retained==1

        # Invalid-token/normal bots remain deletable; deletion keeps task history.
        page.goto(root+'/')
        with appmod.db() as c:
            bot_snapshot=[dict(row) for row in c.execute("SELECT id,username,first_name,status,owner_user_id FROM bots ORDER BY id").fetchall()]
        print('BOT DELETE ACCEPTANCE SNAPSHOT:', bot_snapshot)
        print('DASHBOARD BOT SECTION:', page.locator('#bots').inner_text())
        delete_form=page.locator(f'form[action="/bots/{button_test_bot}/delete"]')
        print('DELETE FORM COUNT:', delete_form.count(), 'EXPECTED BOT ID:', button_test_bot)
        assert delete_form.count()==1, page.locator('body').inner_text()
        page.once('dialog',lambda dialog:dialog.dismiss())
        delete_form.get_by_role('button',name='删除机器人',exact=True).click()
        assert delete_form.count()==1
        page.once('dialog',lambda dialog:dialog.accept())
        delete_form.get_by_role('button',name='删除机器人',exact=True).click()
        page.wait_for_url(root+'/')
        with appmod.db() as c:
            deleted=c.execute('SELECT status,token FROM bots WHERE id=?',(button_test_bot,)).fetchone()
            retained_bot_task=c.execute('SELECT COUNT(*) FROM tasks WHERE id=?',(saved_task_id,)).fetchone()[0]
        assert deleted['status']=='deleted' and deleted['token']==f'deleted:{button_test_bot}' and retained_bot_task==1
        assert page.locator(f'form[action="/bots/{button_test_bot}/delete"]').count()==0

        assert not errors, errors
        browser.close()
        print('Browser smoke passed: visual buttons, recurrence, rotation editor, favicon, announcements, task editing and Bot deletion; no JavaScript errors.')
finally:
    server.shutdown()
