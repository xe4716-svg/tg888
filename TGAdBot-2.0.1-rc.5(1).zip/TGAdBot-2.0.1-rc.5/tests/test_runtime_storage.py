
import os, sys, types, tempfile, sqlite3, threading, time, importlib, pathlib, pytest, json
from contextlib import nullcontext, contextmanager
from cryptography.fernet import Fernet

APP_DIR = pathlib.Path(__file__).parents[1]
TMP = tempfile.mkdtemp(prefix="tgadbot-test-")
os.environ["APP_SECRET"] = "S" * 48
os.environ["ADMIN_PASSWORD"] = "Strong-test-password-123"
os.environ["ENCRYPTION_KEY"] = Fernet.generate_key().decode()
os.environ["DB_PATH"] = os.path.join(TMP, "test.sqlite3")
os.environ["MEDIA_DIR"] = os.path.join(TMP, "media")
os.environ["SESSION_COOKIE_SECURE"] = "0"

# Flask is unavailable in this execution image. Provide a minimal import-time shim;
# tests below exercise the real application storage/queue functions, not HTTP routes.
if importlib.util.find_spec("flask") is None:
    flask = types.ModuleType("flask")
    class StubFlask:
        def __init__(self, *a, **kw): self.config = {}; self.secret_key = None
        def route(self, *a, **kw): return lambda fn: fn
        def post(self, *a, **kw): return lambda fn: fn
        def get(self, *a, **kw): return lambda fn: fn
        def run(self, *a, **kw): pass
        def test_request_context(self, *a, **kw): return nullcontext(self)
    flask.Flask = StubFlask
    flask.request = types.SimpleNamespace(remote_addr="127.0.0.1", path="/")
    flask.redirect = lambda *a, **kw: None
    flask.url_for = lambda *a, **kw: "/"
    flask.flash = lambda *a, **kw: None
    flask.render_template_string = lambda *a, **kw: ""
    flask.session = {}
    flask.abort = lambda *a, **kw: None
    flask.jsonify = lambda *a, **kw: {"json": a[0] if a else kw}
    sys.modules["flask"] = flask
if importlib.util.find_spec("flask_wtf") is None:
    fw = types.ModuleType("flask_wtf")
    csrfmod = types.ModuleType("flask_wtf.csrf")
    csrfmod.CSRFProtect = lambda app: object()
    fw.csrf = csrfmod
    sys.modules["flask_wtf"] = fw
    sys.modules["flask_wtf.csrf"] = csrfmod
if importlib.util.find_spec("markupsafe") is None:
    ms = types.ModuleType("markupsafe")
    ms.Markup = lambda value: value
    sys.modules["markupsafe"] = ms

sys.path.insert(0, str(APP_DIR))
appmod = importlib.import_module("app")
appmod.init_db()

@contextmanager
def app_request_context(path="/", method="GET", data=None):
    """Use a real Flask request context when installed, with a test shim fallback."""
    if hasattr(appmod.app, "test_client"):
        with appmod.app.test_request_context(path, method=method, data=data):
            yield
        return
    previous_request = appmod.request
    previous_session = dict(appmod.session)
    class Form(dict):
        def getlist(self, key):
            value = self.get(key, [])
            if isinstance(value, list):
                return value
            return [value] if value not in (None, "") else []
    appmod.request = types.SimpleNamespace(method=method, form=Form(data or {}), path=path, args={})
    appmod.session.clear()
    try:
        yield
    finally:
        appmod.request = previous_request
        appmod.session.clear()
        appmod.session.update(previous_session)

@pytest.fixture(autouse=True)
def clean_database():
    with appmod.db() as c:
        for table in ('credential_audit','task_versions','resolutions','message_receipts','collection_sources','materials','material_versions','imports','button_actions','button_events','button_templates'):
            c.execute('DELETE FROM ' + table)
        c.execute("DELETE FROM delivery_jobs")
        c.execute("DELETE FROM task_join_auto_sends")
        c.execute("DELETE FROM join_auto_sends")
        c.execute("DELETE FROM recurring_series")
        c.execute("DELETE FROM media_assets")
        c.execute("DELETE FROM tasks")
        c.execute("DELETE FROM chats")
        c.execute("DELETE FROM bots")
        c.execute("DELETE FROM telegram_login_uses")
        c.execute("DELETE FROM user_accounts")
        c.execute("DELETE FROM users")
        c.execute("DELETE FROM registration_attempts")
        c.execute("DELETE FROM login_attempts")

import itertools
_test_bot_ids = itertools.count(1000000)

def create_job():
    token = "fake-test-bot-token"
    with appmod.db() as c:
        cur = c.execute("""INSERT INTO bots(token,telegram_id,username,first_name,token_encryption_version,status,created_at)
            VALUES(?,?,?,?,1,'active',?)""",
            (appmod.encrypt_token(token), next(_test_bot_ids), "testbot", "Test Bot", appmod.now()))
        bot_id = cur.lastrowid
        cur = c.execute("""INSERT INTO tasks(bot_ids,chat_targets,body,buttons,ad_mode,ad_text,ad_button_text,ad_url,status,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)""",
            ("[]","[]","hello","[]","BOTH","forced ad","official","https://example.com","running",appmod.now()))
        task_id = cur.lastrowid
        cur = c.execute("""INSERT INTO delivery_jobs(task_id,bot_id,chat_id,chat_title,status,attempts,next_attempt_at,created_at,updated_at)
            VALUES(?,?,?,'test group','pending',0,0,?,?)""",
            (task_id,bot_id,-100123,appmod.now(),appmod.now()))
        job_id = cur.lastrowid
    return bot_id, task_id, job_id

def test_token_cipher_round_trip_and_database_ciphertext():
    bot_id, task_id, job_id = create_job()
    with appmod.db() as c:
        stored = c.execute("SELECT token FROM bots WHERE id=?", (bot_id,)).fetchone()["token"]
    assert stored != "fake-test-bot-token"
    assert appmod.decrypt_token(stored) == "fake-test-bot-token"

def test_claim_delivery_job_updates_state_and_attempt_count():
    _, _, job_id = create_job()
    claimed = appmod.claim_delivery_job()
    assert claimed["id"] == job_id
    assert claimed["attempts"] == 1
    with appmod.db() as c:
        row = c.execute("SELECT status,attempts FROM delivery_jobs WHERE id=?", (job_id,)).fetchone()
    assert row["status"] == "sending" and row["attempts"] == 1

def test_concurrent_claims_do_not_claim_same_job():
    _, _, job_id = create_job()
    results=[]
    barrier=threading.Barrier(3)
    def run_claim():
        barrier.wait()
        results.append(appmod.claim_delivery_job())
    threads=[threading.Thread(target=run_claim) for _ in range(2)]
    for t in threads: t.start()
    barrier.wait()
    for t in threads: t.join()
    claimed=[x for x in results if x and x["id"] == job_id]
    assert len(claimed) == 1

def test_successful_delivery_updates_job_and_task(monkeypatch):
    _, task_id, job_id = create_job()
    claimed=appmod.claim_delivery_job()
    sent=[]
    monkeypatch.setattr(appmod, "send_one", lambda *a, **kw: sent.append((a,kw)) or {"message_id":1})
    appmod.process_delivery_job(claimed)
    with appmod.db() as c:
        job=c.execute("SELECT status FROM delivery_jobs WHERE id=?", (job_id,)).fetchone()
        task=c.execute("SELECT status,result FROM tasks WHERE id=?", (task_id,)).fetchone()
    assert sent and job["status"] == "sent" and task["status"] == "completed"

def test_429_retry_after_is_scheduled_without_early_retry(monkeypatch):
    _, _, job_id = create_job()
    claimed=appmod.claim_delivery_job()
    monkeypatch.setattr(appmod, "send_one", lambda *a, **kw: (_ for _ in ()).throw(appmod.TelegramAPIError(429,"slow down",retry_after=23)))
    before=int(time.time())
    appmod.process_delivery_job(claimed)
    with appmod.db() as c:
        row=c.execute("SELECT status,next_attempt_at FROM delivery_jobs WHERE id=?", (job_id,)).fetchone()
    assert row["status"] == "pending"
    assert row["next_attempt_at"] >= before + 23

def test_ambiguous_network_error_becomes_unknown_not_retry(monkeypatch):
    _, _, job_id = create_job()
    claimed=appmod.claim_delivery_job()
    import requests
    monkeypatch.setattr(appmod, "send_one", lambda *a, **kw: (_ for _ in ()).throw(requests.exceptions.ConnectionError("test")))
    appmod.process_delivery_job(claimed)
    with appmod.db() as c:
        row=c.execute("SELECT status FROM delivery_jobs WHERE id=?", (job_id,)).fetchone()
    assert row["status"] == "unknown"

def test_interrupted_sending_job_is_recovered_as_unknown():
    _, _, job_id = create_job()
    with appmod.db() as c:
        c.execute("UPDATE delivery_jobs SET status='sending' WHERE id=?", (job_id,))
    appmod.init_db()
    with appmod.db() as c:
        row=c.execute("SELECT status FROM delivery_jobs WHERE id=?", (job_id,)).fetchone()
    assert row["status"] == "unknown"

def test_telegram_media_library_captures_file_id_without_downloading(monkeypatch):
    bot_id,_,_=create_job()
    message={"message_id":88,"chat":{"id":-100321,"title":"素材群","type":"supergroup"},
             "photo":[{"file_id":"photo-small","file_unique_id":"photo-unique","file_size":100},
                      {"file_id":"photo-large","file_unique_id":"photo-unique-large","file_size":900}],
             "caption":"活动图片"}
    assert appmod.remember_media_message(bot_id,message)
    with appmod.db() as c:
        row=c.execute("SELECT * FROM media_assets WHERE bot_id=?",(bot_id,)).fetchone()
    assert row["media_type"]=="photo" and row["file_id"]=="photo-large"
    assert row["source_chat_title"]=="素材群" and row["caption"]=="活动图片"

def test_schedule_timestamp_converts_browser_local_time_to_utc():
    # 2030-01-02 10:00 at UTC+8 is 02:00 UTC.
    value=appmod.parse_schedule_timestamp("2030-01-02T10:00", "-480")
    import datetime
    actual=datetime.datetime.fromtimestamp(value,datetime.timezone.utc)
    assert actual.hour == 2 and actual.day == 2

def test_schedule_timestamp_rejects_past_time():
    with pytest.raises(ValueError):
        appmod.parse_schedule_timestamp("2000-01-01T00:00", "0")

def test_scheduled_job_is_not_claimed_before_due():
    _, _, job_id = create_job()
    with appmod.db() as c:
        c.execute("UPDATE delivery_jobs SET next_attempt_at=? WHERE id=?",
                  (int(time.time())+60,job_id))
    assert appmod.claim_delivery_job() is None
    with appmod.db() as c:
        c.execute("UPDATE delivery_jobs SET next_attempt_at=0 WHERE id=?",(job_id,))
    assert appmod.claim_delivery_job()["id"] == job_id

@pytest.mark.parametrize("kind,method", [
    ("photo","sendPhoto"),("video","sendVideo"),("document","sendDocument")
])
def test_media_sender_uses_correct_telegram_method(monkeypatch,tmp_path,kind,method):
    media=tmp_path/("sample."+{"photo":"png","video":"mp4","document":"pdf"}[kind])
    media.write_bytes(b"media-bytes")
    captured={}
    class Response:
        status_code=200
        def json(self): return {"ok":True,"result":{"message_id":77}}
    def fake_post(url,**kwargs):
        captured["url"]=url
        captured.update(kwargs)
        return Response()
    monkeypatch.setattr(appmod.requests,"post",fake_post)
    result=appmod.send_one("fake-token",-100123,"caption",[],media_path=str(media),media_type=kind,ad_text="forced ad",ad_button_text="official",ad_url="https://example.com")
    assert result["message_id"] == 77
    assert captured["url"].endswith("/"+method)
    assert captured["data"]["caption"].endswith("forced ad")
    assert kind in captured["files"]

def test_remember_media_message_saves_source_and_album_metadata():
    _, _, _ = create_job()
    with appmod.db() as c:
        bot_id = c.execute("SELECT id FROM bots ORDER BY id DESC LIMIT 1").fetchone()[0]
    keyboard={"inline_keyboard":[[{"text":"打开","callback_data":"open"}]]}
    message = {"message_id": 42, "media_group_id": "album-1", "chat": {"id": 123, "title": "素材群"},
               "caption": "编辑好的图片说明", "reply_markup":keyboard,
               "photo": [{"file_id": "photo-file", "file_unique_id": "photo-unique", "file_size": 100}]}
    assert appmod.remember_media_message(bot_id, message)
    with appmod.db() as c:
        row=c.execute("SELECT source_chat_id,source_message_id,media_group_id,caption,source_message_json FROM media_assets WHERE bot_id=?",(bot_id,)).fetchone()
    assert row["source_chat_id"]==123 and row["source_message_id"]==42
    assert row["media_group_id"]=="album-1" and row["caption"]=="编辑好的图片说明"
    saved_message=json.loads(row["source_message_json"])
    assert saved_message["message_id"]==42
    assert saved_message["reply_markup"]==keyboard


def test_selecting_one_album_asset_expands_to_full_album_with_caption_and_keyboard():
    bot_id,_,_=create_job()
    keyboard={"inline_keyboard":[[{"text":"查看详情","url":"https://example.com"}]]}
    with appmod.db() as c:
        first=c.execute("INSERT INTO media_assets(bot_id,source_chat_id,source_chat_title,source_message_id,media_type,file_id,file_unique_id,caption,media_group_id,source_message_json,created_at) VALUES(?, -1001,'素材群',10,'photo','photo-1','unique-1','整组说明','album-1',?,?)",
                        (bot_id,json.dumps({"message_id":10,"caption":"整组说明","reply_markup":keyboard}),appmod.now())).lastrowid
        second=c.execute("INSERT INTO media_assets(bot_id,source_chat_id,source_chat_title,source_message_id,media_type,file_id,file_unique_id,caption,media_group_id,source_message_json,created_at) VALUES(?, -1001,'素材群',11,'video','video-1','unique-2',NULL,'album-1',?,?)",
                         (bot_id,json.dumps({"message_id":11}),appmod.now())).lastrowid
        selected=appmod.load_selected_media_assets(c,bot_id,[str(second)])
    assert [item["id"] for item in selected]==[first,second]
    assert json.loads(selected[0]["source_message_json"])["reply_markup"]==keyboard


def test_selecting_media_rejects_asset_from_another_bot():
    bot_id,_,_=create_job()
    other_bot,_,_=create_job()
    with appmod.db() as c:
        asset=c.execute("INSERT INTO media_assets(bot_id,source_chat_id,source_message_id,media_type,file_id,file_unique_id,created_at) VALUES(?,1,1,'photo','x','x',?)",
                        (other_bot,appmod.now())).lastrowid
        with pytest.raises(ValueError,match="不属于对应机器人"):
            appmod.load_selected_media_assets(c,bot_id,[str(asset)])


def test_source_media_group_uses_copy_or_forward_and_preserves_album(monkeypatch):
    calls=[]
    monkeypatch.setattr(appmod,"api",lambda token,method,payload: calls.append((method,payload)) or ([{"message_id":1},{"message_id":2}] if method in ("copyMessages","forwardMessages") else {"message_id":1}))
    assets=[{"source_chat_id":-1001,"source_message_id":10,"media_group_id":"g1"},
            {"source_chat_id":-1001,"source_message_id":11,"media_group_id":"g1"}]
    appmod._send_source_media_group("token",-1002,assets,"hide")
    assert calls[0][0]=="copyMessages"
    assert calls[0][1]["message_ids"]==[10,11]
    calls.clear()
    appmod._send_source_media_group("token",-1002,assets,"show")
    assert calls[0][0]=="forwardMessages"
    assert calls[0][1]["from_chat_id"]==-1001


def test_source_media_single_sender_visibility(monkeypatch):
    calls=[]
    monkeypatch.setattr(appmod,"api",lambda token,method,payload: calls.append(method) or {"ok":True})
    asset={"source_chat_id":123,"source_message_id":42,"media_group_id":None}
    appmod._send_source_media_group("token",-1002,[asset],"hide")
    appmod._send_source_media_group("token",-1002,[asset],"show")
    assert calls==["copyMessage","forwardMessage"]


def test_source_media_restores_original_inline_keyboard_for_single_copy_and_forward(monkeypatch):
    calls=[]
    keyboard={"inline_keyboard":[[{"text":"查看详情","url":"https://example.com"},
                                  {"text":"联系客服","callback_data":"contact"}]]}
    asset={"source_chat_id":123,"source_message_id":42,"media_group_id":None,
           "source_message_json":json.dumps({"message_id":42,"reply_markup":keyboard})}
    def fake_api(token,method,payload):
        calls.append((method,payload))
        if method in ("copyMessage","forwardMessage"):
            return {"message_id":77}
        return {"ok":True}
    monkeypatch.setattr(appmod,"api",fake_api)
    appmod._send_source_media_group("token",-1002,[asset],"hide")
    appmod._send_source_media_group("token",-1002,[asset],"show")
    assert [method for method,_ in calls] == [
        "copyMessage","editMessageReplyMarkup","forwardMessage","editMessageReplyMarkup"
    ]
    assert calls[1][1]["message_id"]==77 and calls[1][1]["reply_markup"]==keyboard
    assert calls[3][1]["message_id"]==77 and calls[3][1]["reply_markup"]==keyboard


def test_source_media_group_restores_keyboard_on_first_album_item(monkeypatch):
    calls=[]
    keyboard={"inline_keyboard":[[{"text":"立即查看","callback_data":"open"}]]}
    assets=[
        {"source_chat_id":-1001,"source_message_id":10,"media_group_id":"g1",
         "source_message_json":json.dumps({"message_id":10,"reply_markup":keyboard})},
        {"source_chat_id":-1001,"source_message_id":11,"media_group_id":"g1",
         "source_message_json":json.dumps({"message_id":11})},
    ]
    def fake_api(token,method,payload):
        calls.append((method,payload))
        if method=="copyMessages": return [{"message_id":91},{"message_id":92}]
        return {"ok":True}
    monkeypatch.setattr(appmod,"api",fake_api)
    appmod._send_source_media_group("token",-1002,assets,"hide")
    assert [method for method,_ in calls]==["copyMessages","editMessageReplyMarkup"]
    assert calls[0][1]["message_ids"]==[10,11]
    assert calls[1][1]["message_id"]==91 and calls[1][1]["reply_markup"]==keyboard


def test_keyboard_restore_failure_after_media_copy_becomes_unknown_not_retry(monkeypatch):
    bot_id,task_id,job_id=create_job()
    keyboard={"inline_keyboard":[[{"text":"打开","callback_data":"open"}]]}
    asset={"id":1,"type":"photo","file_id":"photo-file","caption":"说明",
           "source_chat_id":123,"source_message_id":42,"media_group_id":None,
           "source_message_json":json.dumps({"message_id":42,"reply_markup":keyboard})}
    with appmod.db() as c:
        c.execute("UPDATE tasks SET body='',content_modes='[\"photo\"]',media_assets=?,sender_mode='hide' WHERE id=?",
                  (json.dumps({str(bot_id):[asset]}),task_id))
    def fake_api(token,method,payload):
        if method=="copyMessage": return {"message_id":77}
        if method=="editMessageReplyMarkup": raise appmod.TelegramAPIError(400,"keyboard cannot be restored")
        return {"ok":True}
    monkeypatch.setattr(appmod,"api",fake_api)
    appmod.process_delivery_job(appmod.claim_delivery_job())
    with appmod.db() as c:
        row=c.execute("SELECT status,last_error FROM delivery_jobs WHERE id=?",(job_id,)).fetchone()
    assert row["status"]=="unknown"
    assert "按钮恢复失败" in row["last_error"]


def test_file_id_only_media_restores_caption_entities_and_inline_keyboard(monkeypatch):
    calls=[]
    keyboard={"inline_keyboard":[[{"text":"打开","url":"https://example.com"}]]}
    source={"caption":"编辑好的素材说明","caption_entities":[{"type":"bold","offset":0,"length":5}],
            "reply_markup":keyboard,"show_caption_above_media":True}
    monkeypatch.setattr(appmod,"api",lambda token,method,payload: calls.append((method,payload)) or {"message_id":1})
    appmod._send_source_media_group("token",-1002,[{"type":"photo","file_id":"file-1",
        "caption":"旧说明","source_message_json":json.dumps(source)}],"hide")
    method,payload=calls[0]
    assert method=="sendPhoto"
    assert payload["caption"]=="编辑好的素材说明"
    assert payload["caption_entities"]==source["caption_entities"]
    assert payload["reply_markup"]==keyboard
    assert payload["show_caption_above_media"] is True



def test_join_auto_send_uses_full_abc_sequence_per_new_group(monkeypatch):
    bot_id, task_id, _ = create_job()
    with appmod.db() as c:
        c.execute("UPDATE tasks SET rotation_messages=?,body='' WHERE id=?", ('["A","B","C"]',task_id))
        cur=c.execute("INSERT INTO task_join_auto_sends(task_id,bot_id,chat_id,chat_title,status,next_attempt_at,attempts,created_at,updated_at) VALUES(?,?,?,'new group','sending',0,1,?,?)",
                      (task_id,bot_id,-100777,appmod.now(),appmod.now()))
        job_id=cur.lastrowid
    sent=[]
    monkeypatch.setattr(appmod,"send_one",lambda token,chat_id,body,*args,**kwargs: sent.append((chat_id,body)))
    appmod.process_task_join_auto_send({"id":job_id,"task_id":task_id,"bot_id":bot_id,"chat_id":-100777})
    with appmod.db() as c:
        row=c.execute("SELECT status,rotation_index FROM task_join_auto_sends WHERE id=?",(job_id,)).fetchone()
    assert sent==[(-100777,"A"),(-100777,"B"),(-100777,"C")]
    assert (row["status"],row["rotation_index"])==("sent",3)


def test_partial_album_copy_is_marked_unknown_not_retryable(monkeypatch):
    calls=[]
    monkeypatch.setattr(appmod,"api",lambda token,method,payload: calls.append(method) or [{"message_id":1}])
    assets=[{"source_chat_id":-1001,"source_message_id":10,"media_group_id":"g1"},
            {"source_chat_id":-1001,"source_message_id":11,"media_group_id":"g1"}]
    with pytest.raises(appmod.PartialDeliveryError,match="部分相册消息"):
        appmod._send_source_media_group("token",-1002,assets,"hide")
    assert calls==["copyMessages"]

def test_media_caption_over_limit_rejected(tmp_path):
    media=tmp_path/"sample.pdf"
    media.write_bytes(b"pdf")
    with pytest.raises(ValueError):
        appmod.send_one("fake-token",-100123,"x"*1024,[],media_path=str(media),media_type="document")

def test_rotation_delivery_sends_abc_inside_each_group(monkeypatch):
    bot_id, task_id, first_job = create_job()
    with appmod.db() as c:
        c.execute("UPDATE tasks SET rotation_messages=? WHERE id=?",
                  ('["message A","message B","message C"]',task_id))
        c.execute("INSERT INTO delivery_jobs(task_id,bot_id,chat_id,chat_title,sequence_no,status,attempts,next_attempt_at,created_at,updated_at) VALUES(?,?,?,'second group',1,'pending',0,0,?,?)",
                  (task_id,bot_id,-100124,appmod.now(),appmod.now()))
    sent=[]
    monkeypatch.setattr(appmod,"send_one",lambda token,chat_id,body,*args,**kwargs: sent.append((chat_id,body)))
    first=appmod.claim_delivery_job()
    appmod.process_delivery_job(first)
    second=appmod.claim_delivery_job()
    appmod.process_delivery_job(second)
    assert sent == [(-100123,"message A"),(-100123,"message B"),(-100123,"message C"),
                    (-100124,"message A"),(-100124,"message B"),(-100124,"message C")]
    with appmod.db() as c:
        states=c.execute("SELECT status,rotation_index FROM delivery_jobs WHERE task_id=? ORDER BY sequence_no",(task_id,)).fetchall()
    assert [(row["status"],row["rotation_index"]) for row in states] == [("sent",3),("sent",3)]


def test_rotation_retry_resumes_at_first_unsent_message(monkeypatch):
    _, task_id, job_id = create_job()
    with appmod.db() as c:
        c.execute("UPDATE tasks SET rotation_messages=? WHERE id=?", ('["A","B","C"]',task_id))
    sent=[]
    def fail_once(token,chat_id,body,*args,**kwargs):
        sent.append(body)
        if body == "B" and sent.count("B") == 1:
            raise appmod.TelegramAPIError(400,"test failure")
    monkeypatch.setattr(appmod,"send_one",fail_once)
    appmod.process_delivery_job(appmod.claim_delivery_job())
    with appmod.db() as c:
        row=c.execute("SELECT status,rotation_index FROM delivery_jobs WHERE id=?",(job_id,)).fetchone()
    assert (row["status"],row["rotation_index"]) == ("failed",1)
    assert appmod.retry_failed_jobs(task_id)[0]
    appmod.process_delivery_job(appmod.claim_delivery_job())
    assert sent == ["A","B","B","C"]
    with appmod.db() as c:
        row=c.execute("SELECT status,rotation_index FROM delivery_jobs WHERE id=?",(job_id,)).fetchone()
    assert (row["status"],row["rotation_index"]) == ("sent",3)

def test_admin_can_update_official_group_and_create_announcement():
    old_group=appmod.setting("official_group_url")
    title="管理员公告验收-"+str(time.time_ns())
    try:
        with app_request_context("/admin/announcements", method="POST", data={
            "action":"group", "official_group_url":"https://t.me/tgadbot_acceptance"
        }):
            appmod.session.update(authenticated=True,auth_method="admin_password",is_admin=True)
            appmod.announcements_admin()
        assert appmod.setting("official_group_url")=="https://t.me/tgadbot_acceptance"
        with app_request_context("/admin/announcements", method="POST", data={
            "action":"save", "title":title, "body":"管理员可创建公告", "enabled":"on", "pinned":"on", "published_at":""
        }):
            appmod.session.update(authenticated=True,auth_method="admin_password",is_admin=True)
            appmod.announcements_admin()
        with appmod.db() as c:
            row=c.execute("SELECT title,body,enabled,pinned FROM announcements WHERE title=?",(title,)).fetchone()
        assert row and row["body"]=="管理员可创建公告" and row["enabled"]==1 and row["pinned"]==1
    finally:
        with appmod.db() as c:
            c.execute("DELETE FROM announcements WHERE title=?",(title,))
            if old_group is None:
                c.execute("DELETE FROM settings WHERE key='official_group_url'")
            else:
                c.execute("INSERT INTO settings(key,value) VALUES('official_group_url',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(old_group,))


def test_regular_user_cannot_modify_official_group_or_announcements(monkeypatch):
    user_id=appmod.create_local_user("readonly-admin-check@example.com","testpass123")
    old_group=appmod.setting("official_group_url")
    class Forbidden(Exception): pass
    monkeypatch.setattr(appmod,"abort",lambda code: (_ for _ in ()).throw(Forbidden(code)))
    with app_request_context("/admin/announcements", method="POST", data={
        "action":"group", "official_group_url":"https://t.me/unauthorized"
    }):
        appmod.session.update(authenticated=True,auth_method="local_password",user_id=user_id,is_admin=False)
        with pytest.raises(Forbidden):
            appmod.announcements_admin()
    assert appmod.setting("official_group_url")==old_group


def test_owner_clause_isolates_bot_and_task_records_between_users():
    user_a=appmod.create_local_user("owner-a@example.com","testpass123")
    user_b=appmod.create_local_user("owner-b@example.com","testpass123")
    with appmod.db() as c:
        bot_a=c.execute("INSERT INTO bots(token,telegram_id,username,first_name,token_encryption_version,status,created_at,owner_user_id) VALUES(?,?,?,?,1,'active',?,?)",
                        (appmod.encrypt_token("token-a"),1001,"bot_a","A",appmod.now(),user_a)).lastrowid
        bot_b=c.execute("INSERT INTO bots(token,telegram_id,username,first_name,token_encryption_version,status,created_at,owner_user_id) VALUES(?,?,?,?,1,'active',?,?)",
                        (appmod.encrypt_token("token-b"),1002,"bot_b","B",appmod.now(),user_b)).lastrowid
        task_a=c.execute("INSERT INTO tasks(bot_ids,chat_targets,body,buttons,ad_mode,ad_text,ad_button_text,ad_url,status,created_at,owner_user_id) VALUES('[]','[]','A','[]','BOTH','','','', 'running',?,?)",
                         (appmod.now(),user_a)).lastrowid
        task_b=c.execute("INSERT INTO tasks(bot_ids,chat_targets,body,buttons,ad_mode,ad_text,ad_button_text,ad_url,status,created_at,owner_user_id) VALUES('[]','[]','B','[]','BOTH','','','', 'running',?,?)",
                         (appmod.now(),user_b)).lastrowid
    with app_request_context("/"):
        appmod.session.update(authenticated=True,auth_method="local_password",user_id=user_a,is_admin=False)
        where,params=appmod.owner_clause("owner_user_id")
        with appmod.db() as c:
            bots=[row["id"] for row in c.execute(f"SELECT id FROM bots WHERE {where}",params).fetchall()]
            tasks=[row["id"] for row in c.execute(f"SELECT id FROM tasks WHERE {where}",params).fetchall()]
        assert bots==[bot_a] and tasks==[task_a] and bot_b not in bots and task_b not in tasks
        appmod.session.update(auth_method="admin_password",is_admin=True)
        admin_where,admin_params=appmod.owner_clause("owner_user_id")
        with appmod.db() as c:
            all_bots=[row["id"] for row in c.execute(f"SELECT id FROM bots WHERE {admin_where}",admin_params).fetchall()]
        assert bot_a in all_bots and bot_b in all_bots


def test_edit_task_updates_content_interval_and_sender_mode_without_recreating_history():
    _, task_id, job_id = create_job()
    form={"content_modes":["text"],"body":"已修改的任务正文","rotation_messages":"",
          "buttons":"","sender_mode":"show","send_gap_seconds":"25",
          "repeat_enabled":"off","repeat_duration_unit":"none",
          "repeat_duration_value":"","repeat_max_runs":""}
    with app_request_context(f"/tasks/{task_id}/edit", method="POST", data=form):
        appmod.session.update(authenticated=True,auth_method="admin_password",is_admin=True)
        appmod.edit_task(task_id)
    with appmod.db() as c:
        task=c.execute("SELECT body,send_gap_seconds,sender_mode,status FROM tasks WHERE id=?",(task_id,)).fetchone()
        job=c.execute("SELECT id,status FROM delivery_jobs WHERE id=?",(job_id,)).fetchone()
    assert task["body"]=="已修改的任务正文"
    assert task["send_gap_seconds"]==25.0 and task["sender_mode"]=="show"
    assert task["status"]=="running"
    assert job["id"]==job_id and job["status"]=="pending"


def test_edit_task_refuses_to_change_content_while_delivery_is_sending():
    _, task_id, job_id = create_job()
    with appmod.db() as c:
        c.execute("UPDATE delivery_jobs SET status='sending' WHERE id=?",(job_id,))
    with app_request_context(f"/tasks/{task_id}/edit", method="POST", data={"body":"不得覆盖"}):
        appmod.session.update(authenticated=True,auth_method="admin_password",is_admin=True)
        appmod.edit_task(task_id)
    with appmod.db() as c:
        task=c.execute("SELECT body FROM tasks WHERE id=?",(task_id,)).fetchone()
    assert task["body"]=="hello"


def test_pause_resume_cancel_task_lifecycle():
    _, task_id, job_id = create_job()
    ok,_=appmod.pause_task(task_id)
    assert ok
    with appmod.db() as c:
        assert c.execute("SELECT status FROM tasks WHERE id=?",(task_id,)).fetchone()["status"]=="paused"
        assert c.execute("SELECT status FROM delivery_jobs WHERE id=?",(job_id,)).fetchone()["status"]=="paused"
    assert appmod.claim_delivery_job() is None
    ok,_=appmod.resume_task(task_id)
    assert ok
    with appmod.db() as c:
        assert c.execute("SELECT status FROM tasks WHERE id=?",(task_id,)).fetchone()["status"]=="running"
        assert c.execute("SELECT status FROM delivery_jobs WHERE id=?",(job_id,)).fetchone()["status"]=="pending"
    assert appmod.claim_delivery_job()["id"] == job_id
    ok,_=appmod.cancel_task(task_id)
    assert ok
    with appmod.db() as c:
        assert c.execute("SELECT status FROM tasks WHERE id=?",(task_id,)).fetchone()["status"]=="cancelled"

def test_cannot_resume_non_paused_task():
    _, task_id, _ = create_job()
    ok,_=appmod.resume_task(task_id)
    assert not ok

def test_join_auto_send_waits_five_seconds_and_is_unique():
    bot_id,_,_=create_job()
    appmod.set_setting("auto_join_enabled","1")
    appmod.set_setting("auto_join_message","welcome")
    chat={"id":-100888,"title":"Join Group","type":"supergroup"}
    before=int(time.time())
    assert appmod.queue_auto_join_send(bot_id,chat)
    assert appmod.queue_auto_join_send(bot_id,chat)
    with appmod.db() as c:
        rows=c.execute("SELECT * FROM join_auto_sends WHERE bot_id=? AND chat_id=?",(bot_id,-100888)).fetchall()
    assert len(rows)==1
    assert rows[0]["next_attempt_at"] >= before+5
    assert appmod.claim_join_auto_send() is None

def test_join_auto_send_success_marks_sent(monkeypatch):
    bot_id,_,_=create_job()
    appmod.set_setting("auto_join_enabled","1")
    appmod.set_setting("auto_join_message","welcome")
    appmod.queue_auto_join_send(bot_id,{"id":-100777,"title":"Join Group","type":"group"})
    with appmod.db() as c:
        c.execute("UPDATE join_auto_sends SET next_attempt_at=0")
    job=appmod.claim_join_auto_send()
    called=[]
    monkeypatch.setattr(appmod,"send_one",lambda *a,**kw: called.append(a))
    appmod.process_join_auto_send(job)
    with appmod.db() as c:
        status=c.execute("SELECT status FROM join_auto_sends WHERE id=?",(job["id"],)).fetchone()["status"]
    assert called and status=="sent"

def test_join_auto_send_ignores_channels_and_disabled_switch():
    bot_id,_,_=create_job()
    appmod.set_setting("auto_join_enabled","1")
    appmod.set_setting("auto_join_message","welcome")
    assert not appmod.queue_auto_join_send(bot_id,{"id":-1001,"type":"channel","title":"Channel"})
    appmod.set_setting("auto_join_enabled","0")
    assert not appmod.queue_auto_join_send(bot_id,{"id":-1002,"type":"group","title":"Group"})

def test_interrupted_join_auto_send_recovers_as_unknown():
    bot_id,_,_=create_job()
    appmod.set_setting("auto_join_enabled","1")
    appmod.set_setting("auto_join_message","welcome")
    appmod.queue_auto_join_send(bot_id,{"id":-100555,"title":"Group","type":"group"})
    with appmod.db() as c:
        c.execute("UPDATE join_auto_sends SET status='sending'")
    appmod.init_db()
    with appmod.db() as c:
        status=c.execute("SELECT status FROM join_auto_sends").fetchone()["status"]
    assert status=="unknown"


def test_recurring_series_creates_next_occurrence_after_completed_run():
    bot_id, task_id, _ = create_job()
    with appmod.db() as c:
        c.execute("INSERT INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,?,?,?,?,?)",
                  (bot_id,-100123,"test group","supergroup","active",appmod.now()))
        c.execute("UPDATE tasks SET status='completed' WHERE id=?",(task_id,))
        config={"bot_ids":[str(bot_id)],"chat_targets":[f"{bot_id}:-100123"],"body":"repeat",
                "buttons":[],"ad_mode":"BOTH","ad_text":"ad","ad_button_text":"official",
                "ad_url":"https://example.com","media_path":None,"media_type":None,"rotation_messages":[]}
        cur=c.execute("INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'active',?,?)",
                      (json.dumps(config),900,2,1,int(time.time())-1,task_id,appmod.now(),appmod.now()))
        series_id=cur.lastrowid
        c.execute("UPDATE tasks SET series_id=? WHERE id=?",(series_id,task_id))
    assert appmod.process_recurring_series()==1
    with appmod.db() as c:
        series=c.execute("SELECT * FROM recurring_series WHERE id=?",(series_id,)).fetchone()
        new_task=c.execute("SELECT * FROM tasks WHERE id=?",(series["last_task_id"],)).fetchone()
        jobs=c.execute("SELECT * FROM delivery_jobs WHERE task_id=?",(new_task["id"],)).fetchall()
    assert series["runs_created"]==2
    assert new_task["status"]=="scheduled"
    assert len(jobs)==1 and jobs[0]["status"]=="pending"

def test_recurring_series_pauses_when_previous_run_unknown():
    bot_id, task_id, _ = create_job()
    with appmod.db() as c:
        c.execute("UPDATE tasks SET status='unknown' WHERE id=?",(task_id,))
        cur=c.execute("INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'active',?,?)",
                      ("{}",900,3,1,int(time.time())-1,task_id,appmod.now(),appmod.now()))
        series_id=cur.lastrowid
    assert appmod.process_recurring_series()==0
    with appmod.db() as c:
        status=c.execute("SELECT status FROM recurring_series WHERE id=?",(series_id,)).fetchone()["status"]
    assert status=="paused_unknown"

def test_recurring_series_marks_complete_after_max_runs():
    bot_id, task_id, _ = create_job()
    with appmod.db() as c:
        c.execute("UPDATE tasks SET status='completed' WHERE id=?",(task_id,))
        cur=c.execute("INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'active',?,?)",
                      ("{}",900,1,1,int(time.time())-1,task_id,appmod.now(),appmod.now()))
        series_id=cur.lastrowid
    appmod.process_recurring_series()
    with appmod.db() as c:
        status=c.execute("SELECT status FROM recurring_series WHERE id=?",(series_id,)).fetchone()["status"]
    assert status=="completed"


def test_continuous_series_creates_next_round_immediately_without_interval():
    bot_id, task_id, _ = create_job()
    with appmod.db() as c:
        c.execute("INSERT INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,?,?,?,?,?)",
                  (bot_id,-100123,"test group","supergroup","active",appmod.now()))
        c.execute("UPDATE tasks SET status='completed' WHERE id=?",(task_id,))
        config={"bot_ids":[str(bot_id)],"chat_targets":[f"{bot_id}:-100123"],"body":"repeat",
                "buttons":[],"ad_mode":"BOTH","ad_text":"ad","ad_button_text":"official",
                "ad_url":"https://example.com","rotation_messages":[],"content_modes":["text"],
                "media_assets":{},"send_gap_seconds":10}
        cur=c.execute("INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at,loop_mode,stop_after_seconds) VALUES(?,0,0,1,?,?,'active',?,?,'continuous',0)",
                      (json.dumps(config),int(time.time())-1,task_id,appmod.now(),appmod.now()))
        series_id=cur.lastrowid
        c.execute("UPDATE tasks SET series_id=? WHERE id=?",(series_id,task_id))
    assert appmod.process_recurring_series()==1
    with appmod.db() as c:
        series=c.execute("SELECT * FROM recurring_series WHERE id=?",(series_id,)).fetchone()
        new_task=c.execute("SELECT * FROM tasks WHERE id=?",(series["last_task_id"],)).fetchone()
    assert series["runs_created"]==2 and series["loop_mode"]=="continuous"
    assert series["interval_seconds"]==0 and new_task["status"]=="scheduled"


def test_continuous_series_duration_expiry_stops_remaining_groups():
    bot_id, task_id, first_job = create_job()
    with appmod.db() as c:
        c.execute("INSERT INTO delivery_jobs(task_id,bot_id,chat_id,chat_title,sequence_no,status,attempts,next_attempt_at,created_at,updated_at) VALUES(?,?,?,'second group',1,'pending',0,0,?,?)",
                  (task_id,bot_id,-100124,appmod.now(),appmod.now()))
        c.execute("UPDATE tasks SET status='running' WHERE id=?",(task_id,))
        c.execute("UPDATE delivery_jobs SET status='sending' WHERE id=?",(first_job,))
        cur=c.execute("INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at,loop_mode,stop_after_seconds,started_at,ends_at) VALUES('{}',0,0,1,?,?,'active',?,?,'continuous',60,?,?)",
                      (int(time.time())-1,task_id,appmod.now(),appmod.now(),int(time.time())-120,int(time.time())-1))
        series_id=cur.lastrowid
        c.execute("UPDATE tasks SET series_id=? WHERE id=?",(series_id,task_id))
    assert appmod.process_recurring_series()==0
    with appmod.db() as c:
        series=c.execute("SELECT status FROM recurring_series WHERE id=?",(series_id,)).fetchone()
        jobs=c.execute("SELECT status,last_error FROM delivery_jobs WHERE task_id=? ORDER BY sequence_no",(task_id,)).fetchall()
    assert series["status"]=="completed"
    assert jobs[0]["status"]=="sending"  # current task's in-flight target is not force-stopped
    assert jobs[1]["status"]=="cancelled" and "定时已到" in jobs[1]["last_error"]


@pytest.mark.parametrize(
    "case,duration_expired,runs_created,max_runs,expected_status,expected_created",
    [
        ("duration_first", True, 1, 3, "completed", 0),
        ("round_count_first", False, 2, 2, "completed", 0),
        ("both_limits_reached", True, 2, 2, "completed", 0),
        ("neither_limit_reached", False, 1, 3, "active", 1),
    ],
)
def test_continuous_series_combined_stop_conditions(
    case, duration_expired, runs_created, max_runs, expected_status, expected_created
):
    bot_id, task_id, first_job = create_job()
    current = int(time.time())
    with appmod.db() as c:
        c.execute(
            "INSERT INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,?,?,?,?,?)",
            (bot_id, -100123, "test group", "supergroup", "active", appmod.now()),
        )
        if duration_expired:
            c.execute("UPDATE tasks SET status='running' WHERE id=?", (task_id,))
            c.execute("UPDATE delivery_jobs SET status='sending' WHERE id=?", (first_job,))
            c.execute(
                "INSERT INTO delivery_jobs(task_id,bot_id,chat_id,chat_title,sequence_no,status,attempts,next_attempt_at,created_at,updated_at) "
                "VALUES(?,?,?,'second group',1,'pending',0,0,?,?)",
                (task_id, bot_id, -100124, appmod.now(), appmod.now()),
            )
        else:
            c.execute("UPDATE tasks SET status='completed' WHERE id=?", (task_id,))
            c.execute("UPDATE delivery_jobs SET status='sent' WHERE id=?", (first_job,))

        config = {
            "bot_ids": [str(bot_id)],
            "chat_targets": [f"{bot_id}:-100123"],
            "body": "repeat",
            "buttons": [],
            "ad_mode": "BOTH",
            "ad_text": "ad",
            "ad_button_text": "official",
            "ad_url": "https://example.com",
            "media_path": None,
            "media_type": None,
            "rotation_messages": [],
            "content_modes": ["text"],
            "media_assets": {},
            "send_gap_seconds": 10,
        }
        ends_at = current - 1 if duration_expired else current + 540
        cur = c.execute(
            "INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at,loop_mode,stop_after_seconds,started_at,ends_at) "
            "VALUES(?,0,?,?,?,?,'active',?,?,'continuous',600,?,?)",
            (
                json.dumps(config),
                max_runs,
                runs_created,
                current - 1,
                task_id,
                appmod.now(),
                appmod.now(),
                current - 60,
                ends_at,
            ),
        )
        series_id = cur.lastrowid
        c.execute("UPDATE tasks SET series_id=? WHERE id=?", (series_id, task_id))

    assert appmod.process_recurring_series() == expected_created
    with appmod.db() as c:
        series = c.execute("SELECT * FROM recurring_series WHERE id=?", (series_id,)).fetchone()
        series_tasks = c.execute(
            "SELECT id,status FROM tasks WHERE series_id=? ORDER BY id", (series_id,)
        ).fetchall()
        jobs = c.execute(
            "SELECT status,last_error FROM delivery_jobs WHERE task_id=? ORDER BY sequence_no",
            (task_id,),
        ).fetchall()

    assert series["status"] == expected_status, case
    assert series["max_runs"] == max_runs
    assert series["stop_after_seconds"] == 600
    assert len(series_tasks) == 1 + expected_created
    if expected_created:
        assert series["runs_created"] == runs_created + 1
        assert series_tasks[-1]["status"] == "scheduled"
    else:
        assert series["runs_created"] == runs_created
    if duration_expired:
        assert [job["status"] for job in jobs] == ["sending", "cancelled"]
        assert "循环定时已到" in jobs[1]["last_error"]
    elif expected_status == "completed":
        assert jobs[0]["status"] == "sent"


def test_continuous_series_pause_resume_freezes_duration():
    _, task_id, _ = create_job()
    with appmod.db() as c:
        cur=c.execute("INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at,loop_mode,stop_after_seconds,started_at,ends_at) VALUES('{}',0,0,1,?,?,'active',?,?,'continuous',3600,?,?)",
                      (int(time.time()),task_id,appmod.now(),appmod.now(),int(time.time())-60,int(time.time())+3540))
        series_id=cur.lastrowid
    assert appmod.pause_series(series_id)[0]
    with appmod.db() as c:
        c.execute("UPDATE recurring_series SET paused_at=? WHERE id=?",(int(time.time())-120,series_id))
    assert appmod.resume_series(series_id)[0]
    with appmod.db() as c:
        row=c.execute("SELECT status,ends_at,paused_at FROM recurring_series WHERE id=?",(series_id,)).fetchone()
    assert row["status"]=="active" and row["paused_at"] is None
    assert row["ends_at"] >= int(time.time())+3650


def test_delete_invalid_bot_clears_token_stops_pending_jobs_and_keeps_history():
    bot_id, task_id, job_id = create_job()
    with appmod.db() as c:
        c.execute("UPDATE bots SET status='invalid_token' WHERE id=?", (bot_id,))
        c.execute("INSERT INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,?,'保留历史群','supergroup','active',?)",
                  (bot_id,-100123,appmod.now()))
        c.execute("INSERT INTO join_auto_sends(bot_id,chat_id,chat_title,status,next_attempt_at,attempts,created_at,updated_at) VALUES(?,?,'新群','pending',0,0,?,?)",
                  (bot_id,-100777,appmod.now(),appmod.now()))
        c.execute("INSERT INTO task_join_auto_sends(task_id,bot_id,chat_id,chat_title,status,next_attempt_at,attempts,created_at,updated_at) VALUES(?,?,?,'任务新群','pending',0,0,?,?)",
                  (task_id,bot_id,-100888,appmod.now(),appmod.now()))
    event=threading.Event()
    appmod.stop_events[bot_id]=event
    with app_request_context(f"/bots/{bot_id}/delete", method="POST"):
        appmod.session.update(authenticated=True,auth_method='admin_password',is_admin=True)
        appmod.delete_bot(bot_id)
    with appmod.db() as c:
        bot=c.execute("SELECT status,token FROM bots WHERE id=?",(bot_id,)).fetchone()
        task=c.execute("SELECT id FROM tasks WHERE id=?",(task_id,)).fetchone()
        delivery=c.execute("SELECT status FROM delivery_jobs WHERE id=?",(job_id,)).fetchone()
        chat=c.execute("SELECT status FROM chats WHERE bot_id=? AND chat_id=?",(bot_id,-100123)).fetchone()
        join=c.execute("SELECT status FROM join_auto_sends WHERE bot_id=? AND chat_id=?",(bot_id,-100777)).fetchone()
        task_join=c.execute("SELECT status FROM task_join_auto_sends WHERE task_id=? AND chat_id=?",(task_id,-100888)).fetchone()
    assert bot["status"]=="deleted" and bot["token"]==f"deleted:{bot_id}"
    assert task is not None and delivery["status"]=="failed"
    assert chat["status"]=="deleted"
    assert join["status"]=="failed" and task_join["status"]=="failed"
    assert event.is_set()


def test_delete_bot_waits_for_in_flight_delivery_before_clearing_token():
    bot_id, task_id, job_id = create_job()
    with appmod.db() as c:
        c.execute("UPDATE delivery_jobs SET status='sending' WHERE id=?",(job_id,))
    with app_request_context(f"/bots/{bot_id}/delete", method="POST"):
        appmod.session.update(authenticated=True,auth_method='admin_password',is_admin=True)
        appmod.delete_bot(bot_id)
    with appmod.db() as c:
        bot=c.execute("SELECT status,token FROM bots WHERE id=?",(bot_id,)).fetchone()
        job=c.execute("SELECT status FROM delivery_jobs WHERE id=?",(job_id,)).fetchone()
    assert bot["status"]=="active" and appmod.decrypt_token(bot["token"])=="fake-test-bot-token"
    assert job["status"]=="sending"


def test_token_401_marks_bot_invalid_and_stops_queued_jobs(monkeypatch):
    bot_id, task_id, job_id = create_job()
    with appmod.db() as c:
        c.execute("INSERT INTO delivery_jobs(task_id,bot_id,chat_id,chat_title,sequence_no,status,attempts,next_attempt_at,created_at,updated_at) VALUES(?,?,?,'second',1,'pending',0,0,?,?)",
                  (task_id,bot_id,-100124,appmod.now(),appmod.now()))
    monkeypatch.setattr(appmod,"send_one",lambda *args,**kwargs: (_ for _ in ()).throw(appmod.TelegramAPIError(401,"unauthorized")))
    appmod.process_delivery_job(appmod.claim_delivery_job())
    with appmod.db() as c:
        bot=c.execute("SELECT status FROM bots WHERE id=?",(bot_id,)).fetchone()
        jobs=c.execute("SELECT status FROM delivery_jobs WHERE task_id=? ORDER BY sequence_no",(task_id,)).fetchall()
    assert bot["status"]=="invalid_token"
    assert [row["status"] for row in jobs]==["failed","failed"]


def test_init_db_migrates_v121_schema_and_clamps_old_send_gaps(tmp_path, monkeypatch):
    legacy_path=tmp_path/"legacy.sqlite3"
    original_path=appmod.DB_PATH
    appmod.DB_PATH=str(legacy_path)
    try:
        appmod.init_db()
        with appmod.db() as c:
            c.execute("INSERT INTO tasks(bot_ids,chat_targets,body,buttons,ad_mode,ad_text,ad_button_text,ad_url,status,created_at,send_gap_seconds) VALUES('[]','[]','x','[]','OFF','', '', '', 'completed', ?, 5)",(appmod.now(),))
            c.execute("ALTER TABLE tasks DROP COLUMN sender_mode")
            c.execute("ALTER TABLE delivery_jobs DROP COLUMN rotation_index")
            c.execute("ALTER TABLE media_assets DROP COLUMN media_group_id")
            c.execute("ALTER TABLE media_assets DROP COLUMN source_message_json")
            for column in ("loop_mode","stop_after_seconds","started_at","ends_at","paused_at"):
                c.execute(f"ALTER TABLE recurring_series DROP COLUMN {column}")
        appmod.init_db()
        with appmod.db() as c:
            task=c.execute("SELECT send_gap_seconds,sender_mode FROM tasks LIMIT 1").fetchone()
            delivery_columns={row["name"] for row in c.execute("PRAGMA table_info(delivery_jobs)")}
            media_columns={row["name"] for row in c.execute("PRAGMA table_info(media_assets)")}
            series_columns={row["name"] for row in c.execute("PRAGMA table_info(recurring_series)")}
        assert task["send_gap_seconds"]==10 and task["sender_mode"]=="hide"
        assert "rotation_index" in delivery_columns
        assert {"media_group_id","source_message_json"}.issubset(media_columns)
        assert {"loop_mode","stop_after_seconds","started_at","ends_at","paused_at"}.issubset(series_columns)
    finally:
        appmod.DB_PATH=original_path

def test_retry_failed_jobs_does_not_retry_unknown():
    _, task_id, job_id = create_job()
    with appmod.db() as c:
        c.execute("UPDATE delivery_jobs SET status='unknown' WHERE id=?",(job_id,))
    ok,message=appmod.retry_failed_jobs(task_id)
    assert not ok
    assert "没有可安全重试" in message
    with appmod.db() as c:
        c.execute("UPDATE delivery_jobs SET status='failed' WHERE id=?",(job_id,))
    ok,message=appmod.retry_failed_jobs(task_id)
    assert ok
    with appmod.db() as c:
        status=c.execute("SELECT status FROM delivery_jobs WHERE id=?",(job_id,)).fetchone()["status"]
    assert status=="pending"

def test_telegram_login_signature_and_allowlist(monkeypatch):
    import hashlib, hmac
    monkeypatch.setattr(appmod,"TELEGRAM_LOGIN_ALLOWED_USER_IDS",{"12345"})
    data={"id":"12345","first_name":"Test","auth_date":str(int(time.time()))}
    check="\n".join(f"{k}={data[k]}" for k in sorted(data))
    secret=hashlib.sha256(b"test-login-token").digest()
    data["hash"]=hmac.new(secret,check.encode(),hashlib.sha256).hexdigest()
    ok,user_id=appmod.verify_telegram_login(data,bot_token="test-login-token")
    assert ok and user_id=="12345"
    bad=dict(data); bad["first_name"]="Attacker"
    assert not appmod.verify_telegram_login(bad,bot_token="test-login-token")[0]

def test_telegram_login_rejects_stale_credentials(monkeypatch):
    monkeypatch.setattr(appmod,"TELEGRAM_LOGIN_ALLOWED_USER_IDS",{"12345"})
    data={"id":"12345","first_name":"Test","auth_date":"1","hash":"fake"}
    assert not appmod.verify_telegram_login(data,bot_token="test-login-token",now_ts=100000)[0]

def test_cancelling_recurring_task_stops_future_occurrences():
    bot_id,task_id,_=create_job()
    with appmod.db() as c:
        cur=c.execute("INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'active',?,?)",
                      ("{}",900,3,1,int(time.time())+900,task_id,appmod.now(),appmod.now()))
        series_id=cur.lastrowid
        c.execute("UPDATE tasks SET series_id=? WHERE id=?",(series_id,task_id))
    ok,_=appmod.cancel_task(task_id)
    assert ok
    with appmod.db() as c:
        status=c.execute("SELECT status FROM recurring_series WHERE id=?",(series_id,)).fetchone()["status"]
    assert status=="cancelled"

def test_recurring_series_pause_resume_cancel_controls():
    bot_id,task_id,_=create_job()
    with appmod.db() as c:
        cur=c.execute("INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'active',?,?)",
                      ("{}",900,3,1,int(time.time())+900,task_id,appmod.now(),appmod.now()))
        series_id=cur.lastrowid
        c.execute("UPDATE tasks SET series_id=? WHERE id=?",(series_id,task_id))
    assert appmod.pause_series(series_id)[0]
    assert appmod.resume_series(series_id)[0]
    assert appmod.cancel_series(series_id)[0]
    with appmod.db() as c:
        status=c.execute("SELECT status FROM recurring_series WHERE id=?",(series_id,)).fetchone()["status"]
        task_status=c.execute("SELECT status FROM tasks WHERE id=?",(task_id,)).fetchone()["status"]
    assert status=="cancelled" and task_status=="cancelled"

def test_unknown_recurring_series_cannot_be_resumed():
    _,task_id,_=create_job()
    with appmod.db() as c:
        cur=c.execute("INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'paused_unknown',?,?)",
                      ("{}",900,3,1,int(time.time())+900,task_id,appmod.now(),appmod.now()))
        series_id=cur.lastrowid
    ok,_=appmod.resume_series(series_id)
    assert not ok


def test_rotation_message_parser_splits_real_newlines():
    raw = "Message A\n---轮换消息---\nMessage B\n---轮换消息---\n\nMessage C"
    assert appmod.parse_rotation_messages(raw) == ["Message A", "Message B", "Message C"]
    assert appmod.parse_rotation_messages("") == []


def test_telegram_login_hash_is_single_use_and_expires_from_replay_table():
    signed_hash = "a" * 64
    assert appmod.consume_telegram_login_hash(signed_hash, now_ts=100000)
    assert not appmod.consume_telegram_login_hash(signed_hash, now_ts=100001)
    # The replay record can be purged after its retention window.
    assert appmod.consume_telegram_login_hash(signed_hash, now_ts=186401)


def test_telegram_login_hash_rejects_malformed_values():
    assert not appmod.consume_telegram_login_hash("not-a-sha256-hash")
    assert not appmod.consume_telegram_login_hash("")


def test_flask_http_routes_require_login_and_csrf():
    if not hasattr(appmod.app, "test_client"):
        pytest.skip("Flask runtime dependencies are not installed in this environment")
    appmod.app.config.update(TESTING=True, WTF_CSRF_ENABLED=True)
    client = appmod.app.test_client()
    protected = client.get("/history")
    assert protected.status_code == 302
    assert "/login" in protected.headers.get("Location", "")
    rejected = client.post("/login", data={"admin_password": os.environ["ADMIN_PASSWORD"]})
    assert rejected.status_code == 400


def test_flask_http_login_accepts_csrf_and_authenticates_admin():
    if not hasattr(appmod.app, "test_client"):
        pytest.skip("Flask runtime dependencies are not installed in this environment")
    import re as regex
    appmod.app.config.update(TESTING=True, WTF_CSRF_ENABLED=True)
    client = appmod.app.test_client()
    login_page = client.get("/login")
    assert login_page.status_code == 200
    match = regex.search(r'name="csrf_token" value="([^"]+)"', login_page.get_data(as_text=True))
    assert match
    response = client.post("/login", data={
        "admin_password": os.environ["ADMIN_PASSWORD"],
        "csrf_token": match.group(1),
    })
    assert response.status_code == 302
    assert client.get("/history").status_code == 200


def test_telegram_login_hash_concurrent_replay_allows_only_one_consumer():
    signed_hash = "b" * 64
    barrier = threading.Barrier(3)
    outcomes = []
    def consume():
        barrier.wait()
        outcomes.append(appmod.consume_telegram_login_hash(signed_hash, now_ts=200000))
    workers = [threading.Thread(target=consume) for _ in range(2)]
    for worker in workers:
        worker.start()
    barrier.wait()
    for worker in workers:
        worker.join()
    assert sum(bool(value) for value in outcomes) == 1


def test_broadcast_template_context_regression():
    if not hasattr(appmod.app, "test_client"):
        pytest.skip("Flask runtime dependencies are not installed in this environment")
    client = appmod.app.test_client()
    with client.session_transaction() as session:
        session['authenticated'] = True
        session['auth_method'] = 'admin_password'
        session['is_admin'] = True
    for url in ['/broadcast', '/broadcast?template_id=latest', '/broadcast?template_id=invalid']:
        assert client.get(url).status_code == 200


def test_clone_profile_http_permissions_followup():
    if not hasattr(appmod.app, "test_client"):
        pytest.skip("Flask runtime dependencies are not installed in this environment")
    import re
    appmod.app.config.update(TESTING=True, WTF_CSRF_ENABLED=True)
    c = appmod.app.test_client()
    assert c.get("/bots/2147483647/profile").status_code == 302
    page = c.get("/login").get_data(as_text=True)
    csrf = re.search('name="csrf_token" value="([^"]+)"', page).group(1)
    assert c.post("/tasks/2147483647/clone", data={"csrf_token":csrf}).status_code == 302
    assert c.post("/login", data={"admin_password":os.environ["ADMIN_PASSWORD"], "csrf_token":csrf}).status_code == 302
    csrf = re.search('name="csrf_token" value="([^"]+)"', c.get("/broadcast").get_data(as_text=True)).group(1)
    assert c.get("/bots/2147483647/profile").status_code == 404
    assert c.post("/tasks/2147483647/clone").status_code == 400
    assert c.post("/tasks/2147483647/clone", data={"csrf_token":csrf}).status_code == 404


def test_send_task_content_uses_telegram_file_ids_and_ad_mode(monkeypatch):
    calls=[]
    monkeypatch.setattr(appmod,"api",lambda token,method,payload=None,timeout=35: calls.append((method,payload)) or {"message_id":len(calls)})
    appmod.send_task_content("token",-1001,"hello",[],"BUTTON_ONLY","","Official","https://example.com",
                             ["text","photo","video"],
                             [{"type":"photo","file_id":"photo-id"},{"type":"video","file_id":"video-id"}])
    assert [x[0] for x in calls]==["sendMessage","sendPhoto","sendVideo"]
    assert calls[0][1]["text"]=="hello"
    assert calls[0][1]["reply_markup"]["inline_keyboard"][0][0]["text"]=="Official"
    assert calls[1][1]["photo"]=="photo-id" and "reply_markup" not in calls[1][1]
    assert calls[2][1]["video"]=="video-id"


def test_platform_ad_modes_are_independent():
    assert appmod.ad_markup([],"TEXT_ONLY") is None
    assert appmod.ad_markup([],"BUTTON_ONLY", "Official", "https://example.com")["inline_keyboard"][0][0]["text"]=="Official"
    assert appmod.ad_markup([],"BOTH", "Official", "https://example.com")["inline_keyboard"][0][0]["text"]=="Official"


def test_task_join_auto_send_is_queued_for_selected_bot():
    bot_id,task_id,_=create_job()
    with appmod.db() as c:
        c.execute("UPDATE tasks SET bot_ids=?,auto_join_enabled=1,content_modes='[\"text\"]' WHERE id=?",(json.dumps([str(bot_id)]),task_id))
        c.execute("UPDATE tasks SET status='completed' WHERE id=?",(task_id,))
    assert appmod.queue_task_join_auto_send(bot_id,{"id":-100999,"title":"new group","type":"supergroup"})==1
    with appmod.db() as c:
        row=c.execute("SELECT * FROM delivery_jobs WHERE task_id=? AND chat_id=-100999",(task_id,)).fetchone()
    assert row and row["status"]=="pending" and row["next_attempt_at"]>=int(time.time())-1


def test_success_log_cleanup_only_removes_old_successes():
    bot_id,task_id,job_id=create_job()
    old=(appmod.datetime.now(appmod.timezone.utc)-appmod.timedelta(days=45)).isoformat(timespec="seconds")
    with appmod.db() as c:
        c.execute("UPDATE tasks SET status='completed' WHERE id=?",(task_id,))
        c.execute("UPDATE delivery_jobs SET status='sent',updated_at=? WHERE id=?",(old,job_id))
        c.execute("INSERT INTO delivery_jobs(task_id,bot_id,chat_id,chat_title,status,attempts,next_attempt_at,created_at,updated_at) VALUES(?,?,?,'failed group','failed',1,0,?,?)",
                  (task_id,bot_id,-100124,old,old))
    removed=appmod.cleanup_success_logs()
    with appmod.db() as c:
        statuses=[r["status"] for r in c.execute("SELECT status FROM delivery_jobs WHERE task_id=?",(task_id,)).fetchall()]
    assert removed==0 and sorted(statuses)==["failed","sent"]
    with appmod.db() as c:
        assert c.execute("SELECT hidden_before FROM log_visibility WHERE owner_user_id='legacy_admin'").fetchone()


def test_public_telegram_login_mode_allows_registration_when_allowlist_empty(monkeypatch):
    import hashlib,hmac
    monkeypatch.setattr(appmod,"TELEGRAM_LOGIN_ALLOWED_USER_IDS",set())
    data={"id":"67890","first_name":"New User","auth_date":str(int(time.time()))}
    check="\n".join(f"{k}={data[k]}" for k in sorted(data))
    secret=hashlib.sha256(b"test-login-token").digest()
    data["hash"]=hmac.new(secret,check.encode(),hashlib.sha256).hexdigest()
    assert appmod.verify_telegram_login(data,bot_token="test-login-token")== (True,"67890")


def test_ordinary_telegram_accounts_have_separate_owner_scope(monkeypatch):
    monkeypatch.setattr(appmod,"TELEGRAM_LOGIN_ALLOWED_USER_IDS",set())
    with appmod.db() as c:
        c.execute("INSERT INTO user_accounts(id,telegram_user_id,username,role,status,created_at,last_login_at) VALUES('111222','111222','one','user','active',?,?)",(appmod.now(),appmod.now()))
        c.execute("INSERT INTO user_accounts(id,telegram_user_id,username,role,status,created_at,last_login_at) VALUES('333444','333444','two','admin','active',?,?)",(appmod.now(),appmod.now()))
    with app_request_context("/"):
        appmod.session.clear()
        appmod.session.update({"authenticated":True,"auth_method":"telegram","user_id":"111222","telegram_user_id":"111222"})
        assert appmod.current_owner_id()=="111222"
        assert not appmod.is_admin_user()
        assert appmod.owner_clause()==("owner_user_id=?",["111222"])
        appmod.session.update({"user_id":"333444","telegram_user_id":"333444"})
        assert appmod.is_admin_user()
        assert appmod.current_owner_id()=="333444"
        assert appmod.owner_clause()==("1=1",[])
        appmod.session.clear()


def test_telegram_login_allowlist_does_not_grant_admin(monkeypatch):
    monkeypatch.setattr(appmod,"TELEGRAM_LOGIN_ALLOWED_USER_IDS",{"111222"})
    with appmod.db() as c:
        c.execute("INSERT INTO user_accounts(id,telegram_user_id,role,status,created_at,last_login_at) VALUES('111222','111222','user','active',?,?)",(appmod.now(),appmod.now()))
    with app_request_context("/"):
        appmod.session.clear()
        appmod.session.update({"authenticated":True,"auth_method":"telegram","user_id":"111222","telegram_user_id":"111222"})
        assert not appmod.is_admin_user()
        appmod.session.clear()


def test_local_account_password_hash_and_tenant_scope():
    user_id = appmod.create_local_user("Test.User@example.com", "Correct-Horse-Battery-2026", "Test User")
    assert user_id.startswith("local:")
    assert appmod.authenticate_local_user("test.user@example.com", "Correct-Horse-Battery-2026")["id"] == user_id
    assert appmod.authenticate_local_user("test.user@example.com", "wrong-password") is None
    with app_request_context("/"):
        appmod.session.clear()
        appmod.session.update({"authenticated":True,"auth_method":"local_password","user_id":user_id})
        assert appmod.current_owner_id() == user_id
        assert appmod.owner_clause() == ("owner_user_id=?", [user_id])
        appmod.session.clear()


def test_old_telegram_users_table_is_preserved_and_backfilled(monkeypatch, tmp_path):
    old_db = tmp_path / "old-users.sqlite3"
    con = sqlite3.connect(old_db)
    con.execute("CREATE TABLE users(telegram_user_id TEXT PRIMARY KEY,username TEXT,first_name TEXT,last_name TEXT,created_at TEXT NOT NULL,last_login_at TEXT NOT NULL)")
    con.execute("INSERT INTO users VALUES('998877','legacy','Legacy','User','2026-01-01','2026-01-02')")
    con.commit(); con.close()
    original = appmod.DB_PATH
    monkeypatch.setattr(appmod, "DB_PATH", str(old_db))
    appmod.init_db()
    with appmod.db() as c:
        old = c.execute("SELECT username FROM users WHERE telegram_user_id='998877'").fetchone()
        migrated = c.execute("SELECT id,telegram_user_id,role,status FROM user_accounts WHERE id='998877'").fetchone()
    assert old["username"] == "legacy"
    assert tuple(migrated) == ("998877", "998877", "user", "active")
    monkeypatch.setattr(appmod, "DB_PATH", original)
    appmod.init_db()


def test_public_registration_and_account_login_http():
    if not hasattr(appmod.app, "test_client"):
        pytest.skip("Flask runtime dependencies are not installed in this environment")
    import re
    appmod.app.config.update(TESTING=True, WTF_CSRF_ENABLED=True)
    client = appmod.app.test_client()
    page = client.get("/register")
    csrf = re.search(r'name="csrf_token" value="([^"]+)"', page.get_data(as_text=True)).group(1)
    response = client.post("/register", data={
        "email":"customer@example.com", "username":"Customer",
        "password":"Correct-Horse-Battery-2026", "password_confirm":"Correct-Horse-Battery-2026",
        "csrf_token":csrf,
    })
    assert response.status_code == 302
    history_page = client.get("/history")
    assert history_page.status_code == 200
    assert client.get("/admin/users").status_code == 403
    csrf = re.search(r'name="csrf_token" value="([^\"]+)"', history_page.get_data(as_text=True)).group(1)
    client.post("/logout", data={"csrf_token":csrf})
    login_page = client.get("/login")
    csrf = re.search(r'name="csrf_token" value="([^"]+)"', login_page.get_data(as_text=True)).group(1)
    response = client.post("/login", data={"email":"customer@example.com", "password":"Correct-Horse-Battery-2026", "csrf_token":csrf})
    assert response.status_code == 302
    assert client.get("/history").status_code == 200


def test_send_gap_parser_accepts_presets_and_custom_seconds():
    assert appmod.parse_send_gap_seconds("10") == 10
    assert appmod.parse_send_gap_seconds("30.0") == 30.0
    assert appmod.parse_send_gap_seconds("custom", "10.5") == 10.5


def test_send_gap_parser_rejects_unsafe_or_invalid_values():
    for preset, custom in (("custom", ""), ("custom", "abc"), ("custom", "0"), ("custom", "1.1"), ("custom", "3600.1"), ("custom", "nan"), ("custom", "inf")):
        with pytest.raises(ValueError):
            appmod.parse_send_gap_seconds(preset, custom)


def test_tasks_store_ten_second_default_and_legacy_values_are_clamped():
    _, task_id, _ = create_job()
    with appmod.db() as c:
        row = c.execute("SELECT send_gap_seconds FROM tasks WHERE id=?", (task_id,)).fetchone()
        assert row["send_gap_seconds"] == 10.0
        c.execute("UPDATE tasks SET send_gap_seconds=? WHERE id=?", (8.5, task_id))
    assert appmod.task_send_gap_seconds(task_id) == 10.0


def test_task_templates_retain_send_gap_in_saved_configuration():
    _, task_id, _ = create_job()
    with appmod.db() as c:
        c.execute("UPDATE tasks SET send_gap_seconds=? WHERE id=?", (12.5, task_id))
        task = c.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
    assert float(task["send_gap_seconds"]) == 12.5


def test_task_gap_defers_only_same_task_jobs_and_keeps_other_users_moving():
    _, task_a, job_a = create_job()
    _, task_b, job_b = create_job()
    with appmod.db() as c:
        c.execute("UPDATE tasks SET send_gap_seconds=? WHERE id=?", (6.5, task_a))
        c.execute("UPDATE delivery_jobs SET status='sent' WHERE id=?", (job_a,))
        c.execute("INSERT INTO delivery_jobs(task_id,bot_id,chat_id,chat_title,sequence_no,status,attempts,next_attempt_at,created_at,updated_at) "
                  "SELECT task_id,bot_id,-100124,'second group',1,'pending',0,0,?,? FROM delivery_jobs WHERE id=?",
                  (appmod.now(), appmod.now(), job_a))
    appmod.defer_task_delivery_jobs(task_a)
    with appmod.db() as c:
        delayed = c.execute("SELECT next_attempt_at FROM delivery_jobs WHERE task_id=? AND status='pending'", (task_a,)).fetchone()
        other = c.execute("SELECT next_attempt_at FROM delivery_jobs WHERE id=?", (job_b,)).fetchone()
    assert delayed["next_attempt_at"] >= int(time.time()) + 10
    assert other["next_attempt_at"] == 0
    claimed = appmod.claim_delivery_job()
    assert claimed["task_id"] == task_b


def test_broadcast_post_persists_custom_task_gap(monkeypatch):
    if not hasattr(appmod.app, "test_client"):
        pytest.skip("Flask runtime dependencies are not installed in this environment")
    bot_id, _, _ = create_job()
    with appmod.db() as c:
        c.execute("INSERT INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,?,?,?,?,?)",
                  (bot_id, -100123, "test group", "supergroup", "active", appmod.now()))
    monkeypatch.setattr(appmod, "start_delivery_worker", lambda: None)
    appmod.app.config.update(TESTING=True, WTF_CSRF_ENABLED=False)
    client = appmod.app.test_client()
    with client.session_transaction() as session:
        session["authenticated"] = True
        session["auth_method"] = "admin_password"
        session["is_admin"] = True
    page = client.get("/broadcast")
    assert page.status_code == 200
    html = page.get_data(as_text=True)
    assert 'id="send-gap-seconds"' in html
    assert 'name="send_gap_seconds"' in html
    assert 'min="10"' in html
    response = client.post("/broadcast", data={
        "bot_ids": [str(bot_id)],
        "chat_keys": [f"{bot_id}:-100123"],
        "content_modes": ["text"],
        "body": "test broadcast",
        "send_gap_seconds": "15",
        "scheduled_at": "",
        "tz_offset_minutes": "0",
        "repeat_duration_unit": "none",
        "repeat_max_runs": "1",
        "buttons": "",
        "rotation_messages": "",
    })
    assert response.status_code == 302
    with appmod.db() as c:
        row = c.execute("SELECT send_gap_seconds FROM tasks ORDER BY id DESC LIMIT 1").fetchone()
    assert row["send_gap_seconds"] == 15.0


def test_clone_task_template_preserves_custom_send_gap():
    if not hasattr(appmod.app, "test_client"):
        pytest.skip("Flask runtime dependencies are not installed in this environment")
    _, task_id, _ = create_job()
    with appmod.db() as c:
        c.execute("UPDATE tasks SET send_gap_seconds=? WHERE id=?", (12.5, task_id))
    appmod.app.config.update(TESTING=True, WTF_CSRF_ENABLED=False)
    client = appmod.app.test_client()
    with client.session_transaction() as session:
        session["authenticated"] = True
        session["auth_method"] = "admin_password"
        session["is_admin"] = True
    response = client.post(f"/tasks/{task_id}/clone")
    assert response.status_code == 302
    with appmod.db() as c:
        row = c.execute("SELECT config_json FROM task_templates ORDER BY id DESC LIMIT 1").fetchone()
    assert json.loads(row["config_json"])["send_gap_seconds"] == 12.5


def test_telegram_retry_after_defers_same_bot_queue_only(monkeypatch):
    bot_a, task_a, job_a = create_job()
    bot_b, task_b, job_b = create_job()
    with appmod.db() as c:
        c.execute("INSERT INTO delivery_jobs(task_id,bot_id,chat_id,chat_title,sequence_no,status,attempts,next_attempt_at,created_at,updated_at) "
                  "VALUES(?,?,?,'same Bot next group',1,'pending',0,0,?,?)",
                  (task_a, bot_a, -100125, appmod.now(), appmod.now()))
    monkeypatch.setattr(appmod, "send_one", lambda *a, **k: (_ for _ in ()).throw(appmod.TelegramAPIError(429, "Too Many Requests", retry_after=12)))
    claimed = appmod.claim_delivery_job()
    assert claimed["id"] == job_a
    appmod.process_delivery_job(claimed)
    with appmod.db() as c:
        same_bot_jobs = c.execute("SELECT next_attempt_at FROM delivery_jobs WHERE bot_id=? AND status='pending'", (bot_a,)).fetchall()
        other_bot_job = c.execute("SELECT next_attempt_at FROM delivery_jobs WHERE id=?", (job_b,)).fetchone()
    assert len(same_bot_jobs) == 2
    assert all(row["next_attempt_at"] >= int(time.time()) + 10 for row in same_bot_jobs)
    assert other_bot_job["next_attempt_at"] == 0


def test_recurring_series_copies_custom_send_gap():
    bot_id, task_id, _ = create_job()
    with appmod.db() as c:
        c.execute("INSERT INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,?,?,?,?,?)",
                  (bot_id, -100123, "test group", "supergroup", "active", appmod.now()))
        c.execute("UPDATE tasks SET status='completed',send_gap_seconds=? WHERE id=?", (9.5, task_id))
        config = {"bot_ids":[str(bot_id)], "chat_targets":[f"{bot_id}:-100123"], "body":"repeat",
                  "buttons":[], "ad_mode":"BOTH", "ad_text":"ad", "ad_button_text":"official",
                  "ad_url":"https://example.com", "media_path":None, "media_type":None,
                  "rotation_messages":[], "send_gap_seconds":9.5}
        cur = c.execute("INSERT INTO recurring_series(config_json,interval_seconds,max_runs,runs_created,next_run_at,last_task_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'active',?,?)",
                        (json.dumps(config), 900, 2, 1, int(time.time())-1, task_id, appmod.now(), appmod.now()))
        series_id = cur.lastrowid
        c.execute("UPDATE tasks SET series_id=? WHERE id=?", (series_id, task_id))
    assert appmod.process_recurring_series() == 1
    with appmod.db() as c:
        series = c.execute("SELECT * FROM recurring_series WHERE id=?", (series_id,)).fetchone()
        new_task = c.execute("SELECT * FROM tasks WHERE id=?", (series["last_task_id"],)).fetchone()
    assert new_task["send_gap_seconds"] == 10.0


def test_password_minimum_six_and_existing_hash_compatibility():
    with pytest.raises(ValueError):
        appmod.create_local_user("short@example.com", "12345")
    uid = appmod.create_local_user("six@example.com", "123456")
    assert appmod.authenticate_local_user("six@example.com", "123456")["id"] == uid
    old_hash = appmod.hash_password("Existing-Long-Password")
    assert appmod.verify_password("Existing-Long-Password", old_hash)


@pytest.mark.parametrize("value", ["1.2", "5", "9.9", "nan", "inf", "3600.1"])
def test_new_send_gap_minimum_ten(value):
    with pytest.raises(ValueError):
        appmod.parse_send_gap_seconds("custom", value)


def test_readd_deleted_bot_keeps_history_and_can_delete_again(monkeypatch):
    old_bot_id, task_id, job_id = create_job()
    with appmod.db() as c:
        c.execute("UPDATE bots SET telegram_id=987654321,status='deleted',token='' WHERE id=?", (old_bot_id,))
    monkeypatch.setattr(appmod, "api", lambda *args, **kwargs: {"id": 987654321, "username": "testbot"})
    monkeypatch.setattr(appmod, "start_pollers", lambda: None)
    with app_request_context("/bots/add", method="POST", data={"token": "987654321:abcdefghijklmnopqrstuvwxyz"}):
        appmod.session.update(authenticated=True, auth_method="admin_password", is_admin=True)
        appmod.add_bot()
    with appmod.db() as c:
        new_bot = c.execute("SELECT id FROM bots WHERE telegram_id=987654321 AND status='active'").fetchone()
        assert new_bot is not None and new_bot["id"] != old_bot_id
        new_id = new_bot["id"]
        assert c.execute("SELECT bot_id FROM delivery_jobs WHERE id=?", (job_id,)).fetchone()[0] == old_bot_id
    with app_request_context(f"/bots/{new_id}/delete", method="POST"):
        appmod.session.update(authenticated=True, auth_method="admin_password", is_admin=True)
        appmod.delete_bot(new_id)
    with appmod.db() as c:
        assert c.execute("SELECT status,token FROM bots WHERE id=?", (new_id,)).fetchone()[:] == ("deleted", f"deleted:{new_id}")
