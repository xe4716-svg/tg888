"""Browser-only smoke tests for the reusable UI editor components.

This intentionally runs without Flask so the JavaScript controls can still be
verified in environments where the HTTP application dependencies are absent.
"""
import os
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "static" / "issue-editors.js"

HTML = r"""<!doctype html>
<html lang="zh-CN">
<head><meta charset="utf-8"><title>TGAdBot UI component acceptance</title></head>
<body>
  <form id="editor-form">
    <label for="buttons">自定义按钮</label>
    <textarea name="buttons" id="buttons"></textarea>
    <label><input type="checkbox" name="repeat_enabled">启用循环</label>
    <select name="repeat_duration_unit"><option value="none">不限制</option><option value="days">天</option></select>
    <input name="repeat_duration_value" value="">
    <input name="repeat_max_runs" value="">
    <details><summary>高级选项：文字轮换</summary></details>
    <textarea id="rotation-messages">第一条轮换消息
---轮换消息---
第二条轮换消息</textarea>
    <button type="submit">提交</button>
  </form>

</body>
</html>"""


def main():
    errors = []
    with sync_playwright() as playwright:
        launch_options = {"headless": True, "args": ["--no-sandbox"]}
        chromium_path = os.environ.get("CHROMIUM_PATH")
        if not chromium_path and Path("/usr/bin/chromium").is_file():
            chromium_path = "/usr/bin/chromium"
        if chromium_path:
            launch_options["executable_path"] = chromium_path
        browser = playwright.chromium.launch(**launch_options)
        page = browser.new_page()
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.set_content(HTML)
        page.add_script_tag(path=str(SCRIPT))
        page.locator("#editor-form").evaluate("form => form.addEventListener(\'submit\', event => { window.lastSubmitWasPrevented = event.defaultPrevented; event.preventDefault(); })")

        # Button editor: add, edit, arrange, delete, switch modes and validate.
        page.get_by_role("button", name="添加按钮", exact=True).click()
        page.get_by_placeholder("按钮文字").first.fill("官网")
        page.get_by_placeholder("https://链接 或已有回调数据").first.fill("https://example.com")
        page.get_by_role("button", name="添加按钮", exact=True).click()
        page.get_by_placeholder("按钮文字").nth(1).fill("客服")
        page.get_by_placeholder("https://链接 或已有回调数据").nth(1).fill("https://example.com/support")
        assert page.locator("[data-button-preview]").inner_text() == "官网\n客服"

        page.locator('select[aria-label="每排按钮数量"]').select_option("2")
        assert page.locator("[data-button-preview]").inner_text() == "官网 | 客服"
        page.get_by_role("button", name="上移", exact=True).nth(1).click()
        assert page.get_by_placeholder("按钮文字").first.input_value() == "客服"
        page.get_by_role("button", name="删除", exact=True).nth(1).click()
        assert page.get_by_placeholder("按钮文字").count() == 1

        assert page.locator('select[aria-label="按钮显示方式"]').count() == 0
        page.get_by_placeholder("https://链接 或已有回调数据").first.fill("javascript:alert(1)")
        page.get_by_role("button", name="提交", exact=True).click()
        assert "HTTP/HTTPS" in page.locator('[role="alert"]').inner_text()
        assert page.evaluate("window.lastSubmitWasPrevented") is True
        page.get_by_placeholder("https://链接 或已有回调数据").first.fill("https://example.com/safe")
        page.get_by_role("button", name="提交", exact=True).click()
        assert page.evaluate("window.lastSubmitWasPrevented") is False

        # Rotation editor: edit, preview, reorder, delete and keep source synced.
        rotation_host = page.locator("#rotation-messages + div")
        assert rotation_host.locator("textarea").count() == 2
        rotation_host.locator("textarea").first.fill("已编辑第一条")
        assert rotation_host.locator("pre").first.inner_text() == "已编辑第一条"
        rotation_host.get_by_role("button", name="上移", exact=True).nth(1).click()
        assert rotation_host.locator("textarea").first.input_value() == "第二条轮换消息"
        rotation_host.get_by_role("button", name="删除", exact=True).nth(1).click()
        assert page.locator("#rotation-messages").input_value() == "第二条轮换消息"

        # Repeat controls are disabled until the feature is explicitly enabled.
        assert page.locator('[name="repeat_duration_unit"]').is_disabled()
        page.locator('[name="repeat_enabled"]').check()
        assert page.locator('[name="repeat_duration_unit"]').is_enabled()
        assert page.locator('[name="repeat_duration_value"]').is_enabled()
        assert page.locator('[name="repeat_max_runs"]').is_enabled()

        assert not errors, errors
        browser.close()
    print("UI component browser smoke passed: button CRUD/layout/mode/validation, rotation editing, recurrence controls; no JavaScript errors.")


if __name__ == "__main__":
    main()
