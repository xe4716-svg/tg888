from __future__ import annotations

import sqlite3
from contextlib import closing
import tarfile
from pathlib import Path

import pytest

from restore_backup import restore_backup


def make_db(path: Path, value: str) -> None:
    with closing(sqlite3.connect(path)) as connection, connection:
        connection.execute("CREATE TABLE IF NOT EXISTS sample(value TEXT NOT NULL)")
        connection.execute("DELETE FROM sample")
        connection.execute("INSERT INTO sample(value) VALUES(?)", (value,))


def db_value(path: Path) -> str:
    with closing(sqlite3.connect(path)) as connection, connection:
        assert connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        return connection.execute("SELECT value FROM sample").fetchone()[0]


def make_media_archive(archive_path: Path, source_file: Path, arcname: str = "old.txt") -> None:
    with tarfile.open(archive_path, "w:gz") as archive:
        archive.add(source_file, arcname=arcname)


def test_restore_reverts_sqlite_and_replaces_media_snapshot(tmp_path: Path) -> None:
    backup_dir = tmp_path / "backup"
    backup_dir.mkdir()
    backup_db = backup_dir / "tgadbot.sqlite3"
    make_db(backup_db, "before-upgrade")

    media_source = tmp_path / "media-source.txt"
    media_source.write_text("old media", encoding="utf-8")
    make_media_archive(backup_dir / "media.tar.gz", media_source)

    live_db = tmp_path / "data" / "tgadbot.sqlite3"
    live_db.parent.mkdir()
    make_db(live_db, "after-migration")
    media_dir = tmp_path / "data" / "media"
    media_dir.mkdir()
    (media_dir / "new.txt").write_text("new media", encoding="utf-8")

    result = restore_backup(backup_dir, live_db, media_dir)

    assert result["integrity"] == "ok"
    assert db_value(live_db) == "before-upgrade"
    assert sorted(p.name for p in media_dir.iterdir()) == ["old.txt"]
    assert (media_dir / "old.txt").read_text(encoding="utf-8") == "old media"


def test_corrupt_database_backup_does_not_touch_live_data(tmp_path: Path) -> None:
    backup_dir = tmp_path / "backup"
    backup_dir.mkdir()
    (backup_dir / "tgadbot.sqlite3").write_text("not a sqlite database", encoding="utf-8")

    live_db = tmp_path / "data" / "tgadbot.sqlite3"
    live_db.parent.mkdir()
    make_db(live_db, "keep-live-data")
    media_dir = tmp_path / "data" / "media"
    media_dir.mkdir()
    (media_dir / "keep.txt").write_text("keep media", encoding="utf-8")

    with pytest.raises(sqlite3.DatabaseError):
        restore_backup(backup_dir, live_db, media_dir)

    assert db_value(live_db) == "keep-live-data"
    assert (media_dir / "keep.txt").read_text(encoding="utf-8") == "keep media"


def test_unsafe_media_archive_does_not_replace_database_or_media(tmp_path: Path) -> None:
    backup_dir = tmp_path / "backup"
    backup_dir.mkdir()
    make_db(backup_dir / "tgadbot.sqlite3", "backup-value")
    with tarfile.open(backup_dir / "media.tar.gz", "w:gz") as archive:
        info = tarfile.TarInfo("../escape.txt")
        payload = b"unsafe"
        info.size = len(payload)
        import io
        archive.addfile(info, io.BytesIO(payload))

    live_db = tmp_path / "data" / "tgadbot.sqlite3"
    live_db.parent.mkdir()
    make_db(live_db, "keep-live-data")
    media_dir = tmp_path / "data" / "media"
    media_dir.mkdir()
    (media_dir / "keep.txt").write_text("keep media", encoding="utf-8")

    with pytest.raises((tarfile.TarError, ValueError)):
        restore_backup(backup_dir, live_db, media_dir)

    assert db_value(live_db) == "keep-live-data"
    assert (media_dir / "keep.txt").read_text(encoding="utf-8") == "keep media"
    assert not (tmp_path / "escape.txt").exists()

def test_host_side_sqlite_validation_reads_private_backup_with_selinux(tmp_path: Path) -> None:
    """The backup is intentionally root-only; the validator must be isolated root."""
    script = Path(__file__).resolve().parents[1] / "upgrade.sh"
    source = script.read_text(encoding="utf-8")
    marker = "# Validate the host-side copy with the already-present production image."
    assert marker in source
    validation_block = source.split(marker, 1)[1].split(
        'docker exec "$CONTAINER_NAME" rm -f "$DB_BACKUP_PATH_IN_CONTAINER"', 1
    )[0]

    # Root is required because BACKUP_DIR is 0700 and the SQLite file is 0600.
    assert "--user 0:0" in validation_block
    # Keep the validator least-privileged and prevent writes/network access.
    assert "--network none" in validation_block
    assert "--read-only" in validation_block
    assert "--cap-drop ALL" in validation_block
    assert "--security-opt no-new-privileges" in validation_block
    # Private SELinux relabel is required on enforcing CentOS/RHEL hosts.
    assert '-v "$BACKUP_DIR:/backup:ro,Z"' in validation_block
    assert '-v "$BACKUP_DIR:/backup:ro"' not in validation_block
    # The host-side backup remains private; do not loosen production backup modes.
    assert 'chmod 0700 "$BACKUP_DIR"' in source
    assert 'chmod 0600 "$BACKUP_DIR/tgadbot.sqlite3"' in source
