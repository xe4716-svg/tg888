from pathlib import Path

SOURCE = (Path(__file__).parents[1] / "app.py").read_text(encoding="utf-8")

def test_authenticated_shell_has_responsive_sidebar_and_brand():
    base = (Path(__file__).parents[1]/"templates/base.html").read_text(encoding="utf-8") + (Path(__file__).parents[1]/"static/app.css").read_text(encoding="utf-8")
    assert "class=\"sidebar\"" in base
    assert "class=\"side-nav\"" in base
    assert "brand-approved.png" in base
    assert "@media(max-width:820px)" in base
    assert "@media(max-width:560px)" in base

def test_dashboard_has_account_scoped_operational_summary():
    start = SOURCE.index("def index():")
    end = SOURCE.index("@app.post(\"/bots/add\")", start)
    dashboard = SOURCE[start:end]
    assert "task_stats" in dashboard
    assert "我的机器人" in dashboard
    assert "已发现群组" in dashboard
    assert "最近群发任务" in dashboard

def test_broadcast_ui_keeps_native_telegram_media_and_independent_modes():
    start = SOURCE.index("def broadcast():")
    end = SOURCE.index("@app.get(\"/bots/<int:bot_id>/profile\")", start)
    broadcast = SOURCE[start:end]
    assert 'name=\"content_modes\" value=\"text\"' in broadcast
    assert 'name=\"content_modes\" value=\"photo\"' in broadcast
    assert 'name=\"content_modes\" value=\"video\"' in broadcast
    assert 'name=\"media_assets_{{b.id}}\"' in broadcast
    assert "直接复制或转发 Telegram 原消息" in SOURCE
    assert 'type=\"file\"' not in broadcast
    assert 'name=\"auto_join_enabled\"' in broadcast


def test_broadcast_ui_uses_direct_seconds_input_with_ten_second_floor():
    start = SOURCE.index("def broadcast():")
    end = SOURCE.index("@app.get(\"/bots/<int:bot_id>/profile\")", start)
    broadcast = SOURCE[start:end]
    assert 'id=\"send-gap-seconds\"' in broadcast
    assert 'name=\"send_gap_seconds\"' in broadcast
    assert 'min=\"10\"' in broadcast
    assert 'name=\"send_gap_custom\"' not in broadcast
    assert 'name=\"send_gap_preset\"' not in broadcast

def test_dashboard_distinguishes_saved_bots_from_live_telegram_connectivity():
    start = SOURCE.index("def index():")
    end = SOURCE.index("@app.post(\"/bots/add\")", start)
    dashboard = SOURCE[start:end]
    assert "last_api_status" in dashboard
    assert "连接正常" in dashboard
    assert "连接异常" in dashboard
    assert "已保存，等待连接" in dashboard
    assert "此输入框不会回显已保存 Token" in dashboard
    assert "不会删除已有机器人或群组" in dashboard



def test_broadcast_has_sender_visibility_selector_and_task_edit_route():
    start = SOURCE.index("def broadcast():")
    end = SOURCE.index("@app.get(\"/bots/<int:bot_id>/profile\")", start)
    broadcast = SOURCE[start:end]
    assert 'name="sender_mode"' in broadcast
    assert "隐藏来源（复制素材）" in broadcast
    assert "显示来源（转发素材）" in broadcast
    assert '@app.route("/tasks/<int:task_id>/edit", methods=["GET", "POST"])' in SOURCE
    assert "修改只影响尚未发送的群组" in SOURCE


def test_bot_delete_keeps_history_and_clears_token():
    assert '@app.post("/bots/<int:bot_id>/delete")' in SOURCE
    assert "status='deleted',token='deleted:' || id" in SOURCE
    assert "历史任务和发送日志保留" in SOURCE


def test_loop_controls_are_duration_or_round_count_not_interval():
    start = SOURCE.index("def broadcast():")
    end = SOURCE.index("@app.get(\"/bots/<int:bot_id>/profile\")", start)
    broadcast = SOURCE[start:end]
    assert 'name="repeat_duration_unit"' in broadcast
    assert 'value="minutes"' in broadcast
    assert 'value="hours"' in broadcast
    assert 'value="days"' in broadcast
    assert 'name="repeat_max_runs"' in broadcast
    assert 'repeat_interval_minutes' not in broadcast


def test_delete_bot_removes_it_from_dashboard_chat_list():
    assert "bots.status<>'deleted' AND chats.status<>'deleted'" in SOURCE
    assert "status='invalid_token'" in SOURCE


def test_media_selection_expands_albums_and_restores_source_keyboard():
    source = SOURCE
    assert "选中相册任意一项会自动包含整组内容" in source
    assert "def load_selected_media_assets" in source
    assert "def _attach_source_keyboard" in source
    assert '"editMessageReplyMarkup"' in source
    assert "source_message_json" in source


def test_brand_logo_and_favicon_assets_exist_and_are_valid_png_ico():
    root=Path(__file__).parents[1]
    png=(root/'static'/'brand-approved.png').read_bytes()
    ico=(root/'static'/'favicon.ico').read_bytes()
    assert png.startswith(b'\x89PNG\r\n\x1a\n')
    assert ico.startswith(b'\x00\x00\x01\x00')
    base=(Path(__file__).parents[1]/"templates/base.html").read_text(encoding="utf-8")
    assert 'class="brand-logo" src="{{ url_for(\'static\', filename=\'brand-approved.png\') }}"' in base
    assert 'class="guest-header"' in base and 'rel="icon"' in base
