import io
import json
import time
import zipfile
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import pytest
from test_runtime_storage import appmod as a, create_job as base_job, clean_database
from test_remaining_issues import client_for
import delivery_v2
import material_library
import button_actions


def create_job():
    bot, task, job = base_job()
    return task, bot, job


def modern(count=3, rotation=None):
    task, bot, job = create_job()
    # create_job returns task_id, bot_id, job_id (asserted by downstream storage).
    with a.db() as c:
        c.execute("UPDATE tasks SET semantics='per_target',max_success=?,rotation_messages=? WHERE id=?",(count,json.dumps(rotation or ['A','B','C']),task))
    return task, bot, job


def get(table, ident):
    with a.db() as c: return dict(c.execute(f'SELECT * FROM {table} WHERE id=?',(ident,)).fetchone())


def test_history_counts_successful_cycles_while_target_is_pending():
    task, _, job = modern()
    with a.db() as conn:
        conn.execute("UPDATE delivery_jobs SET success_count=2,status='pending' WHERE id=?", (job,))
    html = client_for().get("/history").get_data(as_text=True)
    assert "成功次数" in html
    import re
    row = re.search(rf"<strong>#{task}</strong>.*?</tr>", html, re.S).group()
    assert re.search(r"<td>2</td>", row)


def test_admin_gap_updates_pending_cycles_preserves_rate_limit_and_history():
    task, bot, job = modern()
    with a.db() as conn:
        conn.execute("UPDATE delivery_jobs SET success_count=2,status='pending',updated_at=?,next_attempt_at=0 WHERE id=?", (a.now(), job))
        conn.execute("UPDATE tasks SET send_gap_seconds=20 WHERE id=?", (task,))
    client = client_for()
    form = {"default_send_gap_seconds": "30", "forced_ad_mode": "TEXT_ONLY", "ad_text": "平台公告"}
    assert client.post("/ads", data=form).status_code == 302
    # Task had 20s (< 30s new minimum), so it is raised to 30s
    assert a.task_send_gap_seconds(task) == 30
    row = get("delivery_jobs", job)
    assert row["success_count"] == 2
    assert row["next_attempt_at"] >= int(time.time()) + 28
    assert a.claim_delivery_job() is None
    # User sets a longer interval (60s >= 30s); lowering platform min to 15s preserves user's 60s
    with a.db() as conn:
        conn.execute("UPDATE tasks SET send_gap_seconds=60 WHERE id=?", (task,))
        conn.execute("UPDATE delivery_jobs SET next_attempt_at=?,last_error='限流等待' WHERE id=?", (int(time.time())+300, job))
    before = get("delivery_jobs", job)["next_attempt_at"]
    form["default_send_gap_seconds"] = "15"
    client.post("/ads", data=form)
    assert get("delivery_jobs", job)["next_attempt_at"] == before
    assert a.task_send_gap_seconds(task) == 60
    # Submitting an interval below platform minimum (e.g. 10 < 15) is rejected
    with pytest.raises(ValueError, match="最低间隔"):
        a.parse_send_gap_seconds("10")
    form["default_send_gap_seconds"] = "10"
    client.post("/ads", data=form)


def test_new_group_queue_deduplicates_and_stays_handled(monkeypatch):
    task, bot, _ = modern(count=2, rotation=["第一轮", "第二轮"])
    chat = {"id": -987, "type": "supergroup", "title": "测试新群"}
    assert not a.queue_task_join_auto_send(bot, chat)
    with a.db() as conn:
        conn.execute("UPDATE tasks SET auto_join_enabled=1, bot_ids=?, status='running' WHERE id=?",
                     (json.dumps([bot]), task))
    assert a.queue_task_join_auto_send(bot, chat)
    assert a.queue_task_join_auto_send(bot, chat)
    with a.db() as conn:
        jobs = conn.execute("SELECT * FROM delivery_jobs WHERE task_id=? AND chat_id=-987", (task,)).fetchall()
        assert len(jobs) == 1
        new_job_id = jobs[0]["id"]
    assert "测试新群" in client_for().get(f"/tasks/{task}").get_data(as_text=True)
    # Verify multi-round execution on the newly joined group
    sent = []
    monkeypatch.setattr(a, "_api_request", lambda token, method, payload, timeout=35: sent.append(( payload.get("chat_id"), payload.get("text") )) or {"message_id": len(sent)})
    for _ in range(4):
        with a.db() as conn:
            conn.execute("UPDATE delivery_jobs SET next_attempt_at=0 WHERE task_id=?", (task,))
        claimed = a.claim_delivery_job()
        if claimed:
            a.process_delivery_job(claimed)
    assert get("delivery_jobs", new_job_id)["success_count"] == 2
    assert get("delivery_jobs", new_job_id)["status"] == "sent"
    # Paused task registers target as paused; cancelled task does not enqueue
    with a.db() as conn:
        conn.execute("UPDATE tasks SET status='paused' WHERE id=?", (task,))
    assert a.queue_task_join_auto_send(bot, {"id": -988, "type": "supergroup", "title": "暂停入群"})
    with a.db() as conn:
        assert conn.execute("SELECT status FROM delivery_jobs WHERE task_id=? AND chat_id=-988", (task,)).fetchone()[0] == "paused"
        conn.execute("UPDATE tasks SET status='cancelled' WHERE id=?", (task,))
    assert not a.queue_task_join_auto_send(bot, {"id": -989, "type": "supergroup", "title": "取消入群"})


def test_concurrent_poller_start_and_restart(monkeypatch):
    started = []

    def poll(bot_id, token, stop):
        started.append((bot_id, token))
        stop.wait(5)

    monkeypatch.setattr(a, "poll_bot", poll)
    monkeypatch.setattr(a, "polling_threads", {})
    monkeypatch.setattr(a, "stop_events", {})
    token = a.encrypt_token("test-token")
    callers = threading.Barrier(4)

    def start():
        callers.wait(timeout=3)
        a.start_bot_poller(987, token)

    try:
        with ThreadPoolExecutor(max_workers=4) as workers:
            list(workers.map(lambda _: start(), range(4)))
        assert started == [(987, "test-token")]
        a.stop_events[987].set()
        a.polling_threads[987].join(timeout=3)
        a.start_bot_poller(987, token)
        a.stop_events[987].set()
        a.polling_threads[987].join(timeout=3)
        assert started == [(987, "test-token"), (987, "test-token")]
    finally:
        for stop in a.stop_events.values():
            stop.set()


def test_live_collection_checks_source_and_rolls_back_if_media_index_fails(monkeypatch):
    _, bot, _ = create_job()
    message = {"chat": {"id": -987}, "message_id": 12, "video": {"file_id": "video"}}
    assert not material_library.collect(a, bot, message, require_source=True)
    with a.db() as conn:
        conn.execute("INSERT INTO collection_sources(bot_id,chat_id,title) VALUES(?,?,?)", (bot, -987, "测试频道"))

    def fail_index(*args, **kwargs):
        raise RuntimeError("media index unavailable")

    with monkeypatch.context() as patch:
        patch.setattr(a, "remember_media_message", fail_index)
        with pytest.raises(RuntimeError, match="media index unavailable"):
            material_library.collect(a, bot, message, require_source=True)
    with a.db() as conn:
        assert not conn.execute("SELECT 1 FROM materials WHERE bot_id=?", (bot,)).fetchone()
    assert material_library.collect(a, bot, message, require_source=True)
    with a.db() as conn:
        assert conn.execute("SELECT file_id FROM media_assets WHERE bot_id=?", (bot,)).fetchone()[0] == "video"


def test_deleting_bot_stops_unknown_delivery_and_preserves_history():
    task, bot, job = create_job()
    with a.db() as conn:
        conn.execute("UPDATE delivery_jobs SET status='unknown',last_error='网络中断' WHERE id=?", (job,))
    response = client_for().post(f"/bots/{bot}/delete", data={"delete_mode": "token"})
    assert response.status_code == 302 and response.location == "/"
    assert get("bots", bot)["status"] == "deleted"
    assert get("tasks", task)
    delivery = get("delivery_jobs", job)
    assert delivery["status"] == "cancelled"
    assert "网络中断" in delivery["last_error"] and "发送结果未确认" in delivery["last_error"]
    # Mode 2: delete all exclusive records while preserving other bot in shared multi-bot task
    _, bot2, _ = create_job()
    with a.db() as conn:
        conn.execute("UPDATE tasks SET bot_ids=?, chat_targets=? WHERE id=?",
                     (json.dumps([str(bot), str(bot2)]), json.dumps([f"{bot}:-100123", f"{bot2}:-100456"]), task))
        conn.execute("INSERT INTO delivery_jobs(task_id,bot_id,chat_id,chat_title,status,created_at,updated_at) VALUES(?,?,?,'bot2群','sent',?,?)",
                     (task, bot2, -100456, a.now(), a.now()))
    resp_all = client_for().post(f"/bots/{bot}/delete", data={"delete_mode": "all", "confirm_all": "yes"})
    assert resp_all.status_code == 302
    with a.db() as conn:
        assert not conn.execute("SELECT 1 FROM bots WHERE id=?", (bot,)).fetchone()
        assert not conn.execute("SELECT 1 FROM delivery_jobs WHERE bot_id=?", (bot,)).fetchone()
        surviving_task = conn.execute("SELECT * FROM tasks WHERE id=?", (task,)).fetchone()
        assert surviving_task and json.loads(surviving_task["bot_ids"]) == [str(bot2)]
        assert conn.execute("SELECT COUNT(*) FROM delivery_jobs WHERE task_id=? AND bot_id=?", (task, bot2)).fetchone()[0] == 1


def test_poller_collects_enabled_channel_into_library(monkeypatch):
    _, bot, _ = create_job()
    client = client_for()
    source = -100876
    a.remember_chat(bot, {"id": source, "type": "channel", "title": "验收频道"})
    response = client.post("/library", data={
        "action": "source", "bot_id": bot, "chat_id": source,
        "title": "验收频道", "enabled": "on",
    })
    assert response.status_code == 302
    message = {"chat": {"id": source, "type": "channel"}, "message_id": 12,
               "caption": "采集验收原文", "photo": [{"file_id": "test-photo"}]}
    stop = threading.Event()
    offsets = []

    def updates(token, method, payload, timeout):
        assert method == "getUpdates"
        offsets.append(payload["offset"])
        assert "channel_post" in payload["allowed_updates"]
        if len(offsets) == 1:
            return [
                {"update_id": 40, "channel_post": message},
                {"update_id": 41, "channel_post": message},
                {"update_id": 42, "edited_channel_post": dict(message, caption="采集验收编辑")},
                {"update_id": 43, "channel_post": dict(message, chat={"id": -100877, "type": "channel"},
                                                     caption="未授权来源内容")},
            ]
        stop.set()
        return []

    monkeypatch.setattr(a, "api", updates)
    a.poll_bot(bot, "test-token", stop)
    assert len(offsets) == 2 and offsets[1] == 44
    page = client.get("/library").get_data(as_text=True)
    assert "采集验收编辑" in page and "版本 2" in page
    assert "未授权来源内容" not in page
    with a.db() as conn:
        assert conn.execute("SELECT COUNT(*) FROM materials WHERE bot_id=?", (bot,)).fetchone()[0] == 1
        assert conn.execute("SELECT file_id FROM media_assets WHERE bot_id=?", (bot,)).fetchone()[0] == "test-photo"


def test_readding_bot_restores_only_groups_it_can_still_send_to(monkeypatch):
    _, bot, _ = create_job()
    with a.db() as conn:
        conn.execute("UPDATE bots SET status='deleted',telegram_id=1234567 WHERE id=?", (bot,))
        conn.executemany("INSERT OR REPLACE INTO chats(bot_id,chat_id,title,chat_type,status,last_seen) VALUES(?,?,?,'group','active',?)",
                         [(bot, -701, "可发送", a.now()), (bot, -702, "已退出", a.now())])

    def fake_api(token, method, payload=None, timeout=10):
        if method == "getMe":
            return {"id": 1234567, "username": "test_bot"}
        if method == "getChatMember":
            if payload["chat_id"] == -701:
                return {"status": "restricted", "is_member": True, "can_send_messages": True}
            return {"status": "left"}
        assert method == "getChat"
        return {"id": payload["chat_id"], "type": "group", "title": "可发送"}

    monkeypatch.setattr(a, "api", fake_api)
    monkeypatch.setattr(a, "start_pollers", lambda: None)
    response = client_for().post("/bots/add", data={"token": "1234567:" + "a" * 24}, follow_redirects=True)
    assert "已恢复 1 个群组" in response.get_data(as_text=True)
    with a.db() as conn:
        restored = conn.execute("SELECT chat_id FROM chats WHERE bot_id<>?", (bot,)).fetchall()
    assert [row[0] for row in restored] == [-701]


def test_platform_settings_restrict_editing_and_enforce_bot_limit(monkeypatch):
    _, bot, _ = create_job()
    owner = a.create_local_user("bot-owner@example.com", "secret-password")
    with a.db() as conn:
        conn.execute("UPDATE bots SET owner_user_id=? WHERE id=?", (owner, bot))
    user = client_for(owner)
    assert user.post("/ads", data={"user_bot_limit": "0"}).status_code == 403
    admin = client_for()
    admin.post("/ads", data={"user_bot_limit": "1", "default_send_gap_seconds": "25",
                            "forced_ad_mode": "TEXT_ONLY", "ad_text": "广告"})
    assert a.setting("user_bot_limit") == "1"
    assert a.setting("default_send_gap_seconds") == "25"
    monkeypatch.setattr(a, "api", lambda *args, **kwargs: {"id": 1234567, "username": "test_bot"})
    response = user.post("/bots/add", data={"token": "1234567:" + "a" * 24}, follow_redirects=True)
    assert "当前已达到上限" in response.get_data(as_text=True)
    with a.db() as conn:
        assert conn.execute("SELECT COUNT(*) FROM bots WHERE owner_user_id=?", (owner,)).fetchone()[0] == 1


def test_token_reveal_requires_owner_and_reauth_and_no_cache():
    task,bot,job=create_job()
    client=client_for()
    denied=client.post(f'/bots/{bot}/token/reveal',data={'password':'wrong'})
    assert denied.status_code==403 and 'no-store' in denied.headers['Cache-Control']
    success=client.post(f'/bots/{bot}/token/reveal',data={'password':a.ADMIN_PASSWORD})
    assert success.json['token']=='fake-test-bot-token'
    assert client.post(f'/bots/{bot}/token/reveal').status_code==200
    uid=a.create_local_user('owner@example.com','secret-password')
    with a.db() as c: c.execute('UPDATE bots SET owner_user_id=? WHERE id=?',(uid,bot))
    assert client.post(f'/bots/{bot}/token/reveal').status_code==403 # admin is not the owner
    with a.db() as c:
        audit=' '.join(str(tuple(r)) for r in c.execute('SELECT * FROM credential_audit'))
    assert 'fake-test-bot-token' not in audit and a.ADMIN_PASSWORD not in audit


def test_token_reveal_csrf_and_rate_limit():
    _,bot,_=create_job();client=client_for()
    a.app.config['WTF_CSRF_ENABLED']=True
    assert client.post(f'/bots/{bot}/token/reveal',data={'password':a.ADMIN_PASSWORD}).status_code==400
    a.app.config['WTF_CSRF_ENABLED']=False
    for _ in range(5): assert client.post(f'/bots/{bot}/token/reveal',data={'password':'bad'}).status_code==403
    assert client.post(f'/bots/{bot}/token/reveal',data={'password':a.ADMIN_PASSWORD}).status_code==429


def test_late_poll_cannot_revive_deleted_chat_or_media():
    _,bot,_=create_job()
    with a.db() as c: c.execute("UPDATE bots SET status='deleted' WHERE id=?",(bot,))
    a.remember_chat(bot,{'id':-123,'type':'group','title':'late'})
    assert not a.remember_media_message(bot,{'chat':{'id':-123},'message_id':1,'photo':[{'file_id':'x','file_unique_id':'unique'}]})
    with a.db() as c: assert not c.execute('SELECT 1 FROM chats WHERE bot_id=?',(bot,)).fetchone()


def test_per_target_rotation_count_and_interval(monkeypatch):
    task,bot,job=modern(); sent=[]
    monkeypatch.setattr(a,'_api_request',lambda token,method,payload,timeout=35: sent.append(payload['text']) or {'message_id':len(sent)})
    for index in range(3):
        with a.db() as c: c.execute('UPDATE delivery_jobs SET next_attempt_at=0 WHERE id=?',(job,))
        claim=a.claim_delivery_job(); assert claim['id']==job
        a.process_delivery_job(claim)
        row=get('delivery_jobs',job)
        assert row['success_count']==index+1
        assert row['next_attempt_at']>=time.time()+8
        if index<2: assert a.claim_delivery_job() is None
    assert [s.split('\n')[0] for s in sent]==['A','B','C']
    assert get('tasks',task)['status']=='completed'


def test_delivery_error_explains_failure_and_redacts_token(monkeypatch, caplog):
    task, _, job = modern()
    fake_token = "123456789:" + "a" * 24

    def rejected(*args, **kwargs):
        raise a.TelegramAPIError(400, f"unrecognized Telegram reason {fake_token}")

    monkeypatch.setattr(a, "_api_request", rejected)
    a.process_delivery_job(a.claim_delivery_job())
    result = get("delivery_jobs", job)
    assert result["status"] == "failed"
    assert "暂时无法确定具体原因" in result["last_error"]
    assert "unrecognized Telegram reason" in caplog.text
    assert fake_token not in caplog.text
    assert "没有发送权限" in a.telegram_error_message(a.TelegramAPIError(400, "CHAT_WRITE_FORBIDDEN"))
    assert get("tasks", task)["status"] == "failed"


def test_future_schedule_and_rate_limit_survive_pause_resume():
    task,bot,job=modern()
    future=int(time.time())+3600
    with a.db() as c:
        c.execute("UPDATE tasks SET status='scheduled',scheduled_at=? WHERE id=?",(future,task))
        c.execute('UPDATE delivery_jobs SET next_attempt_at=? WHERE id=?',(future+120,job))
    assert a.pause_task(task)[0]; assert a.resume_task(task)[0]
    assert get('delivery_jobs',job)['next_attempt_at']>=future+120
    assert a.claim_delivery_job() is None


def test_unknown_resolution_is_owned_and_idempotent(monkeypatch):
    task,bot,job=modern()
    def timeout(*args,**kwargs): raise a.requests.Timeout('uncertain')
    monkeypatch.setattr(a,'_api_request',timeout)
    a.process_delivery_job(a.claim_delivery_job())
    assert get('delivery_jobs',job)['status']=='unknown'
    with pytest.raises(PermissionError): delivery_v2.resolve(a,job,'other','sent','checked')
    delivery_v2.resolve(a,job,'legacy_admin','sent','目标群已经完整收到 A')
    assert get('delivery_jobs',job)['success_count']==1
    with pytest.raises(ValueError): delivery_v2.resolve(a,job,'legacy_admin','sent','second click')


def test_receipts_skip_confirmed_parts_after_definite_failure(monkeypatch):
    task,bot,job=modern();job=get('delivery_jobs',job);calls=[]
    def send(method,payload):
        calls.append(payload['text'])
        if payload['text']=='B' and calls.count('B')==1: raise a.TelegramAPIError(400,'bad')
        return {'message_id':len(calls)}
    with delivery_v2.journal(a,job):
        delivery_v2.request_with_receipt(lambda:send('sendMessage',{'text':'A'}),'sendMessage',{'text':'A'})
        with pytest.raises(a.TelegramAPIError): delivery_v2.request_with_receipt(lambda:send('sendMessage',{'text':'B'}),'sendMessage',{'text':'B'})
    with delivery_v2.journal(a,job):
        delivery_v2.request_with_receipt(lambda:send('sendMessage',{'text':'A'}),'sendMessage',{'text':'A'})
        delivery_v2.request_with_receipt(lambda:send('sendMessage',{'text':'B'}),'sendMessage',{'text':'B'})
    assert calls==['A','B','B']


def test_material_versions_and_distinct_source_references():
    _,bot,_=create_job()
    message={'chat':{'id':-1},'message_id':1,'photo':[{'file_id':'file','file_unique_id':'same'}],'caption':'one'}
    assert material_library.collect(a,bot,message)
    assert not material_library.collect(a,bot,message)
    message['caption']='edited';assert material_library.collect(a,bot,message)
    message['message_id']=2;assert material_library.collect(a,bot,message)
    with a.db() as c:
        assert c.execute('SELECT COUNT(*) FROM materials WHERE bot_id=?',(bot,)).fetchone()[0]==2
        assert c.execute('SELECT COUNT(*) FROM material_versions').fetchone()[0]==1
        assert c.execute('SELECT COUNT(*) FROM media_assets WHERE bot_id=?',(bot,)).fetchone()[0]==2


@pytest.mark.parametrize('filename',['../escape.jpg','/tmp/escape.jpg','C:/escape.jpg'])
def test_import_rejects_path_traversal(tmp_path,filename):
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w') as z:
        z.writestr('result.json',json.dumps({'id':1,'messages':[]}));z.writestr(filename,b'image')
    with pytest.raises(ValueError): material_library.prepare_import(buf.getvalue(),tmp_path/'import')


def test_import_resumes_and_deduplicates(tmp_path):
    _,bot,_=create_job()
    doc={'id':123,'messages':[{'id':i,'type':'message','text':str(i)} for i in range(101)]}
    path,total=material_library.prepare_import(json.dumps(doc).encode(),tmp_path/'import')
    with a.db() as c: c.execute('INSERT INTO imports(id,bot_id,owner_user_id,path,total) VALUES(?,?,?,?,?)',('batch',bot,'legacy_admin',str(path),total))
    material_library.process_batch(a,'batch','legacy_admin')
    with a.db() as c: assert c.execute('SELECT cursor FROM imports').fetchone()[0]==100
    material_library.process_batch(a,'batch','legacy_admin')
    material_library.process_batch(a,'batch','legacy_admin')
    with a.db() as c:
        assert c.execute('SELECT COUNT(*) FROM materials').fetchone()[0]==101
        assert c.execute('SELECT status FROM imports').fetchone()[0]=='completed'


def test_callback_reply_dedup_and_bot_scope(monkeypatch):
    _,bot,_=create_job();calls=[]
    a.remember_chat(bot,{'id':-123,'type':'group','title':'test'})
    with a.db() as c: c.execute('INSERT INTO button_actions VALUES(?,?,?,?,?)',(bot,'act:help','reply','help text','inline'))
    monkeypatch.setattr(a,'api',lambda token,method,payload: calls.append((method,payload)) or {})
    update={'callback_query':{'id':'same','data':'act:help','message':{'chat':{'id':-123}}}}
    assert button_actions.dispatch(a,bot,'fake',update)
    assert button_actions.dispatch(a,bot,'fake',update)
    assert len(calls)==2
    assert not button_actions.dispatch(a,bot+1,'fake',update)


def test_new_pages_render_user_content_as_text():
    _,bot,_=create_job()
    material_library.collect(a,bot,{'chat':{'id':-1},'message_id':1,'text':'{{7*7}} <script>alert(1)</script>'})
    client=client_for()
    response=client.get('/library')
    assert response.status_code==200 and '{{7*7}}' in response.text and '<script>alert(1)</script>' not in response.text
    assert client.get('/buttons').status_code==200
    assert client.get('/review').status_code==200


def test_concurrent_claim_only_one_wins():
    from concurrent.futures import ThreadPoolExecutor
    task,bot,job=modern()
    with ThreadPoolExecutor(max_workers=2) as pool:
        rows=list(pool.map(lambda _:a.claim_delivery_job(),range(2)))
    assert sum(row is not None for row in rows)==1
    assert get('delivery_jobs',job)['attempts']==1


def test_unknown_target_does_not_block_other_groups(monkeypatch):
    task,bot,job=modern()
    with a.db() as c:
        second=c.execute("INSERT INTO delivery_jobs(task_id,bot_id,chat_id,chat_title,status,created_at,updated_at) VALUES(?,?,?,'second','pending',?,?)",(task,bot,-999,a.now(),a.now())).lastrowid
        c.execute("UPDATE delivery_jobs SET status='unknown' WHERE id=?",(job,))
    claim=a.claim_delivery_job()
    assert claim['id']==second


def test_duration_expiry_and_pause_clock(monkeypatch):
    task,bot,job=modern(0)
    with a.db() as c:
        c.execute('UPDATE tasks SET stop_after_seconds=60 WHERE id=?',(task,))
    monkeypatch.setattr(a,'_api_request',lambda *args,**kwargs:{'message_id':1})
    a.process_delivery_job(a.claim_delivery_job())
    old=get('tasks',task)['ends_at']
    a.pause_task(task)
    with a.db() as c: c.execute('UPDATE tasks SET paused_at=paused_at-120 WHERE id=?',(task,))
    a.resume_task(task)
    assert get('tasks',task)['ends_at']>=old+120
    with a.db() as c: c.execute('UPDATE tasks SET ends_at=? WHERE id=?',(int(time.time())-1,task))
    assert a.claim_delivery_job() is None
    assert get('tasks',task)['status']=='completed'


def test_edit_version_race_and_callback_bytes_preserved():
    a.set_setting("default_send_gap_seconds", "10")
    task,bot,job=modern()
    client=client_for()
    with a.db() as c:
        c.execute('UPDATE tasks SET bot_ids=?,chat_targets=? WHERE id=?',(json.dumps([str(bot)]),json.dumps([f'{bot}:-100123']),task))
    form={'content_modes':'text','body':'changed','buttons':json.dumps({'rows':[[{'text':'help','kind':'CALLBACK','target':'act:help'}]]}), 'send_gap_seconds':'10','config_version':'1'}
    assert client.post(f'/tasks/{task}/edit',data=form).status_code==302
    assert get('tasks',task)['config_version']==2
    assert json.loads(get('tasks',task)['buttons'])[0][0]['callback_data']=='act:help'
    form['body']='stale overwrite'
    client.post(f'/tasks/{task}/edit',data=form)
    assert get('tasks',task)['body']=='changed'


def test_upgrade_backup_preserves_old_token_and_history(tmp_path,monkeypatch):
    import sqlite3
    path=tmp_path/'legacy.sqlite3'
    connection=sqlite3.connect(path)
    try:
        connection.execute("CREATE TABLE bots(id INTEGER PRIMARY KEY AUTOINCREMENT,token TEXT NOT NULL UNIQUE,telegram_id INTEGER NOT NULL,username TEXT,first_name TEXT,status TEXT NOT NULL DEFAULT 'active',offset INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL)")
        connection.execute("INSERT INTO bots(token,telegram_id,status,created_at) VALUES('',1,'deleted','old')")
        connection.execute("INSERT INTO bots(token,telegram_id,status,created_at) VALUES('legacy-fake-token',2,'active','old')")
        connection.commit()
    finally: connection.close()
    monkeypatch.setattr(a,'DB_PATH',str(path))
    a.init_db();a.init_db()
    with a.db() as c:
        assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert c.execute('SELECT token FROM bots WHERE id=1').fetchone()[0]=='deleted:1'
        assert a.decrypt_token(c.execute('SELECT token FROM bots WHERE id=2').fetchone()[0])=='legacy-fake-token'
    backup=sqlite3.connect(str(path)+'.before-2.0.1.bak')
    try: assert backup.execute('SELECT token FROM bots WHERE id=2').fetchone()[0]=='legacy-fake-token'
    finally: backup.close()


def test_migration_checksum_drift_stops_startup():
    from migrations import migrate
    with a.db() as c:
        original=c.execute('SELECT checksum FROM schema_migrations').fetchone()[0]
        c.execute("UPDATE schema_migrations SET checksum='tampered'")
    try:
        with a.db() as c:
            with pytest.raises(RuntimeError,match='checksum'): migrate(c)
    finally:
        with a.db() as c: c.execute('UPDATE schema_migrations SET checksum=?',(original,))


def test_local_media_upload_has_receipt_and_no_double_send(monkeypatch,tmp_path):
    task,bot,job=modern();job=get('delivery_jobs',job);calls=[]
    media=tmp_path/'test.jpg';media.write_bytes(b'fake-media-test')
    class Response:
        def json(self): return {'ok':True,'result':{'message_id':4}}
    monkeypatch.setattr(a.requests,'post',lambda *args,**kwargs:calls.append(1) or Response())
    for _ in range(2):
        with delivery_v2.journal(a,job): a.send_one('fake',-123,'caption',[],'OFF',media_path=str(media),media_type='photo')
    assert len(calls)==1

def test_collection_switch_preserves_material_and_owner_isolation():
    _, first, _ = create_job()
    _, second, _ = create_job()
    message = {"chat": {"id": -111}, "message_id": 5, "photo": [{"file_id": "photo"}]}
    material_library.collect(a, first, message)
    assert not material_library.collect(a, second, message)
    with a.db() as c:
        rows = c.execute("SELECT * FROM materials WHERE source_chat_id=-111").fetchall()
    assert len(rows) == 1 and rows[0]["bot_id"] == second
    assert client_for().post(f'/library/materials/{rows[0]["id"]}/use').status_code == 302
    material_library.collect(a, second, dict(message, chat={"id": -112}))
    owner = a.create_local_user("isolated@example.com", "strong-password")
    with a.db() as c:
        c.execute("UPDATE bots SET owner_user_id=? WHERE id=?", (owner, first))
    material_library.collect(a, first, message)
    with a.db() as c:
        assert c.execute("SELECT COUNT(*) FROM materials").fetchone()[0] == 3
    assert client_for(owner).post(f'/library/materials/{rows[0]["id"]}/use').status_code == 404


def test_group_error_and_remove_preserve_other_bot_and_history():
    _, first, job = create_job()
    _, second, _ = create_job()
    for bot in (first, second):
        a.remember_chat(bot, {"id": -100123, "type": "supergroup", "title": "异常群验收"})
    a.record_delivery_api_error(job, a.TelegramAPIError(429, "Too Many Requests", 30))
    with a.db() as c:
        assert c.execute("SELECT status FROM chats WHERE bot_id=?", (first,)).fetchone()[0] == "active"
    a.record_delivery_api_error(job, a.TelegramAPIError(400, "not enough rights to send"))
    page = client_for().get("/").get_data(as_text=True)
    assert "异常：没有发送权限" in page and "删除异常群" in page
    with a.db() as c:
        chat = c.execute("SELECT id FROM chats WHERE bot_id=?", (first,)).fetchone()[0]
    assert client_for().post(f"/bots/{first}/chats/{chat}/remove").status_code == 302
    a.remember_chat(first, {"id": -100123, "type": "supergroup", "title": "迟到消息"})
    with a.db() as c:
        assert c.execute("SELECT status FROM chats WHERE bot_id=?", (first,)).fetchone()[0] == "deleted"
        assert c.execute("SELECT status FROM chats WHERE bot_id=?", (second,)).fetchone()[0] == "active"
        assert c.execute("SELECT id FROM delivery_jobs WHERE id=?", (job,)).fetchone()


@pytest.mark.parametrize("member,expected", [({"status":"left"},"removed"), ({"status":"kicked"},"removed"), ({"status":"restricted","can_send_messages":False},"no_permission")])
def test_membership_event_marks_only_its_bot_and_preserves_deleted(member, expected):
    _, first, _ = create_job()
    _, second, _ = create_job()
    chat={"id":-100123,"type":"supergroup","title":"事件测试群"}
    for bot in (first,second): a.remember_chat(bot,chat)
    a.update_chat_membership(first,chat,member)
    with a.db() as c:
        assert c.execute("SELECT status FROM chats WHERE bot_id=?",(first,)).fetchone()[0]==expected
        assert c.execute("SELECT status FROM chats WHERE bot_id=?",(second,)).fetchone()[0]=='active'
        ident=c.execute("SELECT id FROM chats WHERE bot_id=?",(first,)).fetchone()[0]
    assert a.status_zh(expected) in client_for().get('/').get_data(as_text=True)
    a.update_chat_membership(first,chat,{"status":"member"})
    with a.db() as c: assert c.execute("SELECT status FROM chats WHERE id=?",(ident,)).fetchone()[0]=='active'
    a.update_chat_membership(first,chat,member)
    client_for().post(f'/bots/{first}/chats/{ident}/remove')
    a.update_chat_membership(first,chat,member)
    with a.db() as c: assert c.execute("SELECT status FROM chats WHERE id=?",(ident,)).fetchone()[0]=='deleted'


def test_prompt_binding_roundtrip_isolated_and_transactional(monkeypatch):
    _, first, _ = create_job()
    _, second, _ = create_job()
    raw=json.dumps({"mode":"inline","rows":[[{"text":"帮助","kind":"PROMPT","target":"提示一"}]]})
    raw2=raw.replace("提示一","提示二") if "提示一" in raw else json.dumps({"mode":"inline","rows":[[{"text":"帮助","kind":"PROMPT","target":"提示二"}]]})
    parsed=a.parse_buttons(raw)
    assert parsed[0][0]['callback_data'] != a.parse_buttons(raw2)[0][0]['callback_data']
    with a.db() as c: a.bind_prompt_actions(c,raw,[first,second])
    with pytest.raises(RuntimeError):
        with a.db() as c:
            a.bind_prompt_actions(c,raw2,[first])
            raise RuntimeError('save failed')
    with a.db() as c:
        assert c.execute('SELECT COUNT(*) FROM button_actions').fetchone()[0]==2
    calls=[]
    monkeypatch.setattr(a,'api',lambda *args,**kw:calls.append(args))
    a.remember_chat(first,{"id":-100123,"type":"supergroup","title":"提示"})
    update={"callback_query":{"id":"prompt-test","data":parsed[0][0]['callback_data'],"message":{"chat":{"id":-100123}}}}
    assert button_actions.dispatch(a,first,'fake',update)
    assert button_actions.dispatch(a,first,'fake',update)
    assert len(calls)==1 and calls[0][2]['text']=='提示一'
    with a.app.test_request_context('/'):
        from flask import session
        session.update(authenticated=True,auth_method='admin_password',is_admin=True)
        editor=json.dumps({"rows":[[{"text":"帮助","kind":"CALLBACK","target":parsed[0][0]['callback_data']}]]})
        assert json.loads(a.restore_prompt_editor(editor))['rows'][0][0]['target']=='提示一'


def test_source_switch_api_disables_previous_and_rejects_unknown():
    _, first, _ = create_job()
    _, second, _ = create_job()
    for bot in (first,second):
        a.remember_chat(bot,{"id":-100123,"type":"supergroup","title":"共享来源"})
    client=client_for()
    for bot in (first,second):
        assert client.post('/library',data={"action":"source","bot_id":bot,"chat_id":-100123,"enabled":"on"}).status_code==302
    with a.db() as c:
        rows=c.execute('SELECT bot_id,enabled FROM collection_sources ORDER BY bot_id').fetchall()
        assert [(r['bot_id'],r['enabled']) for r in rows]==[(first,0),(second,1)]
    client.post('/library',data={"action":"source","bot_id":second,"chat_id":-999,"enabled":"on"})
    with a.db() as c: assert not c.execute('SELECT 1 FROM collection_sources WHERE chat_id=-999').fetchone()
    assert client.post('/library',data={"action":"import"}).status_code==410
    assert client.post('/library/imports/1/resume').status_code==410


def test_task_prompt_save_and_failed_edit_keep_action_transaction():
    task,bot,_=modern()
    with a.db() as c:
        c.execute('UPDATE tasks SET bot_ids=?,chat_targets=? WHERE id=?',(json.dumps([str(bot)]),json.dumps([f'{bot}:-100123']),task))
    raw=json.dumps({'rows':[[{'text':'帮助','kind':'PROMPT','target':'任务提示'}]]})
    form={'content_modes':'text','body':'正文','buttons':raw,'config_version':'1'}
    client=client_for()
    assert client.post(f'/tasks/{task}/edit',data=form).status_code==302
    with a.db() as c:
        assert c.execute('SELECT body FROM button_actions WHERE bot_id=?',(bot,)).fetchone()[0]=='任务提示'
    assert 'PROMPT' in client.get(f'/tasks/{task}/edit').get_data(as_text=True)
    form['buttons']=json.dumps({'rows':[[{'text':'帮助','kind':'PROMPT','target':'不可保存'}]]})
    client.post(f'/tasks/{task}/edit',data=form)
    with a.db() as c: assert not c.execute("SELECT 1 FROM button_actions WHERE body='不可保存'").fetchone()


def test_batch_abnormal_group_cleanup_and_source_diagnostics():
    _, bot1, _ = create_job()
    _, bot2, _ = create_job()
    a.remember_chat(bot1, {"id": -5001, "type": "supergroup", "title": "异常群A"})
    a.remember_chat(bot1, {"id": -5002, "type": "supergroup", "title": "正常群B"})
    a.remember_chat(bot2, {"id": -5001, "type": "supergroup", "title": "同群其他Bot正常"})
    a.update_chat_membership(bot1, {"id": -5001, "type": "supergroup"}, {"status": "kicked"})
    client = client_for()
    assert "一键清除全部异常群（1）" in client.get("/").get_data(as_text=True)
    assert client.post("/chats/remove-abnormal").status_code == 302
    with a.db() as c:
        assert c.execute("SELECT status FROM chats WHERE bot_id=? AND chat_id=-5001", (bot1,)).fetchone()[0] == "deleted"
        assert c.execute("SELECT status FROM chats WHERE bot_id=? AND chat_id=-5002", (bot1,)).fetchone()[0] == "active"
        assert c.execute("SELECT status FROM chats WHERE bot_id=? AND chat_id=-5001", (bot2,)).fetchone()[0] == "active"
    # Verify 005 diagnostic statuses on disabled / unsupported messages
    client.post("/library", data={"action": "source", "bot_id": bot2, "chat_id": -5001, "title": "诊断源"})
    material_library.collect(a, bot2, {"chat": {"id": -5001}, "message_id": 88, "text": "未启用消息"}, require_source=True)
    with a.db() as c:
        src = c.execute("SELECT status_text, last_error FROM collection_sources WHERE bot_id=? AND chat_id=-5001", (bot2,)).fetchone()
        assert src["status_text"] == "来源未启用"
    client.post("/library", data={"action": "source", "bot_id": bot2, "chat_id": -5001, "title": "诊断源", "enabled": "on"})
    material_library.collect(a, bot2, {"chat": {"id": -5001}, "message_id": 89, "sticker": {"file_id": "stk"}}, require_source=True)
    with a.db() as c:
        src = c.execute("SELECT status_text FROM collection_sources WHERE bot_id=? AND chat_id=-5001", (bot2,)).fetchone()
        assert src["status_text"] == "消息类型不支持"
