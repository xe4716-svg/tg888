#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="${TGADBOT_ROOT_DIR:-$APP_DIR}"
if [[ ! -d "$ROOT_DIR" ]]; then
  echo "ERROR: TGADBOT_ROOT_DIR must name an existing installation directory." >&2
  exit 1
fi
ROOT_DIR="$(cd "$ROOT_DIR" && pwd)"
if ! command -v sha256sum >/dev/null 2>&1; then
  echo "ERROR: 未找到 sha256sum，无法验证部署包完整性。" >&2
  exit 1
fi

# Verify every packaged source file before reading production config or touching Docker.
if [[ ! -s "$APP_DIR/SHA256SUMS" ]]; then
  echo "ERROR: 部署包缺少 SHA256SUMS，拒绝继续。请重新获取完整 v2.0.1-rc.2 ZIP。" >&2
  exit 1
fi
if ! (cd "$APP_DIR" && sha256sum -c SHA256SUMS); then
  echo "ERROR: 部署包文件校验失败，拒绝执行升级。" >&2
  exit 1
fi
PROJECT_NAME="${COMPOSE_PROJECT_NAME:-tgadbot}"
CONTAINER_NAME="${TGADBOT_CONTAINER:-}"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="$ROOT_DIR/backups/upgrade-v2.0.1-rc.2-$TIMESTAMP"

if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: 未找到 Docker。"
  exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "ERROR: Docker Compose v2 不可用。"
  exit 1
fi
if ! command -v curl >/dev/null 2>&1; then
  echo "ERROR: 未找到 curl，无法执行升级后的 HTTP 健康检查。"
  exit 1
fi
if ! command -v sha256sum >/dev/null 2>&1 || ! command -v tar >/dev/null 2>&1; then
  echo "ERROR: 缺少 sha256sum 或 tar，无法验证数据库/媒体备份。"
  exit 1
fi

COMPOSE_FILE=""
for candidate in \
  "$ROOT_DIR/compose.tgadbot.production.yaml" \
  "$ROOT_DIR/compose.tgadbot.yaml" \
  "$ROOT_DIR/compose.yaml"; do
  if [[ -f "$candidate" ]]; then COMPOSE_FILE="$candidate"; break; fi
done
if [[ -z "$COMPOSE_FILE" ]]; then
  echo "ERROR: 在 $ROOT_DIR 未找到生产 Compose 文件。"
  exit 1
fi
if [[ ! -f "$APP_DIR/app.py" || ! -f "$APP_DIR/Dockerfile" ]]; then
  echo "ERROR: 更新包不完整，缺少 app.py 或 Dockerfile。"
  exit 1
fi
# Resolve the actual container from the selected Compose project first. The
# package compose file uses container_name=tgadbot, while older deployments may
# have Compose-generated names such as tgadbot-tgadbot-1.
if [[ -z "$CONTAINER_NAME" ]]; then
  COMPOSE_CONTAINER_ID="$(docker compose -p "$PROJECT_NAME" -f "$COMPOSE_FILE" ps -q tgadbot 2>/dev/null || true)"
  if [[ -n "$COMPOSE_CONTAINER_ID" ]]; then
    CONTAINER_NAME="$(docker inspect -f '{{.Name}}' "$COMPOSE_CONTAINER_ID" 2>/dev/null | sed 's#^/##' || true)"
  fi
fi
if [[ -z "$CONTAINER_NAME" ]]; then
  for candidate in tgadbot "${PROJECT_NAME}-tgadbot-1" tgadbot-tgadbot-1; do
    if docker inspect "$candidate" >/dev/null 2>&1; then
      CONTAINER_NAME="$candidate"
      break
    fi
  done
fi
if [[ -z "$CONTAINER_NAME" ]] || ! docker inspect "$CONTAINER_NAME" >/dev/null 2>&1; then
  echo "ERROR: 找不到生产容器。当前 Compose 项目：$PROJECT_NAME；服务：tgadbot。"
  echo "请先确认 compose 文件和项目名，或执行：TGADBOT_CONTAINER=实际容器名 bash upgrade.sh"
  exit 1
fi

IMAGE_TAG="$(docker inspect -f '{{.Config.Image}}' "$CONTAINER_NAME")"
OLD_IMAGE_ID="$(docker inspect -f '{{.Image}}' "$CONTAINER_NAME")"
if [[ -z "$IMAGE_TAG" || -z "$OLD_IMAGE_ID" ]]; then
  echo "ERROR: 无法识别当前生产镜像，停止升级。"
  exit 1
fi
ROLLBACK_TAG="tgadbot-rollback:v2.0.1-rc.2-$TIMESTAMP"
mkdir -p "$BACKUP_DIR"
chmod 0700 "$BACKUP_DIR"

# Docker bridge containers may not inherit a usable upstream resolver on some CentOS 9 hosts.
# Reuse the host's real nameservers in a Compose override without changing port bindings or app networking.
DNS_OVERRIDE_FILE="$BACKUP_DIR/compose.dns-override.yaml"
DNS_SERVERS=()
for resolver_file in /etc/resolv.conf /run/systemd/resolve/resolv.conf /run/NetworkManager/no-stub-resolv.conf; do
  [[ -r "$resolver_file" ]] || continue
  while read -r directive address _; do
    [[ "$directive" == "nameserver" ]] || continue
    if [[ ! "$address" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ && ! "$address" =~ ^[0-9A-Fa-f:]+$ ]]; then
      continue
    fi
    [[ "$address" == 127.* || "$address" == "::1" ]] && continue
    if [[ ! " ${DNS_SERVERS[*]} " == *" $address "* ]]; then
      DNS_SERVERS+=("$address")
    fi
    [[ ${#DNS_SERVERS[@]} -ge 3 ]] && break
  done < "$resolver_file"
  [[ ${#DNS_SERVERS[@]} -ge 3 ]] && break
done
if [[ ${#DNS_SERVERS[@]} -eq 0 ]]; then
  # Fallback only when the host exposes a loopback-only resolver configuration.
  DNS_SERVERS=("1.1.1.1" "8.8.8.8")
fi
{
  printf 'services:\n  tgadbot:\n    dns:\n'
  for dns_server in "${DNS_SERVERS[@]}"; do
    printf '      - "%s"\n' "$dns_server"
  done
} > "$DNS_OVERRIDE_FILE"
COMPOSE_ARGS=(-p "$PROJECT_NAME" -f "$COMPOSE_FILE" -f "$DNS_OVERRIDE_FILE")
echo "Docker bridge DNS：${DNS_SERVERS[*]}"
if ! docker compose "${COMPOSE_ARGS[@]}" config --quiet; then
  echo "ERROR: DNS 覆盖配置未通过 Compose 校验，生产容器未修改。"
  exit 1
fi

# Preserve the current production configuration and an online-consistent SQLite copy.
if [[ -f "$ROOT_DIR/.env" ]]; then
  cp -a "$ROOT_DIR/.env" "$BACKUP_DIR/.env"
  chmod 0600 "$BACKUP_DIR/.env"
fi
cp -a "$COMPOSE_FILE" "$BACKUP_DIR/$(basename "$COMPOSE_FILE")"
chmod 0600 "$BACKUP_DIR/$(basename "$COMPOSE_FILE")"

echo "[1/5] 备份生产数据库、媒体和旧镜像……"
DB_PATH_IN_CONTAINER="$(docker exec "$CONTAINER_NAME" python -c 'import os; print(os.getenv("DB_PATH", "/data/tgadbot.sqlite3"))')"
MEDIA_DIR_IN_CONTAINER="$(docker exec "$CONTAINER_NAME" python -c 'import os; print(os.getenv("MEDIA_DIR", "/data/media"))')"
DATA_MOUNT_TYPE="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/data"}}{{.Type}}{{end}}{{end}}' "$CONTAINER_NAME")"
DATA_MOUNT_NAME="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/data"}}{{.Name}}{{end}}{{end}}' "$CONTAINER_NAME")"
DATA_MOUNT_SOURCE="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/data"}}{{.Source}}{{end}}{{end}}' "$CONTAINER_NAME")"
DATA_MOUNT_RW="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/data"}}{{.RW}}{{end}}{{end}}' "$CONTAINER_NAME")"
RESTORE_VOLUME_ARGS=()
case "$DATA_MOUNT_TYPE" in
  volume)
    if [[ -z "$DATA_MOUNT_NAME" ]]; then
      echo "ERROR: 无法识别 /data 命名卷，停止升级。"
      exit 1
    fi
    RESTORE_VOLUME_ARGS=(-v "$DATA_MOUNT_NAME:/data")
    ;;
  bind)
    if [[ -z "$DATA_MOUNT_SOURCE" ]]; then
      echo "ERROR: 无法识别 /data 绑定目录，停止升级。"
      exit 1
    fi
    RESTORE_VOLUME_ARGS=(-v "$DATA_MOUNT_SOURCE:/data")
    ;;
  *)
    echo "ERROR: /data 必须是可识别的 Docker volume 或 bind mount，停止升级。"
    exit 1
    ;;
esac
if [[ "$DATA_MOUNT_RW" != "true" ]]; then
  echo "ERROR: /data 挂载不是可写状态，停止升级。"
  exit 1
fi
if [[ "$DB_PATH_IN_CONTAINER" != /data/* || "$MEDIA_DIR_IN_CONTAINER" != /data/* ]]; then
  echo "ERROR: 当前 DB_PATH/MEDIA_DIR 不在 /data 持久化挂载内，无法保证自动数据回滚。"
  exit 1
fi
# Create the SQLite snapshot on the persistent /data mount, then stream it to
# the host. This avoids docker cp's archive path handling for tmpfs files and
# avoids consuming the container's 64 MiB /tmp tmpfs.
DB_BACKUP_PATH_IN_CONTAINER="/data/.tgadbot-preupgrade-${TIMESTAMP}.sqlite3"
if ! docker exec \
  -e DB_PATH="$DB_PATH_IN_CONTAINER" \
  -e BACKUP_PATH="$DB_BACKUP_PATH_IN_CONTAINER" \
  "$CONTAINER_NAME" python -c '
import os
import sqlite3

src_path = os.environ["DB_PATH"]
dst_path = os.environ["BACKUP_PATH"]
if os.path.abspath(src_path) == os.path.abspath(dst_path):
    raise RuntimeError("backup path must differ from the production database path")
if os.path.exists(dst_path):
    raise RuntimeError("refusing to overwrite an existing backup file: " + dst_path)

src = sqlite3.connect(src_path, timeout=30)
dst = sqlite3.connect(dst_path, timeout=30)
try:
    src.backup(dst, pages=256, sleep=0.05)
    dst.commit()
    result = dst.execute("PRAGMA quick_check").fetchone()
    if not result or result[0] != "ok":
        raise RuntimeError("SQLite backup integrity check failed: " + repr(result))
finally:
    dst.close()
    src.close()

if not os.path.isfile(dst_path) or os.path.getsize(dst_path) == 0:
    raise RuntimeError("SQLite backup file was not created or is empty")
os.chmod(dst_path, 0o600)
print("SQLite online backup created and quick_check passed")
'; then
  echo "ERROR: SQLite 在线备份创建失败；生产容器未修改。"
  exit 1
fi

if ! docker exec "$CONTAINER_NAME" test -s "$DB_BACKUP_PATH_IN_CONTAINER"; then
  echo "ERROR: 容器内 SQLite 备份文件不存在或为空；生产容器未修改。"
  exit 1
fi
if ! docker exec "$CONTAINER_NAME" cat "$DB_BACKUP_PATH_IN_CONTAINER" > "$BACKUP_DIR/tgadbot.sqlite3"; then
  echo "ERROR: 无法将 SQLite 备份流式复制到宿主机；生产容器未修改。"
  exit 1
fi
chmod 0600 "$BACKUP_DIR/tgadbot.sqlite3"
if [[ ! -s "$BACKUP_DIR/tgadbot.sqlite3" ]]; then
  echo "ERROR: 宿主机 SQLite 备份文件不存在或为空；生产容器未修改。"
  exit 1
fi

CONTAINER_DB_SHA="$(docker exec -e BACKUP_PATH="$DB_BACKUP_PATH_IN_CONTAINER" "$CONTAINER_NAME" python -c '
import hashlib
import os

p = os.environ["BACKUP_PATH"]
h = hashlib.sha256()
with open(p, "rb") as f:
    while True:
        chunk = f.read(1024 * 1024)
        if not chunk:
            break
        h.update(chunk)
print(h.hexdigest())
')"
HOST_DB_SHA="$(sha256sum "$BACKUP_DIR/tgadbot.sqlite3" | awk '{print $1}')"
if [[ "$CONTAINER_DB_SHA" != "$HOST_DB_SHA" ]]; then
  echo "ERROR: SQLite 备份传输前后 SHA-256 不一致；保留容器内临时备份：$DB_BACKUP_PATH_IN_CONTAINER"
  exit 1
fi

# Validate the host-side copy with the already-present production image.
# BACKUP_DIR is intentionally 0700 and the SQLite file 0600. The image defaults
# to UID 10001 (appuser), so it cannot traverse/read this private backup. Run
# only this isolated validator as container root; keep every other boundary:
# no network, read-only rootfs and bind mount, all capabilities dropped, and
# no-new-privileges. The private :Z label permits access on SELinux-enforcing
# CentOS/RHEL hosts without making the backup directory shared with other
# containers.
if ! docker run --rm --network none --read-only \
  --user 0:0 \
  --cap-drop ALL \
  --security-opt no-new-privileges \
  --tmpfs /tmp:rw,noexec,nosuid,size=16m \
  -v "$BACKUP_DIR:/backup:ro,Z" \
  --entrypoint python "$IMAGE_TAG" -c '
import sqlite3
p = "/backup/tgadbot.sqlite3"
db = sqlite3.connect("file:" + p + "?mode=ro", uri=True)
try:
    result = db.execute("PRAGMA quick_check").fetchone()
    if not result or result[0] != "ok":
        raise SystemExit("host-side SQLite backup integrity check failed: " + repr(result))
    print("Host-side SQLite backup verified: quick_check=ok")
finally:
    db.close()
'; then
  echo "ERROR: 宿主机 SQLite 备份完整性验证失败；生产容器未修改。"
  exit 1
fi
docker exec "$CONTAINER_NAME" rm -f "$DB_BACKUP_PATH_IN_CONTAINER"

# Stream media tar output directly to the host; do not stage a potentially
# large archive in the container's size-limited /tmp tmpfs.
if docker exec "$CONTAINER_NAME" sh -c "test -d '$MEDIA_DIR_IN_CONTAINER'"; then
  if ! docker exec "$CONTAINER_NAME" tar -czf - -C "$MEDIA_DIR_IN_CONTAINER" . > "$BACKUP_DIR/media.tar.gz"; then
    echo "ERROR: 媒体文件备份失败；生产容器未修改。"
    exit 1
  fi
  chmod 0600 "$BACKUP_DIR/media.tar.gz"
  if [[ ! -s "$BACKUP_DIR/media.tar.gz" ]] || ! tar -tzf "$BACKUP_DIR/media.tar.gz" >/dev/null; then
    echo "ERROR: 宿主机媒体备份归档验证失败；生产容器未修改。"
    exit 1
  fi
fi

(
  cd "$BACKUP_DIR"
  sha256sum tgadbot.sqlite3 > SHA256SUMS
  chmod 0600 SHA256SUMS
  if [[ -f media.tar.gz ]]; then sha256sum media.tar.gz >> SHA256SUMS; fi
)
if ! (cd "$BACKUP_DIR" && sha256sum -c SHA256SUMS); then
  echo "ERROR: 数据库/媒体备份 SHA-256 复核失败；生产容器未修改。"
  exit 1
fi
docker tag "$OLD_IMAGE_ID" "$ROLLBACK_TAG"
if ! docker image inspect "$ROLLBACK_TAG" >/dev/null 2>&1; then
  echo "ERROR: 旧镜像回滚标签验证失败；生产容器未修改。"
  exit 1
fi
printf '%s\n' "$IMAGE_TAG" > "$BACKUP_DIR/production-image-tag.txt"
printf '%s\n' "$OLD_IMAGE_ID" > "$BACKUP_DIR/production-image-id.txt"
printf '%s\n' "$ROLLBACK_TAG" > "$BACKUP_DIR/rollback-image-tag.txt"
chmod 0600 "$BACKUP_DIR"/production-image-tag.txt "$BACKUP_DIR"/production-image-id.txt "$BACKUP_DIR"/rollback-image-tag.txt "$BACKUP_DIR"/SHA256SUMS

# Allow a backup-only rehearsal. It validates all backup artifacts and the
# rollback image tag, then exits before image build or production recreation.
if [[ "${TGADBOT_BACKUP_ONLY:-0}" == "1" ]]; then
  echo "备份演练完成：数据库、媒体（如存在）和旧镜像均已验证。"
  echo "生产容器未重建，未构建新镜像，未执行数据库迁移。"
  echo "备份目录：$BACKUP_DIR"
  echo "旧镜像回滚标签：$ROLLBACK_TAG"
  exit 0
fi

restore_previous_release() {
  local reason="$1"
  echo "ERROR: $reason；正在恢复升级前数据库、媒体和旧镜像……"

  docker compose "${COMPOSE_ARGS[@]}" stop tgadbot >/dev/null 2>&1 || true
  if docker inspect "$CONTAINER_NAME" >/dev/null 2>&1; then
    local running
    running="$(docker inspect -f '{{.State.Running}}' "$CONTAINER_NAME" 2>/dev/null || echo false)"
    if [[ "$running" == "true" ]]; then
      if ! docker stop "$CONTAINER_NAME" >/dev/null; then
        echo "ERROR: 无法停止当前容器，拒绝在服务运行时覆盖数据库。"
        return 1
      fi
    fi
  fi

  if ! docker run --rm --network none --read-only --tmpfs /tmp \
    --user 0:0 --cap-drop ALL --cap-add CHOWN --cap-add DAC_OVERRIDE --cap-add FOWNER \
    --security-opt no-new-privileges \
    "${RESTORE_VOLUME_ARGS[@]}" \
    -v "$BACKUP_DIR:/backup:ro,Z" \
    --entrypoint python "$IMAGE_TAG" \
    /app/restore_backup.py --backup-dir /backup \
    --db-path "$DB_PATH_IN_CONTAINER" --media-dir "$MEDIA_DIR_IN_CONTAINER"; then
    echo "ERROR: 数据库/媒体恢复失败。应用保持停止，请保留备份目录：$BACKUP_DIR"
    return 1
  fi

  if ! docker tag "$ROLLBACK_TAG" "$IMAGE_TAG"; then
    echo "ERROR: 旧镜像标签恢复失败。备份目录：$BACKUP_DIR"
    return 1
  fi
  if ! docker compose "${COMPOSE_ARGS[@]}" up -d --force-recreate --no-build; then
    echo "ERROR: 旧镜像已恢复，但旧容器启动失败。备份目录：$BACKUP_DIR"
    return 1
  fi
  echo "回滚完成：旧镜像、SQLite 数据库和媒体文件均已恢复。"
  echo "回滚镜像标签：$ROLLBACK_TAG"
  echo "备份目录：$BACKUP_DIR"
}

echo "[2/5] 构建 TG管家免费版 v2.0.1-rc.2……"
# Use the host network for dependency downloads; some CentOS Docker bridge DNS setups fail to resolve PyPI.
if ! docker build --network=host -t "$IMAGE_TAG" "$APP_DIR"; then
  echo "ERROR: 新镜像构建失败；生产容器未切换。旧镜像保留为 $ROLLBACK_TAG"
  exit 1
fi

echo "[3/5] 重建生产容器……"
if ! docker compose "${COMPOSE_ARGS[@]}" up -d --force-recreate --no-build; then
  if ! restore_previous_release "Compose 重建失败"; then
    echo "自动回滚未完成，请勿继续开放服务。"
  fi
  exit 1
fi

echo "[4/5] 等待健康检查……"
HEALTH_OK=0
for _ in $(seq 1 30); do
  if curl -fsS "${TGADBOT_HEALTH_URL:-http://127.0.0.1:8096/health}" > "$BACKUP_DIR/health-response.json" 2>/dev/null; then
    chmod 0600 "$BACKUP_DIR/health-response.json"
    if grep -Fq '2.0.1-rc.2' "$BACKUP_DIR/health-response.json"; then HEALTH_OK=1; break; fi
  fi
  sleep 2
done

if [[ "$HEALTH_OK" -ne 1 ]]; then
  if ! restore_previous_release "v2.0.1-rc.2 健康检查未通过"; then
    echo "自动回滚未完成，请勿继续开放服务。"
  fi
  exit 1
fi

echo "[5/5] 检查容器状态……"
HEALTH_STATUS="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$CONTAINER_NAME" 2>/dev/null || true)"
if [[ "$HEALTH_STATUS" == "unhealthy" || "$HEALTH_STATUS" == "exited" ]]; then
  if ! restore_previous_release "容器状态异常：$HEALTH_STATUS"; then
    echo "自动回滚未完成，请勿继续开放服务。"
  fi
  exit 1
fi

cat "$BACKUP_DIR/health-response.json"
echo
echo "升级完成：TG管家免费版 v2.0.1-rc.2"
echo "旧镜像回滚标签：$ROLLBACK_TAG"
echo "配置/数据库/媒体备份目录：$BACKUP_DIR"
