"use strict";
if(document.querySelector('[data-countdown][data-state="active"]'))setTimeout(()=>window.location.reload(),30000);
document.querySelectorAll('[data-countdown]').forEach(node=>{const tick=()=>{const state=node.dataset.state;const seconds=Math.max(0,Number(node.dataset.countdown)-Math.floor(Date.now()/1000));node.textContent=state==='active'?(seconds?`${new Date(Number(node.dataset.countdown)*1000).toLocaleString()} · 剩余 ${seconds} 秒`:'等待上一轮结束或调度执行'):({paused:'已暂停',completed:'已完成',cancelled:'已取消',paused_unknown:'结果未知，已暂停'}[state]||state);};tick();setInterval(tick,1000);});
const buttonRaw=document.querySelector('textarea[name="buttons"]');
if(buttonRaw){
 const host=document.createElement('section');host.className='card button-editor';buttonRaw.after(host);
 const fieldLabel=buttonRaw.previousElementSibling;
 if(fieldLabel&&fieldLabel.tagName==='LABEL')fieldLabel.textContent='自定义按钮（可视化编辑）';
 let mode='inline',width=1,items=[],rowSizes=[];
 try{const data=JSON.parse(buttonRaw.value);mode=data.mode||'inline';items=(data.rows||[]).flat();rowSizes=(data.rows||[]).map(r=>r.length);width=Math.max(1,...(data.rows||[]).map(r=>r.length));}
 catch{items=buttonRaw.value.split('\n').filter(x=>x.trim()).map(line=>{const [text,kind,...target]=line.split('|').map(x=>x.trim());return {text,kind:kind||'URL',target:target.join('|')};});}
 if(!rowSizes.length)rowSizes=items.map(()=>1);
 const feedback=document.createElement('p');feedback.className='muted';feedback.setAttribute('role','alert');feedback.setAttribute('aria-live','polite');
 const rowsNow=()=>{let offset=0;return rowSizes.filter(n=>n>0).map(n=>{const row=items.slice(offset,offset+n);offset+=n;return row;});};
 const sync=()=>{buttonRaw.value=JSON.stringify({version:2,mode,rows:rowsNow()});buttonRaw.dispatchEvent(new Event('button-config-changed'));};
 const previewText=()=>rowsNow().map(row=>row.map(x=>x.text).join(' | ')).join('\n');
 const validate=()=>{
  if(rowSizes.length>20)return '按钮最多 20 行，请删除部分按钮或改为每排两个。';
  for(let i=0;i<items.length;i++){
   const item=items[i],label='第 '+(i+1)+' 个按钮';
   const text=String(item.text||'').trim();
   if(!text)return label+'请填写按钮文字。';
   if(Array.from(text).length>64)return label+'文字不能超过 64 个字符。';
   if(mode!=='inline')continue;
   const target=String(item.target||'').trim();
   if(item.kind==='URL'){
    try{const url=new URL(target);if(!['http:','https:'].includes(url.protocol)||!url.hostname)return label+'链接必须是有效的 HTTP/HTTPS 地址。';}
    catch{return label+'链接必须是有效的 HTTP/HTTPS 地址。';}
   }else if(item.kind==='PROMPT'){
    if(!target || Array.from(target).length>200)return label+'提示内容须为 1 至 200 字符。';
   }else if(item.kind==='CALLBACK'){
    const bytes=new TextEncoder().encode(target).length;
    if(bytes<1||bytes>64)return label+'回调数据必须为 1 至 64 字节。';
   }else return label+'按钮类型无效。';
  }
  return '';
 };
 const render=()=>{host.replaceChildren();const title=document.createElement('h3');title.textContent='可视化按钮编辑';host.append(title);
 const select=(values,current,change,label)=>{const el=document.createElement('select');el.setAttribute('aria-label',label);values.forEach(([value,text])=>{const o=new Option(text,value);el.add(o);});el.value=current;el.onchange=()=>{change(el.value);feedback.textContent='';};host.append(el);};
 if(mode==='reply'){
  const legacy=document.createElement('p');legacy.textContent='此任务使用旧版回复键盘。';host.append(legacy);
 }
 select([['1','每排一个'],['2','每排两个']],String(width),value=>{width=Number(value);rowSizes=[];for(let i=0;i<items.length;i+=width)rowSizes.push(Math.min(width,items.length-i));sync();render();},'每排按钮数量');
 items.forEach((item,i)=>{const row=document.createElement('div');row.className='button-editor-row';const text=document.createElement('input');text.placeholder='按钮文字';text.setAttribute('aria-label','第 '+(i+1)+' 个按钮文字');text.maxLength=64;text.value=item.text;text.oninput=()=>{item.text=text.value;sync();preview.textContent=previewText();feedback.textContent='';};row.append(text);
 if(mode==='inline'){const type=document.createElement('select');type.setAttribute('aria-label','第 '+(i+1)+' 个按钮类型');['URL','PROMPT','CALLBACK'].forEach(x=>type.add(new Option(({URL:'打开链接',PROMPT:'显示提示',CALLBACK:'已有回调动作'})[x],x)));type.value=item.kind||'URL';type.onchange=()=>{item.kind=type.value;sync();render();feedback.textContent='';};const target=document.createElement('input');target.placeholder=item.kind==='PROMPT'?'点击后显示的提示内容':'https://链接 或已有回调数据';target.setAttribute('aria-label','第 '+(i+1)+' 个按钮链接或回调数据');target.value=item.target||'';target.oninput=()=>{item.target=target.value;sync();feedback.textContent='';};row.append(type,target);}
 [['上移',-1],['下移',1],['删除',0]].forEach(([label,delta])=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.disabled=delta!==0&&(i+delta<0||i+delta>=items.length);b.onclick=()=>{if(delta)[items[i],items[i+delta]]=[items[i+delta],items[i]];else {let n=i;for(let r=0;r<rowSizes.length;r++){if(n<rowSizes[r]){rowSizes[r]--;break;}n-=rowSizes[r];}rowSizes=rowSizes.filter(n=>n>0);items.splice(i,1);}sync();render();};row.append(b);});host.append(row);});
 const add=document.createElement('button');add.type='button';add.textContent='添加按钮';add.disabled=items.length>=20*width;add.onclick=()=>{if(rowSizes.length&&rowSizes.at(-1)<width)rowSizes[rowSizes.length-1]++;else rowSizes.push(1);items.push({text:'新按钮',kind:'URL',target:''});sync();render();};const preview=document.createElement('pre');preview.dataset.buttonPreview='';preview.textContent=previewText();host.append(add,preview,feedback);
 const newRow=document.createElement('button');newRow.type='button';newRow.textContent='新增一行';newRow.disabled=rowSizes.length>=20;newRow.onclick=()=>{rowSizes.push(1);items.push({text:'新按钮',kind:'URL',target:''});sync();render();};host.append(newRow);
 rowsNow().forEach((row,ri)=>{const controls=document.createElement('div');const label=document.createElement('span');label.textContent=`第 ${ri+1} 行（${row.length} 个按钮）`;controls.append(label);[['上移整行',-1],['下移整行',1],['删除整行',0]].forEach(([text,delta])=>{const b=document.createElement('button');b.type='button';b.className='secondary';b.textContent=text;b.disabled=delta!==0&&(ri+delta<0||ri+delta>=rowSizes.length);b.onclick=()=>{const rows=rowsNow();if(delta)[rows[ri],rows[ri+delta]]=[rows[ri+delta],rows[ri]];else rows.splice(ri,1);items=rows.flat();rowSizes=rows.map(r=>r.length);sync();render();};controls.append(b);});host.append(controls);});
 };
 buttonRaw.addEventListener('template-loaded',()=>{try{const data=JSON.parse(buttonRaw.value);mode=data.mode||'inline';items=(data.rows||[]).flat();rowSizes=(data.rows||[]).map(r=>r.length);width=Math.max(1,...rowSizes);sync();render();}catch{feedback.textContent='模板格式无效';}});
 buttonRaw.hidden=true;render();
 if(buttonRaw.form)buttonRaw.form.addEventListener('submit',event=>{sync();const error=validate();if(error){event.preventDefault();feedback.textContent=error;}});
}
const repeatSwitch=document.querySelector('[name="repeat_enabled"]');
if(repeatSwitch){const fields=Array.from(document.querySelectorAll('[name="repeat_duration_unit"],[name="repeat_duration_value"],[name="repeat_max_runs"]'));const refresh=()=>fields.forEach(field=>{field.disabled=!repeatSwitch.checked;});repeatSwitch.addEventListener('change',refresh);refresh();}
document.querySelectorAll("[data-bot-add]").forEach(form=>form.addEventListener("submit",()=>{const b=form.querySelector("button");b.disabled=true;b.textContent="正在验证，请稍候…";}));
const raw=document.querySelector("#rotation-messages");
if(raw){
 const host=document.createElement("div");raw.after(host);raw.hidden=true;
 let messages=raw.value.split(/\n\s*---轮换消息---\s*\n/).map(x=>x.trim()).filter(Boolean);
 const sync=()=>{raw.value=messages.join("\n---轮换消息---\n");};
 const render=()=>{host.replaceChildren();messages.forEach((value,i)=>{
  const card=document.createElement("section");card.className="card";
  const label=document.createElement("label");label.textContent=`轮换消息 ${i+1}`;
  const input=document.createElement("textarea");input.value=value;input.maxLength=4096;
  const preview=document.createElement("pre");preview.style.whiteSpace="pre-wrap";preview.textContent=value;
  input.addEventListener("input",()=>{messages[i]=input.value;preview.textContent=input.value;sync();});
  card.append(label,input,preview);
  [["上移",-1],["下移",1],["删除",0]].forEach(([title,delta])=>{const b=document.createElement("button");b.type="button";b.textContent=title;b.disabled=delta!==0&&(i+delta<0||i+delta>=messages.length);b.onclick=()=>{if(delta){[messages[i],messages[i+delta]]=[messages[i+delta],messages[i]];}else messages.splice(i,1);sync();render();};card.append(b);});host.append(card);
 });const add=document.createElement("button");add.type="button";add.textContent="添加轮换消息";add.disabled=messages.length>=20;add.onclick=()=>{messages.push("");render();};host.append(add);};render();
}

(() => {
  const raw = document.querySelector('textarea[name="buttons"]');
  if (!raw) return;
  const editor = document.querySelector('.button-editor');
  const preview = document.createElement('section');
  preview.className = 'card telegram-preview';
  const title = document.createElement('h3');
  title.textContent = '消息预览';
  const body = document.createElement('p');
  const keyboard = document.createElement('div');
  preview.append(title, body, keyboard);
  const workbench = document.createElement('div');
  workbench.className = 'button-workbench';
  editor.before(workbench);
  workbench.append(editor, preview);
  const message = document.querySelector('#broadcast-body,textarea[name="body"]');
  function render() {
    body.textContent = message?.value || '消息正文将在这里显示';
    keyboard.replaceChildren();
    let config;
    try { config = JSON.parse(raw.value); } catch { return; }
    for (const items of config.rows || []) {
      const row = document.createElement('div');
      row.className = 'preview-button-row';
      for (const item of items) {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = item.text || '按钮';
        button.title = item.kind === 'URL' ? item.target : '点击后执行已配置动作';
        button.onclick = () => { if(item.kind === 'PROMPT') window.alert(item.target || '请填写提示内容'); };
        row.append(button);
      }
      keyboard.append(row);
    }
  }
  raw.addEventListener('button-config-changed', render);
  message?.addEventListener('input', render);
  render();
})();
